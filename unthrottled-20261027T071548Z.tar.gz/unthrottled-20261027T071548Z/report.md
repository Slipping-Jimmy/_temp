# Unthrottled load test: unthrottled-20261027T071548Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_50c | sse_burst | 50 | 150 | 150 | 149 | 0.67 | 32 | 21.48 | 0 | 0 | 12655.9 | 64895.2 | 65440.6 | 51.5 |
  - errors: `{"sse_error_event": 1}`
| stage_002_sse_burst_100c | sse_burst | 100 | 300 | 300 | 97 | 67.67 | 37 | 38.14 | 0 | 0 | 11332.4 | 11844.7 | 11881.2 | 114.9 |
  - errors: `{"sse_error_event": 1, "sse_no_content": 202}`
| stage_003_sse_burst_150c | sse_burst | 150 | 450 | 450 | 32 | 92.89 | 15 | 46.88 | 0 | 0 | 14340.8 | 14526.8 | 14659.4 | 191.8 |
  - errors: `{"sse_no_content": 418}`
| stage_004_sse_burst_200c | sse_burst | 200 | 600 | 600 | 23 | 96.17 | 12 | 52.17 | 0 | 0 | 15376.4 | 15808.7 | 15867.7 | 212.0 |
  - errors: `{"sse_no_content": 573, "sse_record_save_error": 4}`
| stage_005_sse_burst_250c | sse_burst | 250 | 750 | 750 | 37 | 95.07 | 14 | 37.84 | 0 | 0 | 20126.2 | 20292.9 | 20423.9 | 334.5 |
  - errors: `{"sse_no_content": 703, "sse_record_save_error": 10}`
| stage_006_sse_burst_300c | sse_burst | 300 | 900 | 900 | 9 | 99.00 | 4 | 44.44 | 0 | 0 | 22382.6 | 30415.5 | 30474.3 | 371.0 |
  - errors: `{"sse_no_content": 847, "sse_record_save_error": 44}`
| stage_007_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 290 | 72.38 | 62 | 21.38 | 0 | 0 | 37277.2 | 85265.5 | 92700.7 | 451.0 |
  - errors: `{"sse_error_event": 11, "sse_no_content": 708, "sse_record_save_error": 41}`
| stage_008_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 377 | 68.58 | 68 | 18.04 | 0 | 0 | 52398.4 | 95031.2 | 100566.7 | 520.5 |
  - errors: `{"sse_error_event": 18, "sse_no_content": 770, "sse_record_save_error": 35}`
| stage_009_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 839 | 37.85 | 195 | 23.24 | 112 | 0 | 59412.3 | 101832.1 | 125589.8 | 619.2 |
  - errors: `{"sse_error_event": 47, "sse_model_communication_error": 1, "sse_no_content": 458, "sse_record_save_error": 5}`
  - 60-second cutoff candidates: **112**
  - timeout basis: `{"first_token": 112}`
| stage_010_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 585 | 61.00 | 131 | 22.39 | 188 | 0 | 78251.1 | 123345.6 | 132364.0 | 720.4 |
  - errors: `{"sse_error_event": 81, "sse_no_content": 806, "sse_record_save_error": 28}`
  - 60-second cutoff candidates: **188**
  - timeout basis: `{"first_token": 188}`

## 60-second cutoff boundary

The first cutoff candidate occurred at **stage_009_sse_burst_450c** (target=450, count=112).

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
