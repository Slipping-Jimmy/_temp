#!/bin/sh
set -eu

HOTFIX_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BASE_DIR="$(CDPATH= cd -- "${1:-.}" && pwd)"
EXPECTED_COMMIT="7c9da0d6d8f479d8263a79329b89822178b2d172"

# The app is unprivileged. Do not rely on the target extraction umask for
# bind-mounted code and static assets. Prompt Inspector receives a writable
# overlay catalogue, so prompt edits remain possible inside this hotfix folder.
chmod a+rx "$HOTFIX_DIR" "$HOTFIX_DIR/overlay" "$HOTFIX_DIR/overlay/letter_poc" \
  "$HOTFIX_DIR/overlay/letter_poc/domain" "$HOTFIX_DIR/overlay/letter_poc/services" \
  "$HOTFIX_DIR/overlay/web"
chmod a+r "$HOTFIX_DIR/overlay/letter_poc/domain/evidence.py" \
  "$HOTFIX_DIR/overlay/letter_poc/services/drafting.py" \
  "$HOTFIX_DIR/overlay/letter_poc/services/citation_ids.py" \
  "$HOTFIX_DIR/overlay/letter_poc/services/retrieval.py" \
  "$HOTFIX_DIR/overlay/web/app.js" "$HOTFIX_DIR/overlay/web/index.html" \
  "$HOTFIX_DIR/overlay/web/workflow-data.js"
chmod a+rw "$HOTFIX_DIR/overlay/letter_poc/prompts.yaml"

if [ ! -f "$BASE_DIR/docker-compose.yml" ] || [ ! -f "$BASE_DIR/.env" ]; then
  echo "Usage: $0 <existing-drafter-deployment-directory>" >&2
  echo "The target directory must contain docker-compose.yml and .env." >&2
  exit 2
fi
if [ ! -f "$BASE_DIR/release.json" ] || ! grep -q "\"commit\": \"$EXPECTED_COMMIT\"" "$BASE_DIR/release.json"; then
  echo "This hotfix only supports the v0.1.0 7c9da0d deployment base." >&2
  echo "Use the full 12d29ce offline bundle for another base revision." >&2
  exit 2
fi

(cd "$HOTFIX_DIR" && sha256sum -c checksums.sha256)
export DRAFTER_HOTFIX_DIR="$HOTFIX_DIR"
cd "$BASE_DIR"
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" config --quiet
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" up -d --pull never --force-recreate app prompt-inspector
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" ps
