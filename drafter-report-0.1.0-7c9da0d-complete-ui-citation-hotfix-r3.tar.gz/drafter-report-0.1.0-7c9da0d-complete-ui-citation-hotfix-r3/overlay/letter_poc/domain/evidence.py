from __future__ import annotations

import math
import uuid
from http import HTTPStatus

from letter_poc.errors import APIError
from letter_poc.limits import MAX_EVIDENCE_CONTENT_CHARS, MAX_EVIDENCE_SELECTION_ITEMS


ALLOWED_CORPUSES = frozenset({"reference"})


def normalize_evidence(items: object) -> list[dict]:
    """Normalize trusted stored evidence before it enters application services."""

    if not isinstance(items, list):
        return []
    clean = []
    total_chars = 0
    # A reviewed document set is intentionally not pre-trimmed to the old
    # drafting-card limit.  Context fit is checked explicitly before generation;
    # dropping item 31 here would be an invisible retrieval omission.
    for item in items[:MAX_EVIDENCE_SELECTION_ITEMS]:
        if not isinstance(item, dict):
            continue
        raw_content = str(item.get("content") or "")
        content = raw_content if item.get("full_body_retained") else (raw_content if item.get("mode") == "reference_document" else raw_content.strip())[:MAX_EVIDENCE_CONTENT_CHARS]
        if not content:
            continue
        remaining = MAX_EVIDENCE_CONTENT_CHARS * 10 - total_chars
        if not item.get("full_body_retained"):
            if remaining <= 0:
                break
            content = content[:remaining]
        corpus = str(item.get("corpus") or "reference")
        if corpus not in ALLOWED_CORPUSES:
            corpus = "reference"
        try:
            score = float(item.get("score") or 0)
        except (TypeError, ValueError):
            score = 0.0
        if not math.isfinite(score):
            score = 0.0
        clean.append(
            {
                "chunk_id": str(item.get("chunk_id") or "")[:500],
                "preview_chunk_id": str(item.get("preview_chunk_id") or item.get("chunk_id") or "")[:500],
                "evidence_id": str(item.get("evidence_id") or "")[:100],
                "letter_id": str(item.get("letter_id") or "")[:100],
                "document_id": str(item.get("document_id") or item.get("letter_id") or "")[:200],
                "page_nums": item.get("page_nums", []),
                "source_start": item.get("source_start"),
                "source_end": item.get("source_end"),
                "content_regions": item.get("content_regions", []),
                "subject": str(
                    item.get("subject")
                    or item.get("title")
                    or item.get("file_name")
                    or item.get("document_title")
                    or item.get("doc_name")
                    or item.get("document_id")
                    or item.get("letter_id")
                    or ""
                )[:500],
                "sender": str(item.get("sender") or "")[:200],
                "sent_at": item.get("sent_at"),
                "source": str(item.get("source") or "")[:2_000],
                "score": score,
                "mode": str(item.get("mode") or "")[:100],
                "content": content,
                "source_content": item.get("source_content", content),
                "selected_text": item.get("selected_text", content),
                "full_body_retained": bool(item.get("full_body_retained")),
                "page_contexts": item.get("page_contexts", []),
                "file_contexts": item.get("file_contexts", []),
                "case_id": str(item.get("case_id") or "")[:200],
                "application_time": str(item.get("application_time") or "")[:100],
                "corpus": corpus,
                "url": str(item.get("url") or "")[:2_000],
                "category": str(item.get("category") or "")[:300],
            }
        )
        total_chars += len(content)
    return clean


def public_letter_evidence(rows: list[dict]) -> list[dict]:
    evidence = []
    for row in rows:
        metadata = row.get("letter_metadata") or {}
        evidence.append(
            {
                "chunk_id": row["chunk_id"],
                "letter_id": row["letter_id"],
                "subject": row["subject"],
                "sender": row.get("sender"),
                "sent_at": row.get("sent_at"),
                "source": row.get("source"),
                "score": float(row.get("score") or 0),
                "mode": row.get("mode"),
                "content": row["content"],
                "case_id": metadata.get("case_id"),
                "application_time": metadata.get("application_time"),
                "original_request": metadata.get("request"),
                "original_reply": metadata.get("reply"),
                "corpus": "letters",
            }
        )
    return evidence


def public_legal_evidence(rows: list[dict]) -> list[dict]:
    evidence = []
    for row in rows:
        metadata = row.get("document_metadata") or {}
        evidence.append(
            {
                "chunk_id": row["chunk_id"],
                "letter_id": row["document_id"],
                "subject": row["title"],
                "sender": "legal-corpus",
                "sent_at": None,
                "source": row.get("source_url"),
                "score": float(row.get("score") or 0),
                "mode": row.get("mode"),
                "content": row["content"],
                "case_id": row.get("category"),
                "application_time": None,
                "original_request": None,
                "original_reply": None,
                "corpus": "legal",
                "url": row.get("source_url"),
                "category": row.get("category"),
                "metadata": metadata,
            }
        )
    return evidence


def numbered_evidence_block(evidence: list[dict]) -> str:
    blocks = []
    for index, item in enumerate(evidence, start=1):
        corpus = "備參資料"
        source = item.get("url") or item.get("source") or ""
        blocks.append(
            f"[{index}] Corpus: {corpus}\n"
            f"Subject: {item.get('subject')}\n"
            f"Source: {source}\n"
            f"Excerpt: {item.get('content')}"
        )
    return "\n\n".join(blocks)


def revision_warnings(instruction: str, request: str, evidence: list[dict]) -> list[str]:
    text = instruction.casefold()
    evidence_text = "\n".join(
        f"{item.get('subject', '')}\n{item.get('content', '')[:500]}"
        for item in evidence[:8]
        if isinstance(item, dict)
    ).casefold()
    context = f"{request.casefold()}\n{evidence_text}"
    stance_terms = (
        "崇拜", "歌頌", "吹捧", "讚揚", "赞扬", "表態支持", "批判", "批評",
        "批评", "攻擊", "攻击", "羞辱", "辱罵", "辱骂",
    )
    targets = (
        "賴清德", "赖清德", "總統", "总统", "政治人物", "政黨", "政党",
        "民進黨", "民进党", "國民黨", "国民党", "世界衛生組織",
        "世界卫生组织", "who", "world health organization",
    )
    has_stance = any(term in text for term in stance_terms)
    mentioned = [term for term in targets if term in text]
    unsupported_target = bool(mentioned) and not any(term in context for term in mentioned)
    if has_stance and mentioned:
        return ["修訂指令包含政治人物、外部組織或立場性評價；系統會維持公務中立，未將這類內容加入草稿。"]
    if unsupported_target:
        return ["修訂指令要求加入與來信或 evidence 無關的政治人物或外部組織；系統會優先維持回信主旨與資料來源限制。"]
    if has_stance:
        return ["修訂指令包含未必由 evidence 支持的立場性描述；系統會優先保留資料來源可支持的內容。"]
    return []


def assign_evidence_ids(evidence: list[dict]) -> list[dict]:
    assigned = []
    for item in evidence:
        corpus = str(item.get("corpus") or "reference")
        document_id = str(item.get("document_id") or item.get("letter_id") or "")
        chunk_id = str(item.get("chunk_id") or "")
        if document_id or chunk_id:
            identity = f"{corpus}\x1f{document_id}\x1f{chunk_id}"
        else:
            identity = "\x1f".join(
                (
                    corpus,
                    str(item.get("subject") or ""),
                    str(item.get("source") or item.get("url") or ""),
                    str(item.get("content") or ""),
                )
            )
        assigned.append({**item, "evidence_id": str(uuid.uuid5(uuid.NAMESPACE_URL, identity))})
    return assigned


def select_evidence(evidence: list[dict], evidence_ids: object) -> list[dict]:
    if not isinstance(evidence_ids, list) or not evidence_ids:
        raise APIError(HTTPStatus.BAD_REQUEST, "Missing evidence_ids")
    if len(evidence_ids) > MAX_EVIDENCE_SELECTION_ITEMS:
        raise APIError(HTTPStatus.BAD_REQUEST, f"At most {MAX_EVIDENCE_SELECTION_ITEMS} evidence_ids are allowed")
    requested = []
    seen = set()
    for value in evidence_ids:
        evidence_id = str(value or "")
        if evidence_id and evidence_id not in seen:
            requested.append(evidence_id)
            seen.add(evidence_id)
    by_id = {str(item.get("evidence_id") or ""): item for item in evidence}
    if not requested or any(evidence_id not in by_id for evidence_id in requested):
        raise APIError(HTTPStatus.BAD_REQUEST, "Invalid evidence selection")
    return [by_id[evidence_id] for evidence_id in requested]
