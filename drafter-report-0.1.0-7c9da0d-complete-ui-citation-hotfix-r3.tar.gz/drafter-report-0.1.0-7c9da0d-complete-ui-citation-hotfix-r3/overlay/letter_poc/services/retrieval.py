from __future__ import annotations

import logging
from dataclasses import dataclass
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed
from http import HTTPStatus
from typing import Any, Callable

from letter_poc.config import Settings
from letter_poc.domain.evidence import (
    assign_evidence_ids,
    select_evidence,
)
from letter_poc.domain.identifiers import parse_uuid
from letter_poc.errors import APIError
from letter_poc.limits import (
    reference_evidence_limit,
)
from letter_poc.providers.reference import search_reference
from letter_poc.services.document_retrieval import expand_documents
from letter_poc.services.document_review import build_candidate_ledger, review_candidates
from letter_poc.domain.retrieval_audit import (
    COMPLETE_REVIEW_STATUSES,
    MAX_EFFORT_REVIEW_STATUSES,
    empty_retrieval_audit,
)
from letter_poc.repositories.runs import (
    load_evidence_snapshot,
    load_run_evidence,
    load_run_reviewed_evidence,
)
from letter_poc.services.agentic_retrieval import (
    compress_evidence,
    decompose_queries,
    enabled as agentic_retrieval_enabled,
    next_query,
)


@dataclass(frozen=True)
class MandatoryRetrievalResult:
    """Trusted output of the v0.1.0 reference-document review workflow."""

    evidence: list[dict]
    reviewed_evidence: list[dict]
    retrieval_audit: dict
    failures: list[dict]
    ready_for_draft: bool
    blocked_reason: str | None = None


def _generation_context_char_count(evidence: list[dict]) -> int:
    """Count the exact text that the draft model will receive."""

    return sum(len(str(unit.get("selected_text") or unit.get("content") or "")) for unit in evidence)


def search_corpuses(
    query: str,
    mode: str,
    corpuses: list[str],
    settings: Settings,
) -> tuple[list[dict], list[dict]]:
    """Retrieve sources concurrently and merge deterministically by source order."""

    def retrieve(corpus: str) -> list[dict]:
        if corpus != "reference":
            raise ValueError(f"Unsupported corpus: {corpus}")
        return search_reference(query, reference_evidence_limit(), settings)

    results_by_corpus: dict[str, list[dict]] = {}
    failures: list[dict] = []
    with ThreadPoolExecutor(max_workers=len(corpuses)) as executor:
        futures = {executor.submit(retrieve, corpus): corpus for corpus in corpuses}
        for future in as_completed(futures):
            corpus = futures[future]
            try:
                results_by_corpus[corpus] = future.result()
            except Exception as exc:
                logging.warning("Retrieval failed for corpus %s: %s", corpus, exc)
                results_by_corpus[corpus] = []
                failures.append({"corpus": corpus, "error": str(exc)[:300]})

    merged: list[dict] = []
    seen: set[str] = set()
    for corpus in corpuses:
        for item in results_by_corpus.get(corpus, []):
            key = _evidence_key(item)
            if key not in seen:
                seen.add(key)
                merged.append(item)
    return assign_evidence_ids(merged), failures


def _evidence_key(item: dict) -> str:
    corpus = str(item.get("corpus") or "")
    if corpus == "letters":
        return f"letters:{item.get('chunk_id')}"
    if corpus == "legal":
        return f"legal:{item.get('legal_id')}"
    if corpus == "web":
        return f"web:{item.get('url') or item.get('title')}"
    if corpus == "reference" and item.get("chunk_id"):
        return f"reference:{item.get('document_id') or item.get('letter_id') or ''}:{item['chunk_id']}"
    return f"{corpus}:{item.get('evidence_id')}"


def _merge_evidence(existing: list[dict], incoming: list[dict]) -> list[dict]:
    merged = list(existing)
    seen = {_evidence_key(item) for item in existing}
    for item in incoming:
        key = _evidence_key(item)
        if key not in seen:
            seen.add(key)
            merged.append(item)
    return merged


def _corpus_display_name(corpus: str) -> str:
    if corpus == "reference":
        return "備參資料"
    if corpus == "legal":
        return "健保相關法規"
    if corpus == "web":
        return "網路資訊"
    return "民眾意見信箱"


def _review_cards_for_planner(audit: dict) -> list[dict]:
    """Use bounded metadata cards for follow-up planning, never chunk excerpts."""

    cards = []
    for document in audit.get("documents", []):
        if not isinstance(document, dict):
            continue
        cards.append(
            {
                "evidence_id": str(document.get("candidate_id") or ""),
                "corpus": "reference",
                "subject": str(document.get("title") or ""),
                "score": max((float(hit.get("score") or 0) for hit in document.get("hits", []) if isinstance(hit, dict)), default=0.0),
                "content": (
                    f"review_status={document.get('status')}; "
                    f"topics={','.join(str(value) for value in document.get('covered_topics', []))}; "
                    f"reason={document.get('reason', '')}"
                )[:1_200],
            }
        )
    return cards


def _initial_queries_with_progress(
    settings: Settings,
    request: str,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
) -> list[str]:
    """Run optional topic decomposition while exposing its otherwise silent wait."""

    if not agentic_retrieval_enabled(settings):
        return [request]
    if on_event:
        on_event("topic_decomposition_started", {"request_length": len(request)})
    queries = decompose_queries(settings, request)
    if not queries:
        queries = [request]
    if on_event:
        on_event("topic_decomposition_completed", {"query_count": len(queries)})
    return queries


def retrieve_reference_with_mandatory_review(
    request: str,
    settings: Settings,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
) -> MandatoryRetrievalResult:
    """Search every wave, then fully review every newly discovered document.

    This intentionally bypasses ``expand_documents`` and ``compress_evidence``:
    neither the prior 18-card selection nor the context compressor is allowed
    to drop a reviewed reference-document unit.
    """

    # This entry point is called directly by the draft server, so it must own
    # the search ordinal rather than relying on retrieve_for_draft() to add it.
    # It also keeps direct callers and the mandatory SSE contract consistent.
    if on_event:
        on_event = _count_search_events(on_event)

    initial_queries = _initial_queries_with_progress(settings, request, on_event)
    queries = list(initial_queries)
    all_hits: list[dict] = []
    failures: list[dict] = []
    reviewed_by_candidate: dict[str, list[dict]] = {}
    audit_by_candidate: dict[str, dict] = {}

    def execute_query(query: str, round_number: int) -> None:
        if on_event:
            on_event("retrieval_query_started", {"query": query, "round_number": round_number, "corpus": "reference", "corpus_label": _corpus_display_name("reference")})
        retrieved, errors = search_corpuses(query, "vector", ["reference"], settings)
        retrieved = [{**item, "topic_query": query} for item in retrieved]
        all_hits.extend(retrieved)
        failures.extend(errors)
        candidates = build_candidate_ledger(all_hits)
        if on_event:
            on_event(
                "retrieval_query_completed",
                {
                    "query": query,
                    "round_number": round_number,
                    "evidence_count": len(retrieved),
                    "failure_count": len(errors),
                    "cumulative_chunk_count": sum(len(candidate["hits"]) for candidate in candidates),
                    "cumulative_document_count": len(candidates),
                    "corpus": "reference",
                    "corpus_label": _corpus_display_name("reference"),
                },
            )
            on_event(
                "retrieval_hits_collected",
                {"query": query, "chunk_count": len(retrieved), "cumulative_chunk_count": sum(len(candidate["hits"]) for candidate in candidates), "cumulative_document_count": len(candidates)},
            )

    def review_new_documents() -> tuple[list[dict], dict]:
        candidates = build_candidate_ledger(all_hits)
        new_candidates = [candidate for candidate in candidates if candidate["candidate_id"] not in audit_by_candidate]
        if new_candidates:
            new_units, wave_audit = review_candidates(settings, request, new_candidates, on_event)
            by_candidate = {}
            for unit in new_units:
                by_candidate.setdefault(str(unit.get("candidate_id") or ""), []).append(unit)
            reviewed_by_candidate.update(by_candidate)
            audit_by_candidate.update({document["candidate_id"]: document for document in wave_audit["documents"]})
        # A later query may add a hit to a known document.  Its canonical source
        # has already been reviewed, but the audit must retain every hit.
        for candidate in candidates:
            if candidate["candidate_id"] in audit_by_candidate:
                audit_by_candidate[candidate["candidate_id"]]["hits"] = [
                    {key: hit[key] for key in ("chunk_id", "query", "score", "page_nums")}
                    for hit in candidate["hits"]
                ]
        documents = [audit_by_candidate[candidate["candidate_id"]] for candidate in candidates if candidate["candidate_id"] in audit_by_candidate]
        reviewed = [unit for candidate in candidates for unit in reviewed_by_candidate.get(candidate["candidate_id"], [])]
        audit = empty_retrieval_audit()
        selected = [unit for unit in reviewed if unit.get("use_for_generation")]
        audit.update(
            {
                "queries": list(queries),
                "search_hit_count": sum(len(candidate["hits"]) for candidate in candidates),
                "document_count": len(candidates),
                "reviewed_document_count": sum(document["status"] in COMPLETE_REVIEW_STATUSES for document in documents),
                "selected_document_count": len({unit.get("document_id") for unit in selected}),
                "partial_document_count": sum(document["status"] == "source_incomplete" for document in documents),
                "all_reviews_complete": len(documents) == len(candidates) and all(document["status"] in COMPLETE_REVIEW_STATUSES for document in documents),
                "all_documents_processed": len(documents) == len(candidates) and all(document["status"] in MAX_EFFORT_REVIEW_STATUSES for document in documents),
                "documents": documents,
            }
        )
        return reviewed, audit

    for query in initial_queries:
        execute_query(query, 1)
    reviewed_evidence, audit = review_new_documents()

    # The planner sees only review disposition cards and runs only after every
    # document in the preceding wave has either a complete review or an audited
    # partial-source result.  Fetch/review failures remain hard stops.
    for round_number in range(2, int(getattr(settings, "agentic_retrieval_max_rounds", 1)) + 1):
        if not audit["all_documents_processed"] or not agentic_retrieval_enabled(settings):
            break
        follow_up = next_query(settings, request, _review_cards_for_planner(audit), queries, corpus="reference", on_event=on_event)
        if not follow_up:
            break
        queries.append(follow_up)
        execute_query(follow_up, round_number)
        reviewed_evidence, audit = review_new_documents()

    selected_evidence = [unit for unit in reviewed_evidence if unit.get("use_for_generation")]
    char_count = _generation_context_char_count(selected_evidence)
    max_chars = int(getattr(settings, "agentic_retrieval_context_chars", 30_000))
    if not audit["all_documents_processed"]:
        return MandatoryRetrievalResult([], reviewed_evidence, audit, failures, False, "retrieval_incomplete")
    if char_count > max_chars:
        # Every hit has already had a full review (or an audited partial-source
        # review).  Compact only those trusted selections into verbatim excerpts
        # so a large result set does not discard all useful work.  The complete
        # reviewed ledger remains persisted for inspection and regeneration.
        try:
            compacted = compress_evidence(
                settings,
                request,
                selected_evidence,
                "reference",
                on_event=on_event,
                input_kind="reviewed_generation_units",
            )
        except Exception:
            compacted = []
        compacted_char_count = _generation_context_char_count(compacted)
        if not compacted or compacted_char_count > max_chars:
            if on_event:
                on_event("generation_context_overflow", {"required_character_count": char_count, "allowed_character_count": max_chars, "selected_unit_count": len(selected_evidence)})
            return MandatoryRetrievalResult([], reviewed_evidence, audit, failures, False, "generation_context_overflow")
        selected_evidence = compacted
        audit.update(
            {
                "generation_context_compacted": True,
                "generation_selected_document_count": len({unit.get("document_id") for unit in selected_evidence}),
                "generation_selected_unit_count": len(selected_evidence),
                "generation_selected_character_count": compacted_char_count,
            }
        )
        if on_event:
            on_event(
                "generation_context_compacted",
                {
                    "original_character_count": char_count,
                    "compacted_character_count": compacted_char_count,
                    "original_unit_count": len([unit for unit in reviewed_evidence if unit.get("use_for_generation")]),
                    "selected_unit_count": len(selected_evidence),
                    "allowed_character_count": max_chars,
                },
            )
    else:
        audit.update(
            {
                "generation_context_compacted": False,
                "generation_selected_document_count": len({unit.get("document_id") for unit in selected_evidence}),
                "generation_selected_unit_count": len(selected_evidence),
                "generation_selected_character_count": char_count,
            }
        )
    if on_event:
        on_event(
            "generation_evidence_ready",
            {
                "selected_document_count": audit["generation_selected_document_count"],
                "selected_unit_count": len(selected_evidence),
                "selected_character_count": audit["generation_selected_character_count"],
                "context_compacted": audit["generation_context_compacted"],
                "input_kind": "verbatim_excerpt" if audit["generation_context_compacted"] else "reviewed_generation_units",
            },
        )
    return MandatoryRetrievalResult(selected_evidence, reviewed_evidence, audit, failures, True)


def _retrieve_corpus_agentic(
    corpus: str,
    request: str,
    initial_queries: list[str],
    settings: Settings,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
) -> tuple[list[dict], list[dict]]:
    """Execute dedicated agentic retrieval loop (search -> planning -> compression) for one corpus."""
    evidence: list[dict] = []
    failures: list[dict] = []
    attempted_queries = list(initial_queries)
    corpus_label = _corpus_display_name(corpus)

    # Round 1: Search all decomposed sub-queries for this corpus
    for query in initial_queries:
        if on_event:
            on_event(
                "retrieval_query_started",
                {"query": query, "round_number": 1, "corpus": corpus, "corpus_label": corpus_label},
            )
        retrieved, round_failures = search_corpuses(query, "vector", [corpus], settings)
        retrieved = [{**item, "topic_query": query} for item in retrieved]
        evidence = _merge_evidence(evidence, retrieved)
        failures.extend(round_failures)
        if on_event:
            on_event(
                "retrieval_query_completed",
                {
                    "query": query,
                    "round_number": 1,
                    "evidence_count": len(retrieved),
                    "failure_count": len(round_failures),
                    "corpus": corpus,
                    "corpus_label": corpus_label,
                },
            )

    # Subsequent rounds: Evaluate and perform targeted follow-up search
    # v0.1.0 Settings always expose document_review_enabled.  Reference
    # documents must then use the mandatory-review entry point above, never the
    # older optional read_document/context-compressor loop.  The attribute-free
    # branch remains only for legacy unit fixtures and non-v0.1 callers.
    document_agent = (
        corpus == "reference"
        and getattr(settings, "document_retrieval_enabled", False)
        and not hasattr(settings, "document_review_enabled")
    )
    if document_agent:
        def followup_search(query):
            items, errors = search_corpuses(query, "vector", [corpus], settings)
            return [{**item, "topic_query": query} for item in items], errors

        if getattr(settings, "parallel_evidence_preparation_enabled", False):
            from letter_poc.services.parallel_retrieval import prepare_parallel
            compressed, document_failures = prepare_parallel(
                settings, request, evidence, attempted_queries, followup_search, on_event,
            )
            return compressed, failures + document_failures

        evidence, document_failures = expand_documents(
            settings, request, evidence, attempted_queries, followup_search, on_event,
        )
        failures.extend(document_failures)
    for round_index in range(1, 1 if document_agent else settings.agentic_retrieval_max_rounds):
        follow_up = next_query(
            settings,
            request,
            evidence,
            attempted_queries,
            corpus=corpus,
            on_event=on_event,
        )
        if not follow_up:
            break
        attempted_queries.append(follow_up)
        if on_event:
            on_event(
                "retrieval_query_started",
                {"query": follow_up, "round_number": round_index + 1, "corpus": corpus, "corpus_label": corpus_label},
            )
        retrieved, round_failures = search_corpuses(follow_up, "vector", [corpus], settings)
        retrieved = [{**item, "topic_query": follow_up} for item in retrieved]
        evidence = _merge_evidence(evidence, retrieved)
        failures.extend(round_failures)
        if on_event:
            on_event(
                "retrieval_query_completed",
                {
                    "query": follow_up,
                    "round_number": round_index + 1,
                    "evidence_count": len(retrieved),
                    "failure_count": len(round_failures),
                    "corpus": corpus,
                    "corpus_label": corpus_label,
                },
            )

    compressed = compress_evidence(
        settings,
        request,
        evidence,
        corpus=corpus,
        on_event=on_event,
    )
    return compressed, failures


def _count_search_events(callback):
    """Number actual search calls, not planning rounds or document reads."""
    number = 0
    numbers = {}
    lock = Lock()
    def emit(event, data):
        nonlocal number
        with lock:
            key = (data.get("corpus"), data.get("query"))
            if event == "retrieval_query_started":
                number += 1
                numbers[key] = number
            if event in {"retrieval_query_started", "retrieval_query_completed"}:
                data = {**data, "search_number": numbers.get(key, number)}
            callback(event, data)
    return emit


def retrieve_for_draft(
    request: str,
    corpuses: list[str],
    settings: Settings,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
) -> tuple[list[dict], list[dict]]:
    """Retrieve draft evidence, optionally using a bounded planning/retrieval loop.

    When agentic retrieval is enabled, requests are decomposed into clean sub-queries,
    each requested corpus runs its dedicated planning/compression loop in parallel,
    and results are gathered and merged.
    """

    if (
        corpuses == ["reference"]
        and bool(getattr(settings, "document_review_enabled", False))
    ):
        result = retrieve_reference_with_mandatory_review(request, settings, on_event)
        return result.evidence, result.failures

    if on_event:
        on_event = _count_search_events(on_event)

    if not agentic_retrieval_enabled(settings):
        if on_event:
            on_event("retrieval_query_started", {"query": request, "round_number": 1})
        evidence, failures = search_corpuses(request, "vector", corpuses, settings)
        if on_event:
            on_event(
                "retrieval_query_completed",
                {"query": request, "round_number": 1, "evidence_count": len(evidence), "failure_count": len(failures)},
            )
        return evidence, failures

    initial_queries = _initial_queries_with_progress(settings, request, on_event)

    results_by_corpus: dict[str, list[dict]] = {}
    failures_by_corpus: dict[str, list[dict]] = {}

    with ThreadPoolExecutor(max_workers=len(corpuses)) as executor:
        futures = {
            executor.submit(_retrieve_corpus_agentic, corpus, request, initial_queries, settings, on_event): corpus
            for corpus in corpuses
        }
        for future in as_completed(futures):
            corpus = futures[future]
            try:
                evidence_list, failure_list = future.result()
                results_by_corpus[corpus] = evidence_list
                failures_by_corpus[corpus] = failure_list
            except Exception as exc:
                logging.warning("Agentic retrieval failed for corpus %s: %s", corpus, exc)
                results_by_corpus[corpus] = []
                failures_by_corpus[corpus] = [{"corpus": corpus, "error": str(exc)[:300]}]

    merged_evidence: list[dict] = []
    all_failures: list[dict] = []
    dedupe_keys = set()

    for corpus in corpuses:
        for item in results_by_corpus.get(corpus, []):
            key = _evidence_key(item)
            if key not in dedupe_keys:
                dedupe_keys.add(key)
                merged_evidence.append(item)
        all_failures.extend(failures_by_corpus.get(corpus, []))

    return assign_evidence_ids(merged_evidence), all_failures


def trusted_evidence_from_payload(settings: Settings, payload: dict) -> list[dict]:
    if "evidence" in payload:
        raise APIError(HTTPStatus.BAD_REQUEST, "Raw evidence is not accepted; use evidence_ids")
    evidence_ids = payload.get("evidence_ids")
    snapshot_id = str(payload.get("evidence_snapshot_id") or "").strip()
    run_id = str(payload.get("run_id") or "").strip()

    available: list[dict] = []
    if snapshot_id:
        parsed_snapshot_id = parse_uuid(snapshot_id, "evidence_snapshot_id")
        available = _merge_evidence(available, load_evidence_snapshot(settings, parsed_snapshot_id))
    if run_id:
        parsed_run_id = parse_uuid(run_id, "run_id")
        available = _merge_evidence(available, load_run_evidence(settings, parsed_run_id))
        available = _merge_evidence(available, load_run_reviewed_evidence(settings, parsed_run_id))

    if available:
        if evidence_ids is not None:
            return select_evidence(available, evidence_ids)
        return available
    return []
