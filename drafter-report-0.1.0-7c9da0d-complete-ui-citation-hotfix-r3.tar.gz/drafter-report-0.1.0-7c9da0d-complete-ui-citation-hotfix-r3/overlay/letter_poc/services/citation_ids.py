"""Explicit citation IDs bind model-selected exact quotes to each body marker."""
import json
import re
import unicodedata
from difflib import SequenceMatcher
from http import HTTPStatus
from letter_poc.errors import APIError
from letter_poc.domain.citations import compact_text


def _citation_text_key(text):
    """Return typography-insensitive text plus offsets into the original string."""
    comparable = []
    positions = []
    for index, char in enumerate(str(text or '')):
        for normalized in unicodedata.normalize('NFKC', char):
            category = unicodedata.category(normalized)
            if normalized.isspace() or category.startswith('P') or category == 'Cf':
                continue
            comparable.append(normalized)
            positions.append(index)
    return ''.join(comparable), positions


def _locate_quote(source, quote):
    start = source.find(quote)
    if start >= 0:
        return start, start + len(quote), 'citation_id_exact'

    compact, positions = compact_text(source)
    needle, _ = compact_text(quote)
    pos = compact.find(needle) if needle else -1
    if pos >= 0:
        return positions[pos], positions[pos + len(needle) - 1] + 1, 'citation_id_compact_exact'

    # PDF/OCR text and model output commonly differ only in full-width forms or
    # punctuation. Match the same contiguous letters/numbers, then restore the
    # verbatim source slice so normalized model text never becomes evidence.
    comparable, positions = _citation_text_key(source)
    needle, _ = _citation_text_key(quote)
    pos = comparable.find(needle) if needle else -1
    if pos >= 0:
        return positions[pos], positions[pos + len(needle) - 1] + 1, 'citation_id_typographic_exact'
    return None


def _nearest_quote_candidate(source, quote):
    """Find one high-confidence source span to *guide* repair, never validation."""
    comparable, positions = _citation_text_key(source)
    needle, _ = _citation_text_key(quote)
    if (
        len(needle) < 12
        or len(needle) > 2000
        or not comparable
        or len(comparable) > 12000
    ):
        return None

    matcher = SequenceMatcher(None, needle, comparable)
    blocks = sorted(matcher.get_matching_blocks()[:-1], key=lambda block: block.size, reverse=True)
    if not blocks or blocks[0].size < len(needle) * 0.45:
        return None

    candidates = {}
    for block in blocks[:6]:
        inferred_start = block.b - block.a
        for start in range(max(0, inferred_start - 4), min(len(comparable), inferred_start + 4) + 1):
            for length in range(max(1, len(needle) - 4), len(needle) + 5):
                end = start + length
                if end > len(comparable):
                    continue
                candidate_key = comparable[start:end]
                score = SequenceMatcher(None, needle, candidate_key).ratio()
                current = candidates.get((start, end))
                if current is None or score > current:
                    candidates[(start, end)] = score
    if not candidates:
        return None

    ranked = sorted(candidates.items(), key=lambda item: item[1], reverse=True)
    (start, end), score = ranked[0]
    if score < 0.90:
        return None

    candidate_key = comparable[start:end]
    changes = []
    for tag, a1, a2, b1, b2 in SequenceMatcher(None, needle, candidate_key).get_opcodes():
        if tag != "equal":
            changes.append((needle[a1:a2], candidate_key[b1:b2]))
    changed_chars = sum(max(len(left), len(right)) for left, right in changes)
    if changed_chars > max(2, round(len(needle) * 0.02)):
        return None
    # A close number, negation, or modal is not a safe repair hint. The model
    # must reconsider such a claim from the full evidence instead.
    sensitive = set("0123456789不無未非勿莫應得須可禁限")
    if any(any(char in sensitive for char in left + right) for left, right in changes):
        return None

    # Reject a similarly scored candidate at a different location. Overlapping
    # windows merely represent the same source occurrence.
    for (other_start, other_end), other_score in ranked[1:]:
        if other_score < score - 0.005:
            break
        overlap = max(0, min(end, other_end) - max(start, other_start))
        if overlap < min(end - start, other_end - other_start) * 0.5:
            return None

    original_start = positions[start]
    original_end = positions[end - 1] + 1
    while original_end < len(source) and (
        source[original_end].isspace()
        or unicodedata.category(source[original_end]).startswith("P")
    ):
        original_end += 1
    return source[original_start:original_end]


class CitationQuoteMismatch(APIError):
    """Strict quote failure with internal-only details for a targeted retry."""

    def __init__(self, item, evidence_item):
        super().__init__(HTTPStatus.BAD_GATEWAY, "Citation quote is not present in its source")
        citation = item if isinstance(item, dict) else {}
        quote = str(citation.get("support_quote") or "").strip()
        source = str(evidence_item.get("content") or "")
        citation_body = str(evidence_item.get("selected_text") or source)
        candidate = _nearest_quote_candidate(citation_body, quote)
        self.repair_context = {
            "citation_id": citation.get("id"),
            "evidence_index": citation.get("evidence_index"),
            "invalid_support_quote": quote[:4000],
            "exact_source_candidate": candidate,
            "specified_citation_body": citation_body[:6000],
        }

def resolve_citation_ids(raw, evidence):
    if not isinstance(raw, list):
        raise APIError(HTTPStatus.BAD_GATEWAY, 'Missing citation list')
    result = {}
    for item in raw:
        if not isinstance(item, dict):
            raise APIError(HTTPStatus.BAD_GATEWAY, 'Invalid citation entry')
        key = item.get('id')
        index = item.get('evidence_index')
        quote = str(item.get('support_quote') or '').strip()
        if not isinstance(key, str) or not re.fullmatch(r'C[1-9]\d*', key) or key in result:
            raise APIError(HTTPStatus.BAD_GATEWAY, 'Invalid or duplicate citation ID')
        if type(index) is not int or not 1 <= index <= len(evidence) or not quote:
            raise APIError(HTTPStatus.BAD_GATEWAY, 'Invalid citation source or quote')
        source = str(evidence[index-1].get('content') or '')
        located = _locate_quote(source, quote)
        if located is None:
            raise CitationQuoteMismatch(item, evidence[index-1])
        start, end, method = located
        result[key] = dict(id=key, evidence_index=index, support_quote=source[start:end], start_char=start, end_char=end, match_method=method, confidence=None)
    return result


def remove_unsupported_citation_claims(draft, raw, evidence):
    """Remove only claims whose explicit citation IDs cannot be located.

    This is a last-resort guard for the *single* citation-repair response.  It
    never substitutes an approximate quote: every retained citation still goes
    through :func:`resolve_citation_ids`.  A model may occasionally put a quote
    from one Evidence item under another item's index.  Rather than publishing
    that claim or failing an otherwise fully supported report, remove the
    sentence (or reference-list line) containing that bad ``[C#]`` marker.
    """
    if not isinstance(raw, list):
        raise APIError(HTTPStatus.BAD_GATEWAY, "Missing citation list")

    valid = []
    invalid_ids = set()
    seen = set()
    for item in raw:
        if not isinstance(item, dict):
            raise APIError(HTTPStatus.BAD_GATEWAY, "Invalid citation entry")
        key = item.get("id")
        if not isinstance(key, str) or not re.fullmatch(r"C[1-9]\d*", key) or key in seen:
            raise APIError(HTTPStatus.BAD_GATEWAY, "Invalid or duplicate citation ID")
        seen.add(key)
        try:
            resolve_citation_ids([item], evidence)
        except CitationQuoteMismatch:
            invalid_ids.add(key)
        else:
            valid.append(item)

    if not invalid_ids:
        return draft, raw, []

    spans = []
    for marker in _DRAFT_MARKER_RE.finditer(draft):
        if not invalid_ids.intersection(_c_style_marker_ids(marker.group(1))):
            continue
        line_start = draft.rfind("\n", 0, marker.start()) + 1
        line_end = draft.find("\n", marker.end())
        if line_end < 0:
            line_end = len(draft)

        start = line_start
        for boundary in _SENTENCE_BREAKS:
            position = draft.rfind(boundary, line_start, marker.start())
            if position >= start:
                start = position + 1

        end = line_end
        punctuation = [
            position
            for boundary in _SENTENCE_BREAKS
            if boundary != "\n"
            for position in [draft.find(boundary, marker.end(), line_end)]
            if position >= 0
        ]
        if punctuation:
            end = min(punctuation) + 1
        while end < len(draft) and draft[end] in " \t":
            end += 1
        if end < len(draft) and draft[end] == "\n":
            end += 1
        spans.append((start, end))

    merged_spans = []
    for start, end in sorted(spans):
        if merged_spans and start <= merged_spans[-1][1]:
            previous_start, previous_end = merged_spans[-1]
            merged_spans[-1] = (previous_start, max(previous_end, end))
        else:
            merged_spans.append((start, end))

    cleaned = draft
    for start, end in reversed(merged_spans):
        cleaned = cleaned[:start] + cleaned[end:]

    retained_ids = {
        key
        for match in _DRAFT_MARKER_RE.finditer(cleaned)
        for key in (_c_style_marker_ids(match.group(1)) or [match.group(1)])
    }
    if not retained_ids:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation repair has no supported claims")
    return cleaned.strip(), valid, sorted(invalid_ids)

def complete_citation_prefix(text, evidence):
    match = re.search(r'"citations"\s*:\s*', text)
    if not match:
        return None
    try:
        raw, _ = json.JSONDecoder().raw_decode(text[match.end():])
    except json.JSONDecodeError:
        return None
    return list(resolve_citation_ids(raw, evidence).values())


_DRAFT_MARKER_RE = re.compile(
    r"\[((?:C[1-9]\d*)(?:\s*[,，、]\s*C[1-9]\d*)*|\d+(?:\s*[,，、]\s*\d+)*)\]",
    re.IGNORECASE,
)
_C_STYLE_MARKER_RE = re.compile(r"C[1-9]\d*", re.IGNORECASE)
_NUMERIC_MARKER_RE = re.compile(r"\d+")
_SENTENCE_BREAKS = "。！？；.!?;\n"
_MAX_FALLBACK_COMPARISON_CHARS = 1200


def _c_style_marker_ids(marker: str) -> list[str]:
    """Return canonical C-style IDs from one already-recognized marker."""
    return [value.upper() for value in _C_STYLE_MARKER_RE.findall(marker)]


def _marker_sentence(draft: str, start: int, end: int) -> tuple[str, str]:
    """Return the marked sentence and a marker-free claim for fallback matching."""

    left = max((draft.rfind(marker, 0, start) for marker in _SENTENCE_BREAKS), default=-1)
    right_positions = [draft.find(marker, end) for marker in _SENTENCE_BREAKS]
    right = min((position for position in right_positions if position >= 0), default=len(draft) - 1)
    sentence = draft[left + 1 : right + 1].strip()
    claim = _DRAFT_MARKER_RE.sub("", sentence).strip()
    return sentence, claim


def _comparison_text(value: str) -> str:
    text, _ = _citation_text_key(value)
    return text[:_MAX_FALLBACK_COMPARISON_CHARS]


def _edit_distance(left: str, right: str) -> int:
    """Bounded Levenshtein distance for choosing among already verified quotes."""

    if len(left) < len(right):
        left, right = right, left
    previous = list(range(len(right) + 1))
    for left_index, left_char in enumerate(left, 1):
        current = [left_index]
        for right_index, right_char in enumerate(right, 1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[right_index] + 1,
                    previous[right_index - 1] + (left_char != right_char),
                )
            )
        previous = current
    return previous[-1]


def _tighten_near_verbatim_span(metadata: dict, claim: str) -> dict:
    """Narrow a verified quote when most of the report claim is copied verbatim.

    The returned text is always an exact subspan of the already verified source
    quote.  Approximate matching only decides whether it is safe to use the
    smaller span; it never manufactures or rewrites citation text.
    """

    quote = str(metadata.get("support_quote") or "")
    claim_key, _ = _citation_text_key(claim)
    quote_key, quote_positions = _citation_text_key(quote)
    if len(claim_key) < 8 or not quote_key:
        return metadata
    match = SequenceMatcher(None, claim_key, quote_key, autojunk=False).find_longest_match(
        0, len(claim_key), 0, len(quote_key)
    )
    if match.size < 8 or match.size / len(claim_key) < 0.60:
        return metadata

    relative_start = quote_positions[match.b]
    relative_end = quote_positions[match.b + match.size - 1] + 1
    narrowed = quote[relative_start:relative_end]
    if not narrowed or len(narrowed) >= len(quote):
        return metadata
    return {
        **metadata,
        "support_quote": narrowed,
        "start_char": int(metadata["start_char"]) + relative_start,
        "end_char": int(metadata["start_char"]) + relative_end,
        "match_method": f'{metadata.get("match_method") or "citation_id_exact"}_near_verbatim',
    }


def _numeric_marker_citation(
    known: dict[str, dict],
    evidence: list[dict],
    evidence_index: int,
    draft: str,
    marker_start: int,
    marker_end: int,
    output_start: int,
    output_end: int,
    occurrence: int,
) -> dict:
    """Map a numeric body marker to a precise, verified quote when possible.

    Models occasionally keep the UI's legacy ``[n]`` marker even after supplying
    valid C-style citation metadata.  The marker still identifies the source, so
    prefer the already verified quote for that source whose text has the shortest
    edit distance from the marked draft sentence.  A numeric marker without such
    metadata remains invalid: source-number fallback must not invent a support
    span or weaken the strict source-quote validation contract.
    """

    if evidence_index < 1 or evidence_index > len(evidence):
        raise APIError(HTTPStatus.BAD_GATEWAY, "Draft contains an unknown source number")

    sentence, claim = _marker_sentence(draft, marker_start, marker_end)
    claim_key = _comparison_text(claim)
    candidates = [
        (key, metadata)
        for key, metadata in known.items()
        if metadata["evidence_index"] == evidence_index
    ]
    if candidates:
        key, metadata = min(
            candidates,
            key=lambda item: _edit_distance(claim_key, _comparison_text(item[1]["support_quote"])),
        )
        metadata = _tighten_near_verbatim_span(metadata, claim)
        return {
            **metadata,
            "id": f"{key}-numeric-{occurrence}",
            "citation_key": key,
            "draft_sentence": sentence or None,
            "draft_start_char": output_start,
            "draft_end_char": output_end,
            "sentence_id": f"numeric-marker-{output_start}",
            "match_method": "numeric_citation_id_fallback_edit_distance",
            "fallback": True,
            "unverified": False,
        }
    raise APIError(
        HTTPStatus.BAD_GATEWAY,
        "Numeric source marker has no verified citation metadata",
    )


def bind_citation_ids(draft, raw, evidence):
    known = resolve_citation_ids(raw, evidence)
    chunks, citations, cursor, size = [], [], 0, 0
    numeric_occurrence = 0
    for match in _DRAFT_MARKER_RE.finditer(draft):
        prefix = draft[cursor:match.start()]
        chunks.append(prefix); size += len(prefix)
        marker_key = match.group(1)
        c_style_keys = _c_style_marker_ids(marker_key)
        if c_style_keys:
            sentence, claim = _marker_sentence(draft, match.start(), match.end())
            resolved = []
            for citation_key in c_style_keys:
                if citation_key not in known:
                    raise APIError(HTTPStatus.BAD_GATEWAY, 'Unknown citation ID in draft')
                resolved.append((citation_key, _tighten_near_verbatim_span(known[citation_key], claim)))
            marker = "[" + ",".join(str(metadata["evidence_index"]) for _, metadata in resolved) + "]"
            for citation_key, metadata in resolved:
                citations.append({**metadata, 'id':f'{citation_key}-{len(citations)+1}', 'citation_key':citation_key, 'draft_sentence':sentence or None, 'draft_start_char':size, 'draft_end_char':size+len(marker), 'sentence_id':f'marker-{size}-{len(citations)+1}'})
        else:
            marker = match.group(0)
            for value in _NUMERIC_MARKER_RE.findall(marker_key):
                numeric_occurrence += 1
                citations.append(
                    _numeric_marker_citation(
                        known,
                        evidence,
                        int(value),
                        draft,
                        match.start(),
                        match.end(),
                        size,
                        size + len(marker),
                        numeric_occurrence,
                    )
                )
        chunks.append(marker); size += len(marker); cursor = match.end()
    chunks.append(draft[cursor:])
    return ''.join(chunks), citations
