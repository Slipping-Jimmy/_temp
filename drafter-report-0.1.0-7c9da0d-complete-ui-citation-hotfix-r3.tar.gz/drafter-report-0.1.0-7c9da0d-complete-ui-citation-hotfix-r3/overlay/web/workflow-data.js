(function () {
  "use strict";
  const eventDefinitions = {
    topic_decomposition_started:["正在拆解題目","等待模型建立較精確的搜尋查詢詞"], topic_decomposition_completed:["題目拆解完成","已建立搜尋查詢詞，準備開始檢索"], retrieval_query_started:["正在檢索資料","執行搜尋並取得命中區段"], retrieval_query_completed:["檢索完成","顯示本次命中區段，以及累計命中區段與去重文件數"],
    agent_planning_started:["正在評估檢索結果","判斷資料是否足夠，或是否需要下一輪搜尋"], agent_decision_search:["需要補充資料","依資料缺口進行下一輪搜尋"], agent_decision_finish:["資料已足夠","停止補充檢索，開始整理原文"], agent_planning_fallback:["沿用目前檢索結果","暫無合適的補充查詢，使用已取得的資料繼續"],
    document_planning_started:["正在評估補讀需求","判斷要結束、追加搜尋，或補讀文件頁面"], document_read_started:["正在補讀文件","取得規劃器指定的完整頁面與上下文"], document_read_completed:["文件補讀完成","納入可用頁面並記錄未讀或不完整範圍"], document_read_failed:["沿用已取得資料","全文 API 失敗時保留搜尋摘要並繼續"], document_read_skipped:["略過文件補讀","決策無效或已達步數、文件、頁數或字數上限"], document_planning_completed:["補讀評估完成","規劃器判定可以結束文件補讀"],
    context_compression_started:["正在整理生成內容","只從已審閱且建議採用的原文單元選取可追溯節錄"], context_compression_completed:["生成內容已整理完成","已選取實際供報告生成的可追溯原文節錄"], evidence_snapshot_loaded:["已載入目前資料來源","沿用目前選取的資料來源重新撰寫"],
    retrieval_hits_collected:["已建立文件審閱清單","顯示本次與累計命中區段，並顯示依文件去重後的數量"], document_review_queue_ready:["建立文件審閱佇列","所有命中文件將逐份讀取 canonical content"], document_review_started:["正在審閱文件","同一次模型呼叫讀取完整或可安全解析頁面並選取語意單元"], document_review_completed:["文件審閱完成","已保留完整文件或可解析頁面的採用／未採用範圍供檢視"], document_review_failed:["文件審閱失敗","取得失敗或無法安全審閱時保留原因，不會靜默略過"], document_review_all_completed:["所有文件處理完成","完整文件與已記錄缺頁的部分文件都已完成處理，才準備報告生成資料"], generation_context_compacted:["生成內容已依字數預算整理","顯示已審閱原文單元與實際供生成節錄的段數、字數"], generation_evidence_ready:["報告生成資料已備妥","顯示實際送入生成的文件數、原文段數與字數"], generation_context_overflow:["生成內容超出預算","不會自動刪除文件；請由操作員明確排除後重試"],
    revision_intent_classified:["判斷修訂是否需要補查","revision_planner 檢查新事實是否已有原文資料支持"], revision_evidence_merged:["整合補充資料","合併原有與新取得的資料；沒有新資料時保留原資料"], revision_drafting_started:["開始修訂報告","依判斷後的資料集合啟動修訂模型"],
    draft_run_ready:["報告資料準備完成","已備妥本次報告使用的資料，即將開始撰寫"], draft_model_started:["模型流程開始","直接切分並固定可定位的原文片段，再撰寫完整報告"], citation_plan_started:["正在準備引用片段","直接依已選原文建立較小的可定位引用 ID，不額外呼叫模型"], citation_plan_ready:["引用片段已備妥","報告階段可從這組來源片段選擇最直接的 ID"], report_generation_started:["開始撰寫完整報告","以固定引用片段啟動報告模型"], draft_generation_started:["正在生成報告","報告正文持續串流到主畫面"], citations_ready:["引用片段已備妥","建立可定位的小範圍原文連結"], citation_validation_warning:["報告已完成，引用待補驗","仍保存正文，但本次沒有可定位的引用連結"], complete:["版本已儲存","完整輸出完成後建立報告版本"], suggestions_started:["產生快速調整選項","依目前報告與資料來源產生修訂建議"], suggestions_completed:["快速調整選項已更新","可點選建議或自行輸入修訂指令"], error:["操作失敗","顯示錯誤，既有報告版本保持不變"]
  };
  const n=(id,title,detail,kind="process",prompts=[])=>({id,title,detail,kind,prompts});
  const b=(label,steps,kind="normal")=>({label,steps,kind});

  const generationTail=(promptName)=>[
    n("draft_model_started","啟動報告生成","先把已選原文切成較小的可定位片段，再以單一模型呼叫撰寫正文。"),
    n("citation_plan_started","固定資料來源引用","不呼叫引用規劃模型；直接為逐字原文片段配置 C1、C2 等固定 ID。","process"),
    n("citation_plan_ready","引用片段已備妥","已將較小的來源原文片段凍結；舊快照不相符時仍以同來源的小片段回退。","success"),
    n("citations_ready","建立精確引用連結","正文開始前先把固定 ID 綁定到資料來源的小範圍原文。","success"),
    n("report_generation_started",promptName==="revision"?"以固定引用修訂完整報告":"以固定引用撰寫完整報告","報告模型只收到固定引用位置，不能新增來源或改寫引用。","prompt",[promptName,"citation_report_format"]),
    n("draft_generation_started","即時串流正文","解析 JSON 的 draft 欄位並持續送到主畫面。","stream",[promptName,"citation_report_format"]),
    {...n("generation_outcome","報告輸出是否可保存？","完成後核對固定 ID；無法建立引用連結時仍保存正文並標示待補驗。","decision"),branches:[
      ...(promptName==="revision"?[]:[b("使用者按下暫停",[n("paused","停止串流並保留畫面內容","初稿與重新生成會保留已顯示文字，但不建立完成版本。","warning")],"warning")]),
      b("模型、串流或格式失敗",[n("model_error","顯示生成失敗","不建立新版本，既有版本保持不變。","failure")],"failure"),
      b("引用可定位",[n("complete","儲存新報告版本","將 C-style ID 轉成畫面來源編號並寫入新版本。","success")],"success"),
      b("引用待補驗",[n("citation_validation_warning","保存正文並標示待補驗","不因引用連結無法驗證而捨棄已完成的報告。","warning"),n("complete","儲存新報告版本","保留正文，讓使用者檢視後可重新生成。","success")],"warning")
    ]}
  ];

  const mandatoryDocumentReviewStage=()=>[
    n("retrieval_hits_collected","記錄所有搜尋 chunk","每個 API 回傳區段先進 ledger，再以 document_id 去重；區段數與文件數分開顯示。"),
    n("document_review_queue_ready","建立每份文件的審閱佇列","沒有 3 份文件或 18 張卡的前置淘汰；所有命中文件都必須處理。"),
    {...n("document_review_started","讀取 canonical 內容並一次式篩選","完整文件讀取全文；來源缺頁時只讀取上游標為 complete 的頁面。document_relevance_filter 在同一個 LLM 呼叫判斷相關性並以 line ID 選取完整 Q&A／段落。超長文件以完整頁批次覆蓋。","prompt",["document_relevance_filter"]),branches:[
      b("範圍有效",[n("document_review_completed","保留可信語意原文","後端只依 trusted line ID 還原逐字內容；來源不完整時不得跨越缺頁，僅保留成功解析頁面。未採用範圍仍供 UI 檢視與使用者加入。","success")],"success"),
      b("取得／審閱失敗",[n("document_review_failed","停止自動生成並保留 audit","fetch_failed 或 review_failed 不會靜默略過文件。","failure")],"failure")
    ]},
    {...n("document_review_all_completed","所有命中文件已完成處理？","完整審閱與 source_incomplete 的可解析頁面都可繼續；只有 fetch_failed／review_failed 會阻斷。","decision"),branches:[
      b("符合預算",[n("generation_evidence_ready","送入已審閱的採用單元","完整或安全解析頁面直接送入 Draft。","success")],"success"),
      b("超出預算",[n("generation_context_compacted","以可引用原文節錄壓縮","只從已審閱且採用的單元選取原文節錄；完整審閱 ledger 仍保留。", "warning"),n("generation_evidence_ready","送入可追溯的原文節錄","顯示實際用於生成的文件與段數。","success")],"warning"),
      b("取得／審閱失敗",[n("retrieval_incomplete","停止自動生成","保留文件清單、失敗原因及重試入口。","failure")],"failure"),
      b("壓縮無可用內容",[n("generation_context_overflow","要求使用者明確排除","僅在可引用原文節錄仍無法符合預算時停止。","warning")],"warning")
    ]}
  ];
  const plannerSearchStage=()=>[
    {...n("agent_planning_started","LLM 補查判斷（最多{agentic_retrieval_max_rounds}輪）","只有文件補讀關閉時才使用這條一般補查路徑。初始查詢算第 1 輪；LLM 只可提出 1 個未重複且不超過 400 字的下一輪 query。","prompt",["retrieval_planner"]),branches:[
      b("action = search",[n("agent_decision_search","執行下一輪搜尋","有效且未重複的查詢回到搜尋階段，直到 {agentic_retrieval_max_rounds} 輪上限。","loop")],"loop"),
      b("action = finish",[n("agent_decision_finish","使用目前候選資料","規劃器判定資料已足夠。","success")],"success"),
      b("模型失效／查詢無效或重複",[n("agent_planning_fallback","沿用目前候選資料","不中止流程，改用已取得的搜尋結果。","fallback")],"fallback")
    ]}
  ];
  const retrievalTree=[
    n("agentic_retrieval_setting","LLM 檢索：{agentic_retrieval_enabled}","此流程目前顯示的是啟用時的拆解、補讀與原文資料整理路徑。若關閉，程式會以原題只做一次 API 搜尋，略過所有 LLM 檢索步驟。","input"),
    n("topic_decomposition","LLM 拆解題目 → 最多{topic_query_cap}個 query","topic_decomposer 會把報告題目拆成獨立查詢。雖然目前 Prompt 要求 1–5 個關鍵詞，程式會去重、排序後只保留 {topic_query_cap} 個；模型無效時直接使用原題。","prompt",["topic_decomposer"]),
    n("retrieval_query_started","API：{reference_search_top_k}筆／無 score 門檻","每個拆解後的 query 都呼叫備參資料 API，傳送 top_k={reference_search_top_k}。結果依 relevance 排序，但現行沒有 threshold 過濾，score 不會直接淘汰結果。"),
    {...n("retrieval_result","搜尋服務有可用結果？","搜尋可能成功、部分失敗或全部失敗。","decision"),branches:[
      b("全部失敗且無資料",[n("retrieval_error","停止並顯示資料來源失敗","沒有原文資料可供生成，因此不建立報告版本。","failure")],"failure"),
      b("有候選資料",[
        ...mandatoryDocumentReviewStage()
      ],"success")
    ]}
  ];

  const initialRetrievalTree=JSON.parse(JSON.stringify(retrievalTree));
  const initialRetrievalResult=initialRetrievalTree.find(item=>item.id==="retrieval_result");
  initialRetrievalResult.branches[1].steps.push(n("draft_run_ready","建立本次報告任務","固定整理後的原文資料並建立任務。","success"),...generationTail("draft"));
  const revisionRetrievalTree=JSON.parse(JSON.stringify(retrievalTree.slice(1)));
  const revisionRetrievalResult=revisionRetrievalTree.find(item=>item.id==="retrieval_result");
  revisionRetrievalResult.branches[0]=b("全部失敗或沒有新資料",[n("revision_search_fallback","標記資料缺口並沿用原文資料","補查結果不會覆蓋或丟棄既有資料，流程仍會進入修訂。","fallback")],"fallback");

  const standaloneCompressionStage=()=>mandatoryDocumentReviewStage();
  const standaloneDocumentAgentStage=()=>[
    {...n("agentic_document_step_budget","尚有文件規劃步驟？","內網 DOCUMENT_RETRIEVAL_MAX_STEPS={document_retrieval_max_steps}；每次規劃的 finish、search、read_document 或無效決策都會消耗一個步驟。","decision"),branches:[
      b("步數已用完",[n("agentic_document_steps_exhausted","以目前候選資料繼續","達到規劃步數上限後停止補查／補讀，進入原文資料整理。","fallback")],"fallback"),
      b("仍有步數",[
        {...n("agentic_document_planning","決定：結束／補搜／讀全文","document_retrieval_planner 會看到目前候選、歷史、已搜尋 query 與剩餘的步數、文件、頁數、字數預算。","prompt",["document_retrieval_planner"]),branches:[
          b("finish",[n("agentic_document_finish","結束文件代理","規劃器判定目前資料已足夠，進入原文資料整理。","success")],"success"),
          b("search",[
            {...n("agentic_document_search_valid","補搜 query 有效且未重複？","query 必須是非空、未搜尋過且不超過 400 字。","decision"),branches:[
              b("有效",[n("agentic_document_search_api","追加搜尋：Top {reference_search_top_k}","呼叫備參資料 API；結果以 chunk_id 去重後加入候選集合，現行沒有 similarity threshold。"),n("agentic_document_search_again","回到下一個文件規劃步驟","本次 search 已消耗一個規劃步驟。","loop")],"success"),
              b("無效或重複",[n("agentic_document_search_rejected","記錄無效 query","不呼叫搜尋 API，但本次規劃步驟仍已消耗。","fallback"),n("agentic_document_search_rejected_again","回到下一個文件規劃步驟","由下一步重新評估目前候選資料。","loop")],"fallback")
            ]}
          ],"loop"),
          b("read_document",[
            {...n("agentic_document_read_valid","文件 ID、頁碼與預算可用？","只能讀取搜尋結果中已有的 document_id；全文總預算為 {document_retrieval_max_documents} 份、{document_retrieval_max_pages} 頁、{document_retrieval_max_chars} 字。","decision"),branches:[
              b("字數或頁數已滿",[n("agentic_document_read_limit","停止全文補讀","使用已取得的搜尋摘要與完整頁面，進入原文資料整理。","fallback")],"fallback"),
              b("ID／頁碼無效或新文件超額",[n("agentic_document_read_rejected","記錄限制並略過讀取","不讀取文件；下一個規劃步驟可改選其他文件或動作。","fallback"),n("agentic_document_read_rejected_again","回到下一個文件規劃步驟","重新評估尚可用的文件與預算。","loop")],"fallback"),
              b("可讀取",[
                n("agentic_document_read","讀取 canonical 全文","若整份文件超出剩餘預算，document_page_selector 會依需求挑頁；加入的每段原文仍保持逐字內容。","prompt",["document_page_selector"]),
                {...n("agentic_document_read_outcome","全文 API 讀取成功？","同一文件每次 run 只抓取一次，失敗結果也會快取，避免重試。","decision"),branches:[
                  b("成功",[n("agentic_document_pages_added","完整頁面置於候選前方","記錄已讀、略過與不完整頁面，讓完整頁面優先進入 18 張候選卡。","success"),n("agentic_document_read_again","回到下一個文件規劃步驟","可繼續 finish、補搜或讀取其他文件。","loop")],"success"),
                  b("全文 API 失敗",[n("agentic_document_read_failed","保留搜尋摘要","記錄資料缺口，不丟棄原搜尋結果。","fallback"),n("agentic_document_read_failed_again","回到下一個文件規劃步驟","由下一步依剩餘候選繼續判斷。","loop")],"fallback")
                ]}
              ],"success")
            ]}
          ]),
          b("無效決策",[n("agentic_document_invalid","沿用目前候選資料","規劃器未回傳 finish、search 或 read_document 時停止文件代理。","fallback")],"fallback")
        ]}
      ],"success")
    ]},
    ...standaloneCompressionStage()
  ];
  const standaloneGeneralAgentStage=()=>[
    {...n("agentic_general_round_budget","尚有一般補查輪次？","只有文件補讀關閉時才使用。內網 AGENTIC_RETRIEVAL_MAX_ROUNDS={agentic_retrieval_max_rounds}，初始搜尋已算第 1 輪。","decision"),branches:[
      b("輪次已用完",[n("agentic_general_rounds_exhausted","以目前候選資料繼續","達到一般補查上限，進入原文資料整理。","fallback")],"fallback"),
      b("仍有輪次",[
        {...n("agentic_general_planning","判斷是否需要下一輪搜尋","retrieval_planner 可輸出 finish，或提出 1 個非空、未重複且不超過 400 字的 query。","prompt",["retrieval_planner"]),branches:[
          b("action = finish",[n("agentic_general_finish","使用目前候選資料","規劃器判定資料已足夠。","success")],"success"),
          b("action = search",[n("agentic_general_search_api","執行下一輪搜尋：Top {reference_search_top_k}","新增結果會與目前候選資料合併、去重；現行沒有 similarity threshold。"),n("agentic_general_search_again","回到一般補查判斷","完成一輪搜尋後重新檢查輪次與資料充分性。","loop")],"loop"),
          b("模型失效／query 無效或重複",[n("agentic_general_fallback","沿用目前候選資料","不再搜尋，直接進入原文資料整理。","fallback")],"fallback")
        ]}
      ],"success")
    ]},
    ...standaloneCompressionStage()
  ];

  const flowsById=[
    {id:"manual-search",title:"搜尋資料來源",location:{area:"資料來源",control:"搜尋資料來源（放大鏡）",hint:"右欄資料來源標題列"},width:"medium",trigger:"「資料來源」→ 點放大鏡 → 輸入關鍵字 → 按 Enter",summary:"只更新資料來源清單，不呼叫語言模型。",steps:[
      n("manual_trigger","執行「搜尋資料來源」","使用資料來源搜尋框的文字搜尋備參資料。","input"),
      n("manual_query_passthrough","關鍵字不拆解／不改寫","手動輸入的關鍵字不會經過 LLM topic_decomposer；驗證後以原字串直接送往備參資料 API。","input"),
      {...n("manual_input","關鍵字有效？","空白內容不送出請求。","decision"),branches:[
        b("空白",[n("manual_noop","留在原畫面","不送出 API，也不變更資料來源。","warning")],"warning"),
        b("有效",[n("manual_api","API：{reference_search_top_k}筆／無 score 門檻","以原始關鍵字呼叫 API，top_k={reference_search_top_k}。結果按 relevance 排序，沒有 threshold 過濾。"),{...n("manual_result","搜尋成功？","依 API 回應更新主畫面。","decision"),branches:[b("成功",[n("manual_done","顯示搜尋結果","可排除資料，再重新生成報告。","success")],"success"),b("失敗",[n("manual_failed","顯示搜尋失敗","保留原資料來源，不進入生成。","failure")],"failure")]}],"success")
      ]}
    ]},
    {id:"new-draft",title:"檢索並生成詳細報告",location:{area:"報告題目",control:"檢索並生成詳細報告（▶）",hint:"左欄最上方報告題目標題列"},width:"wide",trigger:"「報告題目」→ 點 ▶「檢索並生成詳細報告」，或在題目輸入框按 Enter",summary:"重新檢索、補讀、整理原文資料，接著一次生成並即時串流。",phases:[{label:"前置檢查",node:"draft_precheck"},{label:"拆解／查詢",node:"topic_decomposition"},{label:"補讀文件",node:"document_planning_started"},{label:"整理原文資料",node:"context_compression_started"},{label:"生成與引用",node:"draft_model_started"},{label:"儲存版本",node:"complete"}],steps:[
      {...n("draft_precheck","題目與資料來源可用？","前端先檢查題目與至少一個保留的資料來源。","decision"),branches:[
        b("題目空白",[n("draft_noop","不啟動流程","留在報告題目輸入框。","warning")],"warning"),
        b("沒有保留資料來源",[n("draft_no_corpus","顯示「無資料來源」","要求至少保留一個資料來源。","failure")],"failure"),
        b("條件成立",initialRetrievalTree,"success")
      ]}
    ]},
    {id:"regenerate",title:"以更新後資料重新生成報告",location:{area:"資料來源",control:"以更新後資料重新生成報告（↻）",hint:"右欄資料來源標題列"},width:"medium",trigger:"「資料來源」→ 點 ↻「以更新後資料重新生成報告」",summary:"沿用畫面目前保留的資料來源，不重新搜尋或補讀。",phases:[{label:"載入快照",node:"evidence_snapshot_loaded"},{label:"生成與引用",node:"draft_model_started"},{label:"儲存版本",node:"complete"}],steps:[
      {...n("regenerate_precheck","有題目與可用資料？","按鈕只有在目前原文資料可用時才啟用。","decision"),branches:[
        b("沒有資料",[n("regenerate_disabled","按鈕停用","提示「尚未搜尋或無可用資料來源」。","warning")],"warning"),
        b("有資料",[{...n("evidence_snapshot_loaded","載入目前原文資料快照","依伺服器核發的資料編號與既有任務載入可信資料。"),branches:[
          b("快照或任務無效",[n("snapshot_error","顯示重新生成失敗","找不到快照、任務或原文資料時不建立版本。","failure")],"failure"),
          b("載入成功",[n("draft_run_ready","更新既有報告任務","固定本次沿用的原文資料。","success"),...generationTail("draft")],"success")
        ]}],"success")
      ]}
    ]},
    {id:"revision",title:"快速調整報告",location:{area:"快速調整",control:"建議按鈕／修訂指令輸入框",hint:"左欄最下方快速調整區塊"},width:"wide",trigger:"「快速調整」→ 點選建議，或輸入修訂指令後按 Enter",summary:"同一入口先由 revision_planner 判斷，再分流為直接修訂或補查後修訂。",phases:[{label:"判斷",node:"revision_intent_classified"},{label:"補查（如需要）",node:"revision_retrieval_started"},{label:"修訂與引用",node:"revision_drafting_started"},{label:"儲存版本",node:"complete"}],steps:[
      {...n("revision_precheck","已有報告內容？","沒有報告時不能直接修訂。","decision"),branches:[
        b("沒有報告",[n("revision_to_request","把指令補入「報告題目」","提示先執行「檢索並生成詳細報告」。","fallback")],"fallback"),
        b("已有報告",[
          {...n("revision_intent_classified","是否需要補充新事實？","讀取需求、現有報告與原文資料，判斷是否需要補查。","decision",["revision_planner"]),branches:[
            b("不需要補查",[n("revision_local","直接使用現有原文資料","純結構、語氣、排序或資料已足夠時不搜尋。","success",["revision_planner"])],"success"),
            b("需要補查",[n("revision_retrieval_started","使用規劃器查詢補充資料","最多三個 search_queries；未提供時使用完整修訂指令。","prompt",["revision_planner","topic_decomposer"]),...revisionRetrievalTree,n("revision_evidence_merged","合併原有與補充原文資料","補查失敗或無結果時標記缺口並保留原資料。","fallback")],"success"),
            b("規劃器失效／JSON 無效",[n("revision_plan_fallback","沿用既有原文資料修訂","現行程式將改為不補查，不啟動額外搜尋。","fallback",["revision_planner"])],"fallback")
          ]},
          n("revision_drafting_started","開始修訂報告","所有分支在此匯合，先固定最後原文資料集合的來源位置，再進行完整修訂。"),
          ...generationTail("revision").filter(x=>x.id!=="draft_model_started")
        ],"success")
      ]}
    ]},
    {id:"suggestions",title:"更新快速調整選項",location:{area:"快速調整",control:"系統自動更新建議按鈕",hint:"左欄最下方快速調整區塊"},width:"medium",trigger:"完成「檢索並生成詳細報告」或「快速調整報告」後自動執行",summary:"模型建議失敗時改用 prompts.yaml 的固定備援選項。",phases:[{label:"模型建議",node:"suggestions_started"},{label:"顯示選項",node:"suggestions_result"}],steps:[
      n("suggestions_started","產生快速調整建議","依題目、目前報告與原文資料產生 6–8 個選項。","prompt",["suggestions"]),
      {...n("suggestions_result","模型回傳有效選項？","只接受可解析且非空的選項。","decision"),branches:[
        b("有效",[n("suggestions_completed","顯示模型建議","出現在主畫面的「快速調整」區塊。","success")],"success"),
        b("失敗或無效",[n("suggestions_fallback","顯示固定備援建議","報告不受影響，使用 fallback_suggestions；可在此編輯預設的快速調整選項。","fallback",["fallback_suggestions"])],"fallback")
      ]}
    ]},
    {id:"agentic-retrieval",title:"Agentic Retrieval 完整流程",location:{area:"流程管理",control:"獨立檢索架構圖",hint:"說明系統內部機制，不對應主畫面按鈕"},width:"wide",trigger:"系統在「檢索並生成詳細報告」或需補查的快速調整中執行",summary:"v0.1.0 從每個搜尋命中的 chunk 建立文件 ledger，逐份讀取 canonical content；來源不完整時僅使用成功解析頁面，並在同一 LLM 呼叫選取可信語意單元。",phases:[{label:"拆題／搜尋",node:"agentic_topic_decomposition"},{label:"命中 ledger",node:"retrieval_hits_collected"},{label:"文件審閱",node:"document_review_started"},{label:"範圍驗證",node:"document_review_completed"},{label:"生成 gate",node:"generation_evidence_ready"},{label:"輸出",node:"agentic_retrieval_ready"}],steps:[
      n("agentic_topic_decomposition","建立查詢詞","啟用 Agentic 時 topic_decomposer 產生最多 {topic_query_cap} 個 query；關閉時使用原題，但兩者都必須處理每份命中文件。","prompt",["topic_decomposer"]),
      n("agentic_initial_search","每個 query 搜尋 Top {reference_search_top_k}","每次 API 回傳的每一個 chunk 都先保存；沒有 similarity threshold。"),
      n("retrieval_hits_collected","建立搜尋 hit ledger","以 (corpus, document_id) 去重為候選文件，但每個 chunk/query/score/page 關聯保留在 audit。"),
      n("document_review_queue_ready","所有命中文件進入佇列","沒有 document count、page count、18 card 或 context-compressor 的靜默淘汰。"),
      {...n("document_review_started","一次式文件審閱","一般文件把完整 canonical line catalogue 交給 document_relevance_filter；來源不完整時只交可解析頁面，模型同時判斷相關性並回傳 line-ID 範圍。","prompt",["document_relevance_filter"]),branches:[
        b("有效範圍",[n("document_review_completed","還原可信 Q&A／段落","後端只從 trusted canonical text 還原原文；缺頁時不得跨頁，related、possibly 與 not relevant 皆保留可檢視單元。","success")],"success"),
        b("JSON／ID 無效",[n("document_review_repair","同一全文修復一次","修復仍失敗時僅在全文可 fit 時 safe fallback；否則保留 review_failed。","warning",["document_relevance_filter"])],"warning")
      ]},
      n("document_review_all_completed","完成所有文件處理後才補搜","follow-up planner 僅讀 bounded review cards；完整或部分可解析來源均記錄 scope，若 search 發現新文件，重複審閱 gate。"),
      {...n("generation_evidence_ready","生成前字數 gate","超出字數時，只從已審閱採用單元萃取可引用的原文節錄；不會重新搜尋或採用未審閱內容。","decision"),branches:[
        b("fit 或節錄完成",[n("agentic_retrieval_ready","交給報告生成","報告生成原文與引用索引分開；UI 仍能檢視所有找到的文件。","success")],"success"),
        b("節錄仍無法符合",[n("generation_context_overflow","等待使用者明確排除","顯示全部文件與單元，重新生成只提交伺服器核發的資料編號。","warning")],"warning"),
        b("取得／審閱失敗",[n("agentic_retrieval_failed","停止自動生成","fetch_failed 或 review_failed 會保留 audit；source_incomplete 則只使用已成功解析頁面並繼續。","failure")],"failure")
      ]}
    ]}
  ];

  const orderedFlowIds=["new-draft","manual-search","regenerate","revision","suggestions","agentic-retrieval"];
  const flows=orderedFlowIds.map((id)=>flowsById.find((flow)=>flow.id===id));

  function statusForEvent(event,data={}){let key=event;if(event==="agent_decision")key=data.action==="search"?"agent_decision_search":"agent_decision_finish";const definition=eventDefinitions[key];return definition?{title:definition[0],detail:definition[1],activity:key}:null;}
  window.DrafterWorkflow={eventDefinitions,flows,statusForEvent};
})();
