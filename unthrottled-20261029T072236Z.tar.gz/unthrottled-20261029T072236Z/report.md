# Unthrottled load test: unthrottled-20261029T072236Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_50c | sse_burst | 50 | 150 | 150 | 150 | 0.00 | 150 | 100.00 | 0 | 0 | 7226.0 | 8364.4 | 8424.3 | 59.8 |
| stage_002_sse_burst_100c | sse_burst | 100 | 300 | 300 | 232 | 22.67 | 232 | 100.00 | 0 | 0 | 12067.7 | 14188.0 | 14293.1 | 138.4 |
  - errors: `{"sse_no_content": 68}`
| stage_003_sse_burst_150c | sse_burst | 150 | 450 | 450 | 166 | 63.11 | 166 | 100.00 | 0 | 0 | 12215.8 | 15220.1 | 15293.7 | 248.0 |
  - errors: `{"sse_no_content": 282, "sse_record_save_error": 2}`
| stage_004_sse_burst_200c | sse_burst | 200 | 600 | 600 | 532 | 11.33 | 532 | 100.00 | 0 | 0 | 24446.1 | 31662.2 | 32207.3 | 346.6 |
  - errors: `{"sse_no_content": 67, "sse_record_save_error": 1}`
| stage_005_sse_burst_250c | sse_burst | 250 | 750 | 750 | 269 | 64.13 | 269 | 100.00 | 0 | 0 | 22563.2 | 28070.7 | 28335.1 | 431.6 |
  - errors: `{"sse_no_content": 477, "sse_record_save_error": 4}`
| stage_006_sse_burst_300c | sse_burst | 300 | 900 | 900 | 755 | 16.11 | 755 | 100.00 | 0 | 0 | 35301.8 | 43164.5 | 43925.6 | 544.6 |
  - errors: `{"sse_no_content": 145}`
| stage_007_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 535 | 49.05 | 535 | 100.00 | 0 | 0 | 36404.9 | 44752.3 | 45397.9 | 602.0 |
  - errors: `{"sse_model_communication_error": 1, "sse_no_content": 494, "sse_record_save_error": 20}`
| stage_008_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 843 | 29.75 | 843 | 100.00 | 101 | 0 | 49837.9 | 67383.7 | 68302.6 | 710.3 |
  - errors: `{"sse_model_communication_error": 2, "sse_no_content": 339, "sse_record_save_error": 16}`
  - 60-second cutoff candidates: **101**
  - timeout basis: `{"first_token": 101}`
| stage_009_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 836 | 38.07 | 836 | 100.00 | 189 | 0 | 54475.2 | 73657.8 | 74602.6 | 849.8 |
  - errors: `{"sse_model_communication_error": 2, "sse_no_content": 493, "sse_record_save_error": 19}`
  - 60-second cutoff candidates: **189**
  - timeout basis: `{"first_token": 189}`
| stage_010_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 7 | 99.53 | 7 | 100.00 | 0 | 0 | 23412.0 | 29428.0 | 29908.0 | 711.3 |
  - errors: `{"sse_no_content": 1460, "sse_record_save_error": 33}`

## 60-second cutoff boundary

The first cutoff candidate occurred at **stage_008_sse_burst_400c** (target=400, count=101).

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received SSE lines with elapsed times and chat IDs, including blank event separators, event names and completion markers. Wire-line counters distinguish empty responses from heartbeat-only streams.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.

## All-request first-token timing

Includes failed requests that received content. Requests without a first token are counted separately, not assigned zero latency.

| Target | First token received | No first token | TTFT >60s | Mean ms | p95 ms | Max ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 50 | 150 | 0 | 0 | 5904.5 | 8232.2 | 8336.3 |
| 100 | 232 | 68 | 0 | 10813.5 | 13595.4 | 13903.4 |
| 150 | 168 | 282 | 0 | 11067.6 | 14466.1 | 14591.5 |
| 200 | 533 | 67 | 0 | 21352.0 | 29503.4 | 30627.0 |
| 250 | 273 | 477 | 0 | 19942.5 | 26851.7 | 27293.9 |
| 300 | 755 | 145 | 0 | 30960.3 | 41122.0 | 41931.9 |
| 350 | 555 | 495 | 0 | 31683.2 | 43142.7 | 43740.4 |
| 400 | 859 | 341 | 101 | 42650.7 | 64028.2 | 65961.5 |
| 450 | 855 | 495 | 187 | 47019.7 | 70343.9 | 72586.1 |
| 500 | 40 | 1460 | 0 | 19290.2 | 31898.0 | 32279.6 |
