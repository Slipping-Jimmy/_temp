# Unthrottled load test: unthrottled-20261027T092050Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_100c | sse_burst | 100 | 300 | 300 | 76 | 74.67 | 45 | 59.21 | 0 | 0 | 10942.9 | 12132.0 | 12265.9 | 171.3 |
  - errors: `{"sse_no_content": 224}`
| stage_002_sse_burst_150c | sse_burst | 150 | 450 | 450 | 62 | 86.22 | 32 | 51.61 | 0 | 0 | 13765.2 | 14388.0 | 17168.5 | 268.0 |
  - errors: `{"sse_no_content": 386, "sse_record_save_error": 2}`
| stage_003_sse_burst_200c | sse_burst | 200 | 600 | 600 | 0 | 100.00 | 0 | 0.00 | 0 | 0 | N/A | N/A | N/A | 299.5 |
  - errors: `{"sse_no_content": 595, "sse_record_save_error": 5}`
| stage_004_sse_burst_250c | sse_burst | 250 | 750 | 750 | 5 | 99.33 | 4 | 80.00 | 0 | 0 | 19794.3 | 20160.8 | 20199.0 | 378.7 |
  - errors: `{"sse_no_content": 739, "sse_record_save_error": 6}`
| stage_005_sse_burst_300c | sse_burst | 300 | 900 | 900 | 45 | 95.00 | 20 | 44.44 | 0 | 0 | 23050.4 | 26447.3 | 27325.7 | 472.6 |
  - errors: `{"sse_no_content": 823, "sse_record_save_error": 32}`
| stage_006_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 58 | 94.48 | 19 | 32.76 | 0 | 0 | 28391.9 | 30764.8 | 30808.4 | 633.3 |
  - errors: `{"sse_no_content": 962, "sse_record_save_error": 30}`
| stage_007_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 12 | 99.00 | 5 | 41.67 | 0 | 0 | 30416.0 | 32931.1 | 32941.7 | 671.1 |
  - errors: `{"sse_no_content": 1147, "sse_record_save_error": 41}`
| stage_008_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 677 | 49.85 | 218 | 32.20 | 196 | 0 | 65708.0 | 107529.3 | 127431.0 | 821.0 |
  - errors: `{"sse_error_event": 86, "sse_model_communication_error": 3, "sse_no_content": 570, "sse_record_save_error": 14}`
  - 60-second cutoff candidates: **196**
  - timeout basis: `{"first_token": 196}`
| stage_009_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 1 | 99.93 | 1 | 100.00 | 0 | 0 | 79149.9 | 79149.9 | 79149.9 | 956.3 |
  - errors: `{"sse_no_content": 1477, "sse_record_save_error": 22}`

## 60-second cutoff boundary

The first cutoff candidate occurred at **stage_008_sse_burst_450c** (target=450, count=196).

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received SSE lines with elapsed times and chat IDs, including blank event separators, event names and completion markers. Wire-line counters distinguish empty responses from heartbeat-only streams.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.

## All-request first-token timing

Includes failed requests that received content. Requests without a first token are counted separately, not assigned zero latency.

| Target | First token received | No first token | TTFT >60s | Mean ms | p95 ms | Max ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 100 | 76 | 224 | 0 | 10296.3 | 11751.6 | 11768.9 |
| 150 | 64 | 386 | 0 | 12790.0 | 13847.0 | 13855.3 |
| 200 | 5 | 595 | 0 | 6980.5 | 8234.9 | 8239.5 |
| 250 | 11 | 739 | 0 | 12594.8 | 16898.5 | 16942.0 |
| 300 | 77 | 823 | 0 | 18999.3 | 25944.1 | 26093.5 |
| 350 | 88 | 962 | 0 | 23090.8 | 29993.9 | 30174.8 |
| 400 | 53 | 1147 | 0 | 21228.1 | 29593.4 | 29689.4 |
| 450 | 777 | 573 | 196 | 49000.0 | 72183.0 | 75176.3 |
| 500 | 23 | 1477 | 0 | 19698.0 | 30264.2 | 30396.8 |
