const state = {
  runId: null,
  selectedRating: null,
  evidence: [],
  reviewedEvidence: [],
  retrievalAudit: {},
  documentAuditFilter: "all",
  retrievalAuditDetailsOpen: false,
  hasPendingEvidenceSelection: false,
  evidenceSnapshotId: null,
  activeEvidenceCorpus: "reference",
  busyCount: 0,
  suggestions: [],
  suggestionRequestVersion: 0,
  drafts: [],
  selectedDraftId: null,
  diffMode: true,
  compareMode: false,
  highlightedEvidence: null,
  highlightedCitationId: null,
  highlightText: "",
  highlightTerms: [],
  queryHighlightTerms: [],
  citations: [],
  draftFontSize: 13,
  versionLabels: {},
  comparisonBaseVersion: null,
  excludedCorpuses: new Set(),
  commandReferences: new Map(),
  pendingReference: null,
  theme: "light",
  uiText: {},
  statusHistory: [],
  catAnimationEnabled: false,
  performanceModeEnabled: false,
  animationsEnabled: true,
  activeAbortController: null,
  draftPreviewStop: null,
  isPaused: false,
};

const $ = (id) => document.getElementById(id);
const DRAFT_SOURCE_CORPUSES = ["reference"];

function updateCatVisibility() {
  const catEl = $("statusCatAssistant");
  if (catEl) catEl.hidden = !state.catAnimationEnabled || !state.animationsEnabled;
}

function bindCatControls() {
  const catEl = $("statusCatAssistant");
  if (catEl) {
    let pounceTimer = null;
    catEl.addEventListener("click", () => {
      if (!state.catAnimationEnabled || !state.animationsEnabled) return;
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      window.clearTimeout(pounceTimer);
      catEl.classList.remove("is-pouncing");
      void catEl.offsetWidth;
      catEl.classList.add("is-pouncing");
      pounceTimer = window.setTimeout(() => catEl.classList.remove("is-pouncing"), 600);
    });
  }
}

function sourceCorpusOrder() {
  const tabs = [...document.querySelectorAll(".source-tab[data-corpus]")];
  const corpuses = tabs.map((tab) => tab.dataset.corpus).filter((corpus) => DRAFT_SOURCE_CORPUSES.includes(corpus));
  return corpuses.length ? [...new Set(corpuses)] : DRAFT_SOURCE_CORPUSES;
}

function includedDraftCorpuses() {
  return sourceCorpusOrder().filter((corpus) => !state.excludedCorpuses.has(corpus));
}

function firstIncludedCorpus() {
  return includedDraftCorpuses()[0] || null;
}

function usableCurrentEvidence() {
  return state.evidence.filter((item) => {
    const corpus = item?.corpus || "reference";
    return DRAFT_SOURCE_CORPUSES.includes(corpus) && !state.excludedCorpuses.has(corpus);
  });
}

function reviewedEvidenceById() {
  return new Map((state.reviewedEvidence || []).map((item) => [item.evidence_id, item]));
}

function evidenceIdsInGeneration() {
  return new Set((state.evidence || []).map((item) => item.evidence_id));
}

function corpusDisplayName() {
  return "備參資料";
}

function setTemporaryStatus(statusState, title, detail) {
  setOperationState({ state: statusState, title, detail, progress: 100 });
  window.setTimeout(() => {
    if (state.busyCount === 0) {
      setOperationState({
        state: "idle",
        title: "待命",
        detail: "可繼續搜尋資料、生成詳細報告或送出回饋",
        progress: 0,
      });
    }
  }, 2200);
}

const MAX_STATUS_HISTORY = 100;

function recordStatus(stateName, title, detail) {
  const last = state.statusHistory[0];
  if (last && last.type !== "divider" && last.state === stateName && last.title === title && last.detail === detail) return;
  state.statusHistory.unshift({ type: "item", state: stateName, title, detail, time: new Date() });
  if (state.statusHistory.length > MAX_STATUS_HISTORY) {
    state.statusHistory = state.statusHistory.slice(0, MAX_STATUS_HISTORY);
  }
  renderStatusHistory();
}

function renderStatusHistory() {
  const list = $("statusHistoryList");
  if (!list) return;
  list.replaceChildren();
  if (!state.statusHistory.length) {
    const empty = document.createElement("p");
    empty.className = "status-history-empty";
    empty.textContent = state.uiText.status_history_empty || "尚無狀態紀錄";
    list.append(empty);
    return;
  }
  for (const item of state.statusHistory) {
    if (item.type === "divider") {
      const divider = document.createElement("div");
      divider.className = "status-history-divider";
      const titleSpan = document.createElement("span");
      titleSpan.textContent = `── 操作：${item.title || "新操作"} ──`;
      const timeSpan = document.createElement("time");
      timeSpan.textContent = item.time.toLocaleTimeString("zh-TW", { hour12: false });
      divider.append(titleSpan, timeSpan);
      list.append(divider);
      continue;
    }
    const row = document.createElement("article");
    row.className = `status-history-item ${item.state}`;
    const title = document.createElement("strong");
    title.textContent = item.title;
    const detail = document.createElement("span");
    detail.textContent = item.detail;
    const time = document.createElement("time");
    time.textContent = item.time.toLocaleTimeString("zh-TW", { hour12: false });
    row.append(title, detail, time);
    list.append(row);
  }
}

function setStatusHistoryOpen(open) {
  const panel = $("statusPanel");
  const history = $("statusHistory");
  if (!panel || !history) return;
  panel.classList.toggle("expanded", open);
  panel.setAttribute("aria-expanded", String(open));
  history.hidden = !open;
  $("topbar")?.classList.toggle("status-history-open", open);
}

function setOperationState({ state: statusState = "idle", title = "待命", detail = "", progress = 0, indeterminate = false }) {
  const panel = $("statusPanel");
  const bar = $("progressBar");
  panel.className = `status-panel ${statusState}`;
  $("statusTitle").textContent = title;
  $("statusDetail").textContent = detail;
  $("statusDetail").title = detail;
  bar.className = indeterminate ? "progress-bar indeterminate" : "progress-bar";
  bar.style.width = indeterminate ? "" : `${Math.max(0, Math.min(100, progress))}%`;
  const isRunning = statusState === "running";
  document.body.classList.toggle("is-generating", isRunning);
  setQuickActionsDisabled(state.busyCount > 0);
  const catActive = state.catAnimationEnabled && state.animationsEnabled && isRunning;
  $("statusCatAssistant")?.classList.toggle("is-active", catActive);
  $("topbar")?.classList.toggle("cat-active", catActive);
  const activeJobLabel = $("activeJobLabel");
  if (activeJobLabel) {
    activeJobLabel.textContent = isRunning ? title : "idle";
    activeJobLabel.classList.toggle("running", isRunning);
  }
  recordStatus(statusState, title, detail);
}

function applyFeatureFlags(features) {
  state.catAnimationEnabled = features?.cat_animation_enabled === true;
  state.performanceModeEnabled = features?.performance_mode_enabled === true;
  state.animationsEnabled = features?.animations_enabled !== false;
  document.body.classList.toggle("performance-mode", state.performanceModeEnabled);
  document.body.classList.toggle("no-animations", !state.animationsEnabled);
  updateCatVisibility();
  $("statusCatAssistant")?.classList.remove("is-active", "is-pouncing");
  $("topbar")?.classList.remove("cat-active");
}

function applyUiText(texts) {
  state.uiText = texts;
  document.title = texts.browser_title;
  const setText = (id, value) => {
    const element = $(id);
    if (element) element.textContent = value;
  };
  setText("browserTitle", texts.browser_title);
  setText("appTitle", texts.app_title);
  setText("organizationName", texts.organization_name);
  setText("organizationUnit", texts.organization_unit);
  setText("versionLabel", texts.version_label);
  const requestInput = $("requestInput");
  if (requestInput) {
    requestInput.value = texts.default_request;
    updateCharCounter(requestInput);
  }
  setText("statusHistoryTitle", texts.status_history_title);
  $("statusHistory")?.setAttribute("aria-label", texts.status_history_title);
  renderStatusHistory();
}

async function loadUiText() {
  try {
    const config = await api("/api/ui-config");
    applyFeatureFlags(config?.features);
    if (config && typeof config.texts === "object") applyUiText(config.texts);
  } catch (error) {
    console.warn("Unable to load UI text configuration", error);
  }
}

function addActivity(title, detail = "", status = "done") {
  const item = document.createElement("div");
  const time = new Date().toLocaleTimeString("zh-TW", { hour12: false });
  item.className = `chat-message system ${status}`;
  item.innerHTML = `<strong>${escapeHtml(title)}</strong><br><span>${escapeHtml(time)} ${escapeHtml(detail)}</span>`;
  return item;
}

function updateActivity(item, title, detail = "", status = "done") {
  if (!item) return;
  const time = new Date().toLocaleTimeString("zh-TW", { hour12: false });
  item.className = `chat-message system ${status}`;
  item.innerHTML = `<strong>${escapeHtml(title)}</strong><br><span>${escapeHtml(time)} ${escapeHtml(detail)}</span>`;
  if (item.parentElement) item.parentElement.scrollTop = item.parentElement.scrollHeight;
}

function updateVersionActivity(item, title, detail = "", status = "done") {
  if (!item) return;
  const time = new Date().toLocaleTimeString("zh-TW", { hour12: false });
  item.className = `chat-message system version-card ${status}`;
  item.innerHTML = `
    <div class="version-card-head">
      <strong>${escapeHtml(title)}</strong>
      <time class="version-card-time">${escapeHtml(time)}</time>
    </div>
    <span class="version-card-detail">${escapeHtml(detail)}</span>
  `;
  item.title = detail || title;
  if (item.parentElement) item.parentElement.scrollTop = item.parentElement.scrollHeight;
}

function beginOperation(operationName, title, detail, progress = 12) {
  state.busyCount += 1;
  const opLabel = operationName || title || "新操作";
  if (state.statusHistory.length > 0 && state.statusHistory[0].type !== "divider") {
    state.statusHistory.unshift({
      type: "divider",
      title: opLabel,
      time: new Date(),
    });
  }
  setOperationState({ state: "running", title: title || opLabel, detail, progress });
}

function stepOperation(title, detail, progress, indeterminate = false) {
  setOperationState({ state: "running", title, detail, progress, indeterminate });
}

function formatDebugError(error) {
  if (!error) return "";
  const status = error.status ? `HTTP ${error.status}` : "Error";
  const message = error.message || String(error);
  return `${status}: ${message}`;
}

function endOperation(title, detail, success = true, debugError = null) {
  state.busyCount = Math.max(0, state.busyCount - 1);
  const displayDetail = success ? detail : (formatDebugError(debugError) || detail || title);
  setOperationState({
    state: success ? "success" : "error",
    title,
    detail: displayDetail,
    progress: success ? 100 : 100,
  });
  if (!success) return;
  window.setTimeout(() => {
    if (state.busyCount === 0) {
      setOperationState({
        state: "idle",
        title: "待命",
        detail: "可繼續搜尋資料、生成詳細報告或送出回饋",
        progress: 0,
      });
    }
  }, 2200);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function updateCharCounter(input) {
  const max = Number(input.getAttribute("maxlength")) || 0;
  const counter = document.querySelector(`[data-counter-for="${input.id}"]`);
  if (!max || !counter) return;
  counter.textContent = `${input.value.length}/${max}`;
  counter.classList.toggle("is-at-limit", input.value.length >= max);
}

function bindCharCounters() {
  for (const input of document.querySelectorAll("[maxlength][id]")) {
    updateCharCounter(input);
    input.addEventListener("input", () => updateCharCounter(input));
  }
}

const QUERY_STOP_WORDS = new Set([
  "一下", "一個", "以及", "使用", "來信", "回覆", "問題", "資料", "民眾", "相關", "請問", "詢問", "需要",
  "希望", "協助", "可以", "是否", "如何", "什麼", "幫我", "正式", "簡潔", "語氣", "參考", "過去", "加入", "說明",
  "the", "and", "for", "with", "from", "this", "that", "please",
]);

function tokenizeSearchQuery(sourceText) {
  const source = String(sourceText || "").normalize("NFKC");
  const terms = new Set();
  const accept = (raw) => {
    const value = String(raw || "").trim();
    if (!value || QUERY_STOP_WORDS.has(value.toLowerCase())) return;
    const isCjk = /[\u3400-\u9fff]/.test(value);
    if ((isCjk && value.length < 2) || (!isCjk && value.length < 2)) return;
    terms.add(value.slice(0, 32));
  };

  // Preserve short Chinese names and domain phrases that a word segmenter may split,
  // such as "賴清德" or "健康存摺".
  for (const match of source.matchAll(/[\u3400-\u9fff]+/g)) {
    if (match[0].length >= 2 && match[0].length <= 8) accept(match[0]);
  }

  if (typeof Intl.Segmenter === "function") {
    const segmenter = new Intl.Segmenter("zh-Hant", { granularity: "word" });
    for (const segment of segmenter.segment(source)) {
      if (segment.isWordLike) accept(segment.segment);
    }
  } else {
    for (const match of source.matchAll(/[A-Za-z0-9_-]{2,}|[\u3400-\u9fff]{2,}/g)) {
      const value = match[0];
      if (/^[\u3400-\u9fff]+$/.test(value) && value.length > 4) {
        for (let index = 0; index < value.length - 1; index += 2) accept(value.slice(index, index + 2));
      } else {
        accept(value);
      }
    }
  }

  return [...terms].sort((a, b) => b.length - a.length).slice(0, 32);
}

function extractHighlightTerms(sourceText = null) {
  const text = sourceText ?? `${$("requestInput").value || ""}\n${$("draftEditor").value || ""}`;
  const terms = new Set();
  for (const match of text.matchAll(/[A-Za-z0-9_-]{3,}|[\u4e00-\u9fff]{2,}/g)) {
    const value = match[0].trim();
    if (value.length >= 2) terms.add(value.slice(0, 16));
  }
  return [...terms].sort((a, b) => b.length - a.length).slice(0, 12);
}

function highlightedHtml(text, terms, className = "evidence-highlight") {
  const value = String(text || "");
  if (!terms.length) return escapeHtml(value);
  const escapedTerms = terms.map((term) => term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const pattern = new RegExp(`(${escapedTerms.join("|")})`, "gi");
  return value
    .split(pattern)
    .map((part) => {
      if (!part) return "";
      const isHit = terms.some((term) => part.toLowerCase() === term.toLowerCase());
      return isHit ? `<mark class="${className}">${escapeHtml(part)}</mark>` : escapeHtml(part);
    })
    .join("");
}

function layeredHighlightedHtml(text, keywordTerms, citationTerms) {
  const value = String(text || "");
  const rangesFor = (terms) => {
    const ranges = [];
    for (const term of terms) {
      const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const pattern = new RegExp(escaped, "gi");
      for (const match of value.matchAll(pattern)) {
        ranges.push([match.index, match.index + match[0].length]);
      }
    }
    return ranges;
  };
  const keywordRanges = rangesFor(keywordTerms);
  const citationRanges = rangesFor(citationTerms);
  const boundaries = new Set([0, value.length]);
  for (const [start, end] of [...keywordRanges, ...citationRanges]) {
    boundaries.add(start);
    boundaries.add(end);
  }
  const points = [...boundaries].sort((a, b) => a - b);
  let html = "";
  for (let index = 0; index < points.length - 1; index += 1) {
    const start = points[index];
    const end = points[index + 1];
    if (end <= start) continue;
    const hasKeyword = keywordRanges.some(([left, right]) => left < end && right > start);
    const hasCitation = citationRanges.some(([left, right]) => left < end && right > start);
    let segment = escapeHtml(value.slice(start, end));
    if (hasKeyword) segment = `<mark class="keyword-match">${segment}</mark>`;
    if (hasCitation) segment = `<mark class="evidence-highlight">${segment}</mark>`;
    html += segment;
  }
  return html;
}

function highlightedSpanHtml(text, start, end, keywordTerms = []) {
  const value = String(text || "");
  const left = Math.max(0, Math.min(value.length, Number(start)));
  const right = Math.max(left, Math.min(value.length, Number(end)));
  if (right <= left) return highlightedHtml(value, keywordTerms, "keyword-match");
  return [
    highlightedHtml(value.slice(0, left), keywordTerms, "keyword-match"),
    `<mark class="evidence-highlight citation-support">${highlightedHtml(value.slice(left, right), keywordTerms, "keyword-match")}</mark>`,
    highlightedHtml(value.slice(right), keywordTerms, "keyword-match"),
  ].join("");
}

function referenceConfig(kind) {
  if (kind === "draft") return { label: "草稿" };
  if (DRAFT_SOURCE_CORPUSES.includes(kind)) return { label: corpusDisplayName(kind) };
  return { label: "來信" };
}

function referenceMarker(kind, startLine, endLine = startLine, evidenceIndex = null) {
  const config = referenceConfig(kind);
  const first = Math.max(1, Number(startLine) || 1);
  const last = Math.max(first, Number(endLine) || first);
  if (DRAFT_SOURCE_CORPUSES.includes(kind)) {
    const index = Math.max(1, Number(evidenceIndex) || 1);
    return `${config.label}#[${index}]L${first}${last > first ? `-${last}` : ""}`;
  }
  return `${config.label}#L${first}${last > first ? `-${last}` : ""}`;
}

function lineNumberFromOffset(text, offset) {
  return String(text || "").slice(0, Math.max(0, offset)).split("\n").length;
}

function lineReferenceFromSelection(text, start, end) {
  const value = String(text || "");
  const safeStart = Math.max(0, Math.min(value.length, start));
  const safeEnd = Math.max(safeStart, Math.min(value.length, end));
  const startLine = lineNumberFromOffset(value, safeStart);
  const endOffset = safeEnd > safeStart ? safeEnd - 1 : safeEnd;
  const endLine = lineNumberFromOffset(value, endOffset);
  const lines = value.split("\n");
  return {
    startLine,
    endLine,
    text: lines.slice(startLine - 1, endLine).join("\n"),
  };
}

function lineReferenceFromRange(text, startLine, endLine) {
  const lines = String(text || "").split("\n");
  const first = Math.max(1, Math.min(lines.length, Number(startLine) || 1));
  const last = Math.max(first, Math.min(lines.length, Number(endLine) || first));
  return {
    startLine: first,
    endLine: last,
    text: lines.slice(first - 1, last).join("\n"),
  };
}

function evidenceLineHtml(item, evidenceIndex, queryTerms, preciseRange, hasPreciseCitation) {
  if (preciseRange) {
    return highlightedSpanHtml(item.content, preciseRange.start, preciseRange.end, queryTerms);
  }
  if (hasPreciseCitation) {
    return highlightedHtml(item.content, queryTerms, "keyword-match");
  }
  if (state.highlightedEvidence === evidenceIndex) {
    return layeredHighlightedHtml(item.content, queryTerms, state.highlightTerms);
  }
  return highlightedHtml(item.content, queryTerms, "keyword-match");
}

function evidenceContentHtml(item, evidenceIndex, queryTerms, hasPreciseCitation, activeCitation) {
  const lines = String(item.content || "").split("\n");
  const citationStart = Number(activeCitation?.start_char);
  const citationEnd = Number(activeCitation?.end_char);
  let lineStart = 0;
  return lines
    .map((line, index) => {
      const lineEnd = lineStart + line.length;
      const overlapStart = Math.max(lineStart, citationStart);
      const overlapEnd = Math.min(lineEnd, citationEnd);
      const preciseRange =
        hasPreciseCitation && overlapEnd > overlapStart
          ? { start: overlapStart - lineStart, end: overlapEnd - lineStart }
          : null;
      const html = evidenceLineHtml(
        { ...item, content: line },
        evidenceIndex,
        queryTerms,
        preciseRange,
        hasPreciseCitation
      );
      lineStart = lineEnd + 1;
      return `<span class="evidence-line" data-evidence-line="${index + 1}">${html || " "}</span>`;
    })
    .join("\n");
}

function insertAtCursor(input, text) {
  const start = input.selectionStart ?? input.value.length;
  const end = input.selectionEnd ?? input.value.length;
  const before = input.value.slice(0, start);
  const after = input.value.slice(end);
  const prefix = before && !/\s$/.test(before) ? " " : "";
  const suffix = after && !/^\s/.test(after) ? " " : "";
  const nextValue = `${before}${prefix}${text}${suffix}${after}`;
  const maxLength = Number(input.getAttribute("maxlength")) || 0;
  if (maxLength && nextValue.length > maxLength) {
    setTemporaryStatus("error", "無法加入提及", `快速調整最多 ${maxLength} 字`);
    return false;
  }
  input.value = nextValue;
  const cursor = before.length + prefix.length + text.length + suffix.length;
  input.focus();
  input.setSelectionRange(cursor, cursor);
  updateCharCounter(input);
  return true;
}

function hideSelectionQuote() {
  const button = $("quoteSelectionBtn");
  if (button) button.classList.add("hidden");
  state.pendingReference = null;
}

function showSelectionQuote(kind, reference, anchor) {
  const selectedText = reference?.text;
  const text = String(selectedText || "").trim();
  const button = $("quoteSelectionBtn");
  if (!button || !text) {
    hideSelectionQuote();
    return;
  }
  state.pendingReference = {
    kind,
    text: String(selectedText || ""),
    startLine: reference.startLine,
    endLine: reference.endLine,
    evidenceIndex: reference.evidenceIndex || null,
  };
  const left = Math.min(window.innerWidth - 148, Math.max(8, anchor.x - 58));
  const top = Math.min(window.innerHeight - 40, Math.max(8, anchor.y - 38));
  button.style.left = `${left}px`;
  button.style.top = `${top}px`;
  button.classList.remove("hidden");
}

function commitPendingReference() {
  if (!state.pendingReference) return;
  const marker = referenceMarker(
    state.pendingReference.kind,
    state.pendingReference.startLine,
    state.pendingReference.endLine,
    state.pendingReference.evidenceIndex
  );
  const inserted = insertAtCursor($("commandInput"), `{${marker}}`);
  if (!inserted) return;
  state.commandReferences.set(marker, {
    kind: state.pendingReference.kind,
    text: state.pendingReference.text,
  });
  hideSelectionQuote();
}

function referenceTokenPattern() {
  return /\{((?:來信|草稿)#L\d+(?:-\d+)?|(?:備參資料)#\[\d+\]L\d+(?:-\d+)?)\}/g;
}

function expandCommandReferences(text) {
  return String(text || "").replace(referenceTokenPattern(), (wrappedMarker, marker) => {
    const reference = state.commandReferences.get(marker);
    if (!reference) return wrappedMarker;
    return `${wrappedMarker}（引用原文：${reference.text}）`;
  });
}

function textAreaSelectionAnchor(element, event) {
  if (event?.clientX && event?.clientY) return { x: event.clientX, y: event.clientY };
  const rect = element.getBoundingClientRect();
  return { x: rect.right - 36, y: rect.top + 42 };
}

function handleTextareaReferenceSelection(kind, element, event = null) {
  const start = element.selectionStart ?? 0;
  const end = element.selectionEnd ?? 0;
  if (end <= start) {
    hideSelectionQuote();
    return;
  }
  const reference = lineReferenceFromSelection(element.value, start, end);
  if (!reference.text.trim()) {
    hideSelectionQuote();
    return;
  }
  showSelectionQuote(kind, reference, textAreaSelectionAnchor(element, event));
}

function handleDisplayDraftReferenceSelection(event = null) {
  const viewer = $("diffViewer");
  if (!viewer || viewer.classList.contains("hidden")) return;
  const selection = window.getSelection();
  if (!selection || selection.isCollapsed || !selection.rangeCount) {
    hideSelectionQuote();
    return;
  }
  if (!viewer.contains(selection.anchorNode) || !viewer.contains(selection.focusNode)) return;
  const range = selection.getRangeAt(0);
  if (!selection.toString().trim()) {
    hideSelectionQuote();
    return;
  }
  const elementForNode = (node) => (node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement);
  const startRow = elementForNode(range.startContainer)?.closest(".diff-line[data-draft-line]");
  const endRow = elementForNode(range.endContainer)?.closest(".diff-line[data-draft-line]");
  if (!startRow || !endRow) {
    hideSelectionQuote();
    return;
  }
  const reference = lineReferenceFromRange(
    displayDraftContent(),
    Number(startRow.dataset.draftLine),
    Number(endRow.dataset.draftLine)
  );
  const rect = range.getBoundingClientRect();
  const anchor = rect.width || rect.height ? { x: rect.left + rect.width / 2, y: rect.top } : textAreaSelectionAnchor(viewer, event);
  showSelectionQuote("draft", reference, anchor);
}

function handleEvidenceReferenceSelection(event = null) {
  const list = $("evidenceList");
  const selection = window.getSelection();
  if (!list || !selection || selection.isCollapsed || !selection.rangeCount) {
    hideSelectionQuote();
    return;
  }
  if (!list.contains(selection.anchorNode) || !list.contains(selection.focusNode)) return;
  const selectedText = selection.toString().trim();
  if (!selectedText) {
    hideSelectionQuote();
    return;
  }
  const range = selection.getRangeAt(0);
  const elementForNode = (node) => (node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement);
  const startLineElement = elementForNode(range.startContainer)?.closest(".evidence-line[data-evidence-line]");
  const endLineElement = elementForNode(range.endContainer)?.closest(".evidence-line[data-evidence-line]");
  const startCard = startLineElement?.closest(".evidence-card[id^='evidence-card-']");
  const endCard = endLineElement?.closest(".evidence-card[id^='evidence-card-']");
  if (!startLineElement || !endLineElement || !startCard || startCard !== endCard) {
    hideSelectionQuote();
    return;
  }
  const evidenceIndex = Number(startCard.id.replace("evidence-card-", ""));
  const item = state.evidence[evidenceIndex - 1];
  if (!item) {
    hideSelectionQuote();
    return;
  }
  const firstLine = Math.min(Number(startLineElement.dataset.evidenceLine), Number(endLineElement.dataset.evidenceLine));
  const lastLine = Math.max(Number(startLineElement.dataset.evidenceLine), Number(endLineElement.dataset.evidenceLine));
  const reference = lineReferenceFromRange(item.content || "", firstLine, lastLine);
  reference.evidenceIndex = evidenceIndex;
  const rect = range.getBoundingClientRect();
  const anchor = rect.width || rect.height ? { x: rect.left + rect.width / 2, y: rect.top } : { x: event?.clientX || 120, y: event?.clientY || 120 };
  showSelectionQuote(item.corpus || "reference", reference, anchor);
}

function deleteReferenceToken(event, input) {
  if (event.key !== "Backspace") return false;
  const selected = input.value.slice(input.selectionStart ?? 0, input.selectionEnd ?? 0);
  const exactPattern = new RegExp(`^(?:${referenceTokenPattern().source})$`);
  if (exactPattern.test(selected)) {
    event.preventDefault();
    const start = input.selectionStart;
    input.setRangeText("", input.selectionStart, input.selectionEnd, "start");
    input.setSelectionRange(start, start);
    const inner = selected.match(exactPattern)?.[1] || selected;
    state.commandReferences.delete(inner);
    updateCharCounter(input);
    return true;
  }
  if (input.selectionStart !== input.selectionEnd) return false;
  const cursor = input.selectionStart ?? 0;
  const before = input.value.slice(0, cursor);
  const match = before.match(new RegExp(`(?:${referenceTokenPattern().source})$`));
  if (!match) return false;
  event.preventDefault();
  const start = cursor - match[0].length;
  input.value = `${input.value.slice(0, start)}${input.value.slice(cursor)}`;
  input.setSelectionRange(start, start);
  state.commandReferences.delete(match[1] || match[0]);
  updateCharCounter(input);
  return true;
}

function selectReferenceTokenAtCursor(input) {
  if (input.selectionStart !== input.selectionEnd) return;
  const cursor = input.selectionStart ?? 0;
  for (const match of input.value.matchAll(referenceTokenPattern())) {
    const start = match.index;
    const end = start + match[0].length;
    if (cursor >= start && cursor <= end) {
      input.setSelectionRange(start, end);
      return;
    }
  }
}

function setTheme(theme) {
  state.theme = theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = state.theme;
  const button = $("themeToggleBtn");
  if (button) {
    const isDark = state.theme === "dark";
    button.setAttribute("aria-pressed", String(isDark));
    button.setAttribute("aria-label", isDark ? "切換淺色模式" : "切換深色模式");
    button.title = isDark ? "切換淺色模式" : "切換深色模式";
  }
  try {
    window.localStorage.setItem("letter-drafter-theme", state.theme);
  } catch (_error) {
    // Theme still applies when storage is unavailable.
  }
}

function initialTheme() {
  try {
    const saved = window.localStorage.getItem("letter-drafter-theme");
    if (saved === "dark" || saved === "light") return saved;
  } catch (_error) {
    // Fall through to the operating-system preference.
  }
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `HTTP ${response.status}`);
    error.status = response.status;
    error.payload = data;
    throw error;
  }
  return data;
}

async function streamSSE(url, payload, onEvent, signal) {
  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal,
    });
  } catch (err) {
    if (signal?.aborted || err.name === "AbortError") {
      const abortErr = new Error("使用者已暫停生成");
      abortErr.name = "AbortError";
      throw abortErr;
    }
    throw err;
  }
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    const error = new Error(data.error || `HTTP ${response.status}`);
    error.status = response.status;
    error.payload = data;
    throw error;
  }
  if (!response.body) throw new Error("瀏覽器不支援即時串流");

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let completed = null;

  const consumeFrame = (frame) => {
    const lines = frame.replaceAll("\r", "").split("\n");
    let event = "message";
    const dataLines = [];
    for (const line of lines) {
      if (line.startsWith("event:")) event = line.slice("event:".length).trim() || event;
      if (line.startsWith("data:")) dataLines.push(line.slice("data:".length).trimStart());
    }
    if (!dataLines.length) return;
    let data;
    try {
      data = JSON.parse(dataLines.join("\n"));
    } catch (_error) {
      throw new Error("即時串流回傳格式錯誤");
    }
    if (event === "error") {
      const error = new Error(data.error || "處理失敗");
      error.status = data.status;
      throw error;
    }
    onEvent(event, data);
    if (event === "complete") completed = data;
  };

  while (true) {
    if (signal?.aborted) {
      try { await reader.cancel(); } catch (_) {}
      const abortErr = new Error("使用者已暫停生成");
      abortErr.name = "AbortError";
      throw abortErr;
    }
    let readResult;
    try {
      readResult = await reader.read();
    } catch (err) {
      if (signal?.aborted || err.name === "AbortError") {
        const abortErr = new Error("使用者已暫停生成");
        abortErr.name = "AbortError";
        throw abortErr;
      }
      throw err;
    }
    const { value, done } = readResult;
    buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
    let frameEnd = buffer.indexOf("\n\n");
    while (frameEnd >= 0) {
      consumeFrame(buffer.slice(0, frameEnd));
      buffer = buffer.slice(frameEnd + 2);
      frameEnd = buffer.indexOf("\n\n");
    }
    if (done) break;
  }
  if (!completed) throw new Error("串流在完成前中斷");
  return completed;
}

const FLOW_ICONS = {
  play: `<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><polygon points="8,5 19,12 8,19"></polygon></svg>`,
  pause: `<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><rect x="6" y="5" width="3.5" height="14" rx="1"></rect><rect x="14.5" y="5" width="3.5" height="14" rx="1"></rect></svg>`,
  rerun: `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 12A8.5 8.5 0 1 1 18 6L21 8.5"></path><path d="M21 3v5.5h-5.5"></path><polygon points="10,8.5 15.5,12 10,15.5" fill="currentColor" stroke="none"></polygon></svg>`,
};

function updateFlowButtonsState(isRunning = false, source = "request") {
  const reqBtn = $("requestDraftBtn");
  const srcBtn = $("sourceDraftBtn");
  if (!reqBtn || !srcBtn) return;

  if (isRunning) {
    if (source === "request") {
      reqBtn.innerHTML = FLOW_ICONS.pause;
      reqBtn.title = "暫停生成詳細報告";
      reqBtn.setAttribute("aria-label", "暫停生成詳細報告");
      reqBtn.classList.add("pause-mode");
      reqBtn.disabled = false;
      srcBtn.disabled = true;
    } else {
      srcBtn.innerHTML = FLOW_ICONS.pause;
      srcBtn.title = "暫停重新生成報告";
      srcBtn.setAttribute("aria-label", "暫停重新生成報告");
      srcBtn.classList.add("pause-mode");
      srcBtn.disabled = false;
      reqBtn.disabled = true;
    }
  } else {
    reqBtn.innerHTML = FLOW_ICONS.play;
    reqBtn.title = "檢索並生成詳細報告";
    reqBtn.setAttribute("aria-label", "檢索並生成詳細報告");
    reqBtn.classList.remove("pause-mode");
    reqBtn.disabled = false;

    srcBtn.innerHTML = FLOW_ICONS.rerun;
    srcBtn.classList.remove("pause-mode");
    updateActionButtonsState();
  }
}

function updateActionButtonsState() {
  const hasEvidence = Boolean(
    (state.evidence && state.evidence.length > 0) ||
    (typeof usableCurrentEvidence === "function" && usableCurrentEvidence().length > 0)
  );
  const isRunning = Boolean(state.activeAbortController);
  const currentEditorText = ($("draftEditor")?.value || "").trim();
  const draftText = (state.diffMode ? latestDraftContent() : currentEditorText).trim();
  const hasDraftContent = draftText.length > 0;
  const draftCount = Array.isArray(state.drafts) ? state.drafts.length : 0;
  const canCompare = state.diffMode && draftCount >= 2;

  // 1. 以更新後資料重新生成報告
  const srcBtn = $("sourceDraftBtn");
  if (srcBtn && !isRunning) {
    srcBtn.disabled = !hasEvidence;
    srcBtn.title = hasEvidence ? "以更新後資料重新生成報告" : "尚未搜尋或無可用資料來源";
    srcBtn.setAttribute("aria-label", srcBtn.title);
  }

  // 2. 比較按鈕
  const compareBtn = $("compareToggleBtn");
  if (compareBtn) {
    compareBtn.disabled = !canCompare;
    if (draftCount < 2) {
      compareBtn.classList.remove("active");
      compareBtn.setAttribute("aria-pressed", "false");
      compareBtn.title = "需有兩個以上版本才可進行比較";
    } else if (!state.diffMode) {
      compareBtn.title = "請切換至顯示模式進行比較";
    } else {
      compareBtn.classList.toggle("active", state.compareMode);
      compareBtn.setAttribute("aria-pressed", state.compareMode ? "true" : "false");
      const current = latestDraft();
      const base = comparisonBaseDraft(current);
      compareBtn.title = state.compareMode && base
        ? `關閉 v${current?.version || "?"} 與 v${base.version} 的版本比較`
        : "開啟版本比較";
    }
  }

  // 3. 存檔按鈕 (儲存版本)
  const saveBtn = $("saveDraftBtn");
  if (saveBtn) {
    const savedDraftText = editableDraftContent(latestDraftContent()).trim();
    const isModified = currentEditorText.length > 0 && currentEditorText !== savedDraftText;
    const canSave = Boolean(state.runId) && !state.diffMode && hasDraftContent && isModified;
    saveBtn.disabled = !canSave;
    if (!state.runId || draftCount === 0) {
      saveBtn.title = "尚無草稿版本可供存檔";
    } else if (state.diffMode) {
      saveBtn.title = "請切換至編輯模式修改後再儲存版本";
    } else if (!hasDraftContent) {
      saveBtn.title = "草稿內容為空，無法儲存";
    } else if (!isModified) {
      saveBtn.title = "內容尚未修改，無新版本可供存檔";
    } else {
      saveBtn.title = "儲存目前編輯為新版本";
    }
  }

  // 4. DOCX 僅匯出目前選取、已保存的版本；編輯中的文字必須先另存版本。
  const downloadDocxBtn = $("downloadDocxBtn");
  if (downloadDocxBtn) {
    const selectedDraft = latestDraft();
    const selectedText = editableDraftContent(selectedDraft?.content || "").trim();
    const hasUnsavedEdit = !state.diffMode && currentEditorText !== selectedText;
    const canDownload = Boolean(state.runId && selectedDraft?.id && selectedText) && !hasUnsavedEdit;
    downloadDocxBtn.disabled = !canDownload;
    downloadDocxBtn.title = !selectedDraft?.id || !selectedText
      ? "尚無草稿版本可供下載"
      : hasUnsavedEdit
        ? "請先儲存目前修改，再下載 DOCX"
        : `下載 ${draftDisplayName(selectedDraft)} 為 DOCX`;
  }

  // 5. 複製按鈕
  const copyBtn = $("copyBtn");
  if (copyBtn) {
    copyBtn.disabled = !hasDraftContent;
    copyBtn.title = hasDraftContent ? "複製報告" : "目前尚無報告內容可複製";
  }

  // 6. 報告回饋：僅在已建立的報告上開放，避免無對象的評價。
  const feedbackToggle = $("feedbackPanelToggle");
  if (feedbackToggle) {
    const canFeedback = Boolean(state.runId) && hasDraftContent && !isRunning;
    feedbackToggle.disabled = !canFeedback;
    if (!canFeedback) setFeedbackPanelOpen(false);
    feedbackToggle.title = canFeedback ? "開啟報告回饋" : "尚無報告可回饋";
  }
}

function pauseCurrentOperation() {
  if (!state.activeAbortController) return;
  state.isPaused = true;
  state.activeAbortController.abort();
}

async function streamDraft(payload, onEvent, signal) {
  try {
    return await streamSSE("/api/draft/stream", payload, onEvent, signal);
  } finally {
    state.draftPreviewStop?.();
  }
}

function createIncrementalDraftPreview() {
  state.draftPreviewStop?.();
  let streamedText = "";
  let renderedLines = [];
  let started = false;
  let scrollFrame = null;
  const viewer = $("diffViewer");
  let following = true;
  let lastScrollTop = viewer.scrollTop;
  let stopped = false;
  const atBottom = () => viewer.scrollHeight - viewer.clientHeight - viewer.scrollTop <= 4;
  const cancelScroll = () => {
    if (scrollFrame !== null) {
      window.cancelAnimationFrame(scrollFrame);
      scrollFrame = null;
    }
  };
  const onScroll = () => {
    if (viewer.scrollTop < lastScrollTop - 1) following = false;
    if (atBottom()) following = true;
    lastScrollTop = viewer.scrollTop;
    if (!following) cancelScroll();
  };
  // Cancel a pending frame immediately, before the browser applies the wheel.
  const onWheel = (event) => {
    if (event.deltaY < 0) {
      following = false;
      cancelScroll();
    }
  };
  viewer.addEventListener("scroll", onScroll, { passive: true });
  viewer.addEventListener("wheel", onWheel, { passive: true });

  const scheduleScroll = () => {
    if (stopped || !following || scrollFrame !== null) return;
    scrollFrame = window.requestAnimationFrame(() => {
      scrollFrame = null;
      // A scrollbar drag/keyboard scroll can precede its scroll event.
      if (viewer.scrollTop < lastScrollTop - 1) following = false;
      if (!following || stopped) return;
      viewer.scrollTop = viewer.scrollHeight;
      lastScrollTop = viewer.scrollTop;
    });
  };

  const stop = () => {
    stopped = true;
    cancelScroll();
    viewer.removeEventListener("scroll", onScroll);
    viewer.removeEventListener("wheel", onWheel);
    if (state.draftPreviewStop === stop) state.draftPreviewStop = null;
  };
  state.draftPreviewStop = stop;

  return {
    append(text) {
      if (!started) {
        started = true;
        setDiffMode(true);
        $("draftEditor").value = "";
        $("diffViewer").replaceChildren();
        lastScrollTop = viewer.scrollTop;
      }

      streamedText += text || "";
      const displayContent = stripReferenceSection(streamedText);
      $("draftEditor").value = editableDraftContent(displayContent);
      const nextLines = splitLines(displayContent);

      // Reconcile only the growing tail. Completed lines keep their existing
      // nodes, citation buttons, event delegation, and layout boxes.
      let commonLineCount = 0;
      while (
        commonLineCount < renderedLines.length &&
        commonLineCount < nextLines.length &&
        renderedLines[commonLineCount] === nextLines[commonLineCount]
      ) {
        commonLineCount += 1;
      }

      while (viewer.children.length > commonLineCount) {
        viewer.lastElementChild.remove();
      }
      if (commonLineCount < nextLines.length) {
        viewer.insertAdjacentHTML(
          "beforeend",
          nextLines
            .slice(commonLineCount)
            .map((line, offset) => renderCitedLine(line, "ctx", commonLineCount + offset + 1))
            .join("")
        );
      }
      renderedLines = nextLines;
      scheduleScroll();
    },
    stop,
  };
}

function setBusy(button, busy) {
  if (!button) return;
  if (button.id === "requestDraftBtn" || button.id === "sourceDraftBtn") {
    button.setAttribute("aria-busy", busy ? "true" : "false");
    return;
  }
  button.disabled = busy;
  button.setAttribute("aria-busy", busy ? "true" : "false");
}

function setFeedbackPanelOpen(open) {
  const panel = $("floatingFeedbackRow");
  const toggle = $("feedbackPanelToggle");
  if (!panel || !toggle) return;
  const isOpen = Boolean(open && !toggle.disabled);
  panel.classList.toggle("expanded", isOpen);
  toggle.setAttribute("aria-expanded", String(isOpen));
  toggle.title = isOpen ? "收合報告回饋" : "開啟報告回饋";
  if (!isOpen) {
    $("inlineFeedbackWrap")?.classList.remove("expanded");
    $("feedbackNoteToggle")?.classList.remove("active");
  }
}

function flashButton(button) {
  if (!button) return;
  button.classList.add("active-feedback");
  window.setTimeout(() => button.classList.remove("active-feedback"), 220);
}

function setDraftFontSize(size) {
  state.draftFontSize = Math.max(11, Math.min(20, size));
  document.documentElement.style.setProperty("--draft-font-size", `${state.draftFontSize}px`);
}

function resetDraftWorkspace({ keepEvidence = false } = {}) {
  const evidence = keepEvidence ? state.evidence : [];
  const evidenceSnapshotId = keepEvidence ? state.evidenceSnapshotId : null;
  const reviewedEvidence = keepEvidence ? state.reviewedEvidence : [];
  const retrievalAudit = keepEvidence ? state.retrievalAudit : {};
  state.runId = null;
  state.evidence = evidence;
  state.evidenceSnapshotId = evidenceSnapshotId;
  state.reviewedEvidence = reviewedEvidence;
  state.retrievalAudit = retrievalAudit;
  state.documentAuditFilter = "all";
  state.retrievalAuditDetailsOpen = false;
  state.hasPendingEvidenceSelection = false;
  state.drafts = [];
  state.selectedDraftId = null;
  state.versionLabels = {};
  state.selectedRating = null;
  state.busyCount = 0;
  state.highlightedEvidence = null;
  state.highlightedCitationId = null;
  state.highlightText = "";
  state.highlightTerms = [];
  state.queryHighlightTerms = [];
  state.citations = [];
  state.compareMode = false;
  state.commandReferences = new Map();
  state.pendingReference = null;
  state.suggestionRequestVersion += 1;
  $("draftEditor").value = "";
  $("diffViewer").innerHTML = "";
  $("versionMessages").innerHTML = "";
  $("feedbackNote").value = "";
  updateCharCounter($("feedbackNote"));
  setFeedbackPanelOpen(false);
  document.querySelectorAll(".rating").forEach((item) => item.classList.remove("selected", "pop-active"));
  renderEvidence(evidence);
  renderRetrievalAudit();
  renderDraftVersions();
  renderQuickActions(state.suggestions);
  hideSelectionQuote();
  setCompareMode(false);
  setDiffMode(true);
  updateActionButtonsState();
}

function renderEvidence(evidence, { preserveScroll = false } = {}) {
  state.evidence = evidence;
  const list = $("evidenceList");
  if (usesUnifiedDocumentCards()) {
    list.hidden = true;
    list.innerHTML = "";
    renderRetrievalAudit();
    renderCitationLinks();
    updateActionButtonsState();
    return;
  }
  list.hidden = false;
  const visibleEvidence = evidence.filter(
    (item) => (item.corpus || "reference") === state.activeEvidenceCorpus && !state.excludedCorpuses.has(item.corpus || "reference")
  );
  const previousScrollTop = list.scrollTop;
  list.innerHTML = "";
  if (!visibleEvidence.length) {
    list.innerHTML = `<div class="empty">尚無資料</div>`;
    if (!preserveScroll) list.scrollTop = 0;
    renderCitationLinks();
    updateActionButtonsState();
    return;
  }
  const focusTerms = state.highlightedEvidence ? state.highlightTerms : [];
  const queryTerms = state.queryHighlightTerms;
  const activeCitation =
    state.citations.find((item) => item.id === state.highlightedCitationId) ||
    state.citations.find(
      (item) => Number(item.evidence_index) === Number(state.highlightedEvidence)
    );
  for (const item of visibleEvidence) {
    const evidenceIndex = state.evidence.indexOf(item) + 1;
    const hasPreciseCitation =
      activeCitation &&
      Number(activeCitation.evidence_index) === evidenceIndex &&
      activeCitation.start_char !== null &&
      activeCitation.end_char !== null &&
      Number.isFinite(Number(activeCitation.start_char)) &&
      Number.isFinite(Number(activeCitation.end_char));
    const card = document.createElement("article");
    card.id = `evidence-card-${evidenceIndex}`;
    card.className = `evidence-card${state.highlightedEvidence === evidenceIndex ? " focused" : ""}`;
    const score = Number(item.score || 0).toFixed(4);
    const caseLine = evidenceFileTitle(item);
    const pageLabel = String(item.source || "").match(/·\s*(第\s*[^·]+頁)\s*$/)?.[1] || "";
    const previewChunkId =
      item.preview_chunk_id ||
      (item.chunk_id && !item.chunk_id.startsWith("reference:") && !item.chunk_id.startsWith("document:") ? item.chunk_id : "") ||
      "";
    const sourceHtml = previewChunkId && caseLine
      ? `<span class="meta-source-clickable" role="button" tabindex="0" data-chunk-id="${escapeHtml(previewChunkId)}" data-evidence-index="${evidenceIndex}" title="點擊預覽 PDF 文件：${escapeHtml(caseLine)}">
          <span class="meta-source-book-icon" aria-hidden="true">
            <svg class="icon-book-closed" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a2.5 2.5 0 0 1-2.5-2.5z" fill="currentColor" fill-opacity="0.14" stroke-width="1.8"/>
              <path d="M7 2v20" stroke-width="1.8"/>
              <path d="M11 2v8l2.5-2 2.5 2V2" fill="currentColor" stroke-width="1.4"/>
              <line x1="11" y1="14" x2="16" y2="14" stroke-width="1.4" opacity="0.6"/>
              <line x1="11" y1="17" x2="14.5" y2="17" stroke-width="1.4" opacity="0.6"/>
            </svg>
            <svg class="icon-book-open" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 17C4.5 15.5 8 15.5 12 18C16 15.5 19.5 15.5 22 17V18.5C19.5 17 16 17 12 19.5C8 17 4.5 17 2 18.5V17Z" fill="currentColor" stroke-width="1"/>
              <path d="M12 7C8 4.5 4.5 4.5 2 6V17C4.5 15.5 8 15.5 12 18C16 15.5 19.5 15.5 22 17V6C19.5 4.5 16 4.5 12 7Z" stroke-width="1.8" fill="none"/>
              <path d="M12 7V18" stroke-width="1.8"/>
              <path d="M5.5 8.5C7 8 9 8.2 10 8.8" stroke-width="1.4"/>
              <path d="M5 11C6.8 10.5 8.8 10.7 10 11.3" stroke-width="1.4"/>
              <path d="M5 13.5C6.5 13.1 8 13.2 9.5 13.7" stroke-width="1.4"/>
              <path d="M14 8.8C15 8.2 17 8 18.5 8.5" stroke-width="1.4"/>
              <path d="M14 11.3C15.2 10.7 17.2 10.5 19 11" stroke-width="1.4"/>
              <path d="M14.5 13.7C16 13.2 17.5 13.1 19 13.5" stroke-width="1.4"/>
            </svg>
          </span>
          <span class="meta-source-text">${escapeHtml(caseLine)}</span>
        </span>`
      : escapeHtml(caseLine);
    card.innerHTML = `
      <header>
        <div>
          <h3>${sourceHtml}</h3>
          <div class="meta">${escapeHtml(pageLabel)} ${escapeHtml(item.application_time || "")}</div>
        </div>
        <div class="score">${score}</div>
      </header>
      <div class="excerpt">${
        evidenceContentHtml(item, evidenceIndex, queryTerms, hasPreciseCitation, activeCitation)
      }</div>
    `;
    list.appendChild(card);
  }
  list.scrollTop = preserveScroll ? previousScrollTop : 0;
  renderCitationLinks();
  updateActionButtonsState();
}

function usesUnifiedDocumentCards() {
  return state.activeEvidenceCorpus === "reference" &&
    !state.excludedCorpuses.has("reference") &&
    Array.isArray(state.retrievalAudit?.documents) && state.retrievalAudit.documents.length > 0;
}

function createNestedGenerationEvidenceCard(item, evidenceIndex, activeCitation) {
  const hasPreciseCitation =
    activeCitation &&
    Number(activeCitation.evidence_index) === evidenceIndex &&
    activeCitation.start_char !== null &&
    activeCitation.end_char !== null &&
    Number.isFinite(Number(activeCitation.start_char)) &&
    Number.isFinite(Number(activeCitation.end_char));
  const card = document.createElement("article");
  card.id = `evidence-card-${evidenceIndex}`;
  card.className = `evidence-card evidence-card--nested${state.highlightedEvidence === evidenceIndex ? " focused" : ""}`;
  const pageLabel = String(item.source || "").match(/·\s*(第\s*[^·]+頁)\s*$/)?.[1] || "";
  card.innerHTML = `
    <header>
      <div>
        <h3>生成原文段落 ${evidenceIndex}</h3>
        <div class="meta">${escapeHtml(pageLabel)} ${escapeHtml(item.application_time || "")}</div>
      </div>
    </header>
    <div class="excerpt">${
      evidenceContentHtml(item, evidenceIndex, state.queryHighlightTerms, hasPreciseCitation, activeCitation)
    }</div>
  `;
  return card;
}

function auditStatusLabel(status) {
  return {
    relevant: "判定相關",
    possibly_relevant: "可能相關，保守採用",
    not_relevant: "Agent 未採用",
    fetch_failed: "文件取得失敗",
    source_incomplete: "來源不完整，僅採用可解析頁面",
    review_failed: "審閱失敗",
  }[status] || "等待審閱";
}

function auditDocumentMatchesFilter(document, citedDocumentIds, generationDocumentIds) {
  const status = document.status;
  if (state.documentAuditFilter === "selection") {
    // Only documents with a reviewed unit can be safely added to or removed
    // from the generation set.  This intentionally excludes fetch/review
    // failures while retaining safe units from a partial source.
    return ["relevant", "possibly_relevant", "not_relevant", "source_incomplete"].includes(status)
      && Array.isArray(document.reviewed_evidence_ids)
      && document.reviewed_evidence_ids.length > 0;
  }
  if (state.documentAuditFilter === "generation") return generationDocumentIds.has(document.document_id);
  if (state.documentAuditFilter === "cited") return citedDocumentIds.has(document.document_id);
  if (state.documentAuditFilter === "exceptions") {
    return ["source_incomplete", "fetch_failed", "review_failed"].includes(status);
  }
  return true;
}

function renderRetrievalAudit() {
  const panel = $("retrievalAuditPanel");
  const audit = state.retrievalAudit || {};
  const documents = Array.isArray(audit.documents) ? audit.documents : [];
  if (!panel) return;
  const unified = usesUnifiedDocumentCards();
  panel.closest(".source-pane")?.classList.toggle("unified-document-cards", unified);
  const evidenceList = $("evidenceList");
  if (unified && evidenceList) {
    evidenceList.hidden = true;
    evidenceList.innerHTML = "";
  } else if (evidenceList) {
    evidenceList.hidden = false;
  }
  panel.hidden = !documents.length;
  if (!documents.length) return;
  const citedDocumentIds = new Set(
    (state.citations || [])
      .map((citation) => state.evidence[Number(citation.evidence_index) - 1]?.document_id)
      .filter(Boolean)
  );
  const selectedCount = Number(audit.selected_document_count || 0);
  const reviewedCount = Number(audit.reviewed_document_count || 0);
  const partialCount = Number(audit.partial_document_count || 0);
  const currentGenerationEvidence = (state.evidence || []).filter(
    (item) => (item.corpus || "reference") === "reference"
  );
  const generationDocumentIds = new Set(
    currentGenerationEvidence.map((item) => item.document_id).filter(Boolean)
  );
  const generationSelectedCount = generationDocumentIds.size;
  const generationSelectedUnits = currentGenerationEvidence.length;
  const generationCompacted = Boolean(audit.generation_context_compacted);
  const documentCount = Number(audit.document_count || documents.length);
  const retrievalDetails = [
    `搜尋命中 <strong>${Number(audit.search_hit_count || 0)}</strong> 個區段`,
    `涉及 <strong>${documentCount}</strong> 份文件`,
    `建議採用 <strong>${selectedCount}</strong> 份`,
    partialCount ? `部分解析 <strong>${partialCount}</strong> 份（僅使用成功頁面）` : "",
    generationCompacted ? `生成內容為已整理的原文節錄；共 <strong>${generationSelectedCount}</strong> 份／${generationSelectedUnits} 段` : "",
  ].filter(Boolean);
  $("retrievalAuditSummary").innerHTML = `
    <div class="retrieval-audit-summary-primary">
      <span>完整檢視 <strong>${reviewedCount}/${documentCount}</strong></span>
      <span>生成使用 <strong>${generationSelectedUnits}</strong></span>
      <span>報告引用 <strong>${citedDocumentIds.size}</strong></span>
    </div>
    <button type="button" class="retrieval-audit-details-toggle" data-retrieval-audit-details-toggle aria-expanded="${state.retrievalAuditDetailsOpen}">檢索與解析詳情 <span aria-hidden="true">${state.retrievalAuditDetailsOpen ? "⌄" : "›"}</span></button>
    ${state.retrievalAuditDetailsOpen ? `<div class="retrieval-audit-details">${retrievalDetails.map((detail) => `<span>${detail}</span>`).join("")}</div>` : ""}`;
  const filters = [
    ["all", "全部"],
    ["selection", "採用調整"],
    ["generation", "生成使用"],
    ["cited", "報告引用"],
    ["exceptions", "例外／稽核"],
  ];
  const filterButton = ([key, label]) =>
    `<button type="button" class="document-audit-filter${state.documentAuditFilter === key ? " active" : ""}" data-document-audit-filter="${key}">${label}</button>`;
  $("documentAuditFilters").innerHTML = `<div class="document-audit-filter-row">${filters.map(filterButton).join("")}</div>`;
  const selectionNotice = $("sourceSelectionNotice");
  if (selectionNotice) {
    selectionNotice.hidden = !state.hasPendingEvidenceSelection;
    selectionNotice.innerHTML = state.hasPendingEvidenceSelection
      ? `<span>原文選用已變更；重新生成後才會更新報告。</span><button type="button" data-regenerate-from-selection>套用並重新生成</button>`
      : "";
  }
  const reviewedById = reviewedEvidenceById();
  const generationIds = evidenceIdsInGeneration();
  const activeCitation =
    state.citations.find((item) => item.id === state.highlightedCitationId) ||
    state.citations.find((item) => Number(item.evidence_index) === Number(state.highlightedEvidence));
  const visible = documents.filter((document) => auditDocumentMatchesFilter(document, citedDocumentIds, generationDocumentIds));
  const list = $("documentAuditList");
  list.innerHTML = visible.length ? "" : `<div class="empty">此篩選沒有文件</div>`;
  for (const candidate of visible) {
    const units = (candidate.reviewed_evidence_ids || []).map((id) => reviewedById.get(id)).filter(Boolean);
    const cited = citedDocumentIds.has(candidate.document_id);
    const generationItems = (state.evidence || [])
      .map((item, index) => ({ item, evidenceIndex: index + 1 }))
      .filter(({ item }) => (item.corpus || "reference") === "reference" && item.document_id === candidate.document_id);
    const hitPages = [...new Set((candidate.hits || []).flatMap((hit) => hit.page_nums || []))].join("、") || "未提供";
    const unavailablePages = candidate.review_scope?.unavailable_pages || [];
    const partialDetail = candidate.status === "source_incomplete"
      ? `；缺頁／OCR 未完成 ${escapeHtml(unavailablePages.join("、") || "未提供頁碼")}`
      : "";
    const card = document.createElement("article");
    card.className = `document-audit-card status-${escapeHtml(candidate.status || "pending")}`;
    const title = escapeHtml(candidate.title || candidate.document_id);
    const titleHtml = candidate.preview_chunk_id
      ? `<a href="#" class="document-audit-title-link" data-audit-preview="${escapeHtml(candidate.preview_chunk_id)}" data-audit-title="${title}" title="預覽 PDF：${title}">${title}</a>`
      : title;
    card.innerHTML = `
      <header>
        <h3>${titleHtml}</h3>
      </header>
      <div class="document-audit-badges">
        <span class="document-audit-badge status">${escapeHtml(auditStatusLabel(candidate.status))}</span>
        ${generationItems.length ? `<span class="document-audit-badge generation">生成使用 ${generationItems.length} 段</span>` : ""}
        ${cited ? `<span class="document-audit-badge cited">已引用</span>` : ""}
      </div>
      <p class="document-audit-meta">命中 ${(candidate.hits || []).length} 個區段／頁 ${escapeHtml(hitPages)}；已檢視 ${Number(candidate.review_scope?.pages_reviewed || 0)}/${Number(candidate.review_scope?.pages_total || 0)} 頁${partialDetail}</p>
      <p class="document-audit-reason">${escapeHtml(candidate.reason || candidate.error || "尚無判定說明")}</p>`;
    if (units.length || generationItems.length) {
      const details = document.createElement("details");
      details.className = "document-audit-details";
      details.open = Boolean(generationItems.length && (cited || state.highlightedEvidence));
      details.innerHTML = `<summary>原文與操作：已審閱 ${units.length} 段${generationItems.length ? `；生成使用 ${generationItems.length} 段` : ""}</summary>`;
      const body = document.createElement("div");
      body.className = "document-audit-detail-body";
      for (const { item, evidenceIndex } of generationItems) {
        body.appendChild(createNestedGenerationEvidenceCard(item, evidenceIndex, activeCitation));
      }
      if (units.length) {
        const controls = document.createElement("div");
        controls.className = "document-review-unit-controls";
        controls.innerHTML = `<span>原文選用</span>${units.map((unit, index) => {
          const selected = generationIds.has(unit.evidence_id);
          const action = selected ? "exclude" : "include";
          const label = selected ? `從生成內容移除第 ${index + 1} 段` : `加入生成內容第 ${index + 1} 段`;
          return `<button type="button" data-reviewed-evidence-id="${escapeHtml(unit.evidence_id)}" data-reviewed-action="${action}" title="${label}">${label}</button>`;
        }).join("")}`;
        body.appendChild(controls);
      }
      details.appendChild(body);
      card.appendChild(details);
    }
    list.appendChild(card);
  }
  renderCitationLinks();
}

function updateReviewedEvidenceSelection(evidenceId, action) {
  const unit = reviewedEvidenceById().get(evidenceId);
  if (!unit) return;
  if (action === "include" && !evidenceIdsInGeneration().has(evidenceId)) {
    state.evidence = [...state.evidence, { ...unit, selection_origin: "user_included" }];
    state.hasPendingEvidenceSelection = true;
  } else if (action === "exclude") {
    state.evidence = state.evidence.filter((item) => item.evidence_id !== evidenceId);
    state.hasPendingEvidenceSelection = true;
  }
  renderEvidence(state.evidence, { preserveScroll: true });
  renderRetrievalAudit();
}

function citedEvidenceIndexes() {
  const max = state.evidence.length;
  const text = state.diffMode ? displayDraftContent() : $("draftEditor").value || "";
  const cited = [...text.matchAll(/\[(\d{1,2})\]/g)]
    .map((match) => Number(match[1]))
    .filter((index) => index >= 1 && index <= max);
  return [...new Set(cited.length ? cited : state.evidence.map((_, index) => index + 1))];
}

function evidenceFileTitle(item) {
  return String(item?.source || item?.subject || "未命名資料來源").replace(/\s*·\s*第\s*[^·]+頁\s*$/, "").trim();
}

function citationTitle(index) {
  return evidenceFileTitle(state.evidence[Number(index) - 1]);
}

function citationLabelHtml(index) {
  return `<span class="citation-file-label">${escapeHtml(citationLabel(index))}</span>`;
}

function citationLabel(index) {
  const characters = Array.from(citationTitle(index));
  const label = characters.slice(0, 6).join("");
  return characters.length > 6 ? `${label}...` : label;
}

function renderCitationLinks() {
  const container = $("citationLinks");
  if (!container) return;
  container.innerHTML = "";
  if (!state.evidence.length) return;
  for (const index of citedEvidenceIndexes()) {
    const button = document.createElement("button");
    button.className = "citation-link";
    button.type = "button";
    button.dataset.evidenceIndex = String(index);
    button.innerHTML = citationLabelHtml(index);
    button.title = citationTitle(index);
    container.appendChild(button);
  }
}

function focusEvidence(index, citationId = null, lineText = "") {
  const resolvedCitation =
    state.citations.find((item) => item.id === citationId) ||
    state.citations.find((item) => Number(item.evidence_index) === Number(index)) ||
    null;
  const resolvedCitationId = resolvedCitation?.id || null;
  const isSameCitation =
    Number(state.highlightedEvidence) === Number(index) &&
    state.highlightedCitationId === resolvedCitationId;
  if (isSameCitation) return;
  const previousCorpus = state.activeEvidenceCorpus;
  state.highlightedEvidence = index;
  state.highlightedCitationId = resolvedCitationId;
  state.highlightText = resolvedCitation?.support_quote || lineText || "";
  const target = state.evidence[index - 1];
  if (target?.corpus) {
    setEvidenceCorpus(target.corpus);
  }
  state.highlightTerms = extractHighlightTerms(state.highlightText);
  renderEvidence(state.evidence, { preserveScroll: previousCorpus === state.activeEvidenceCorpus });
  const card = $(`evidence-card-${index}`);
  if (card) {
    const targetElement = card.querySelector(".evidence-highlight") || card;
    const list = card.closest(".retrieval-audit-panel") || $("evidenceList");
    const targetRect = targetElement.getBoundingClientRect();
    const listRect = list.getBoundingClientRect();
    const isVisible = targetRect.top >= listRect.top && targetRect.bottom <= listRect.bottom;
    const changedCorpus = previousCorpus !== state.activeEvidenceCorpus;
    if (changedCorpus || !isVisible) {
      targetElement.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }
  }
}

function setEvidenceCorpus(corpus) {
  state.activeEvidenceCorpus = corpus || "reference";
  for (const tab of document.querySelectorAll(".source-tab[data-corpus]")) {
    const active = tab.dataset.corpus === state.activeEvidenceCorpus;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", active ? "true" : "false");
  }
}

function syncSourceTabState(tab) {
  const corpus = tab?.dataset?.corpus;
  if (!corpus) return;
  const excluded = state.excludedCorpuses.has(corpus);
  const toggle = tab.querySelector(".exclude-toggle");
  tab.classList.toggle("excluded", excluded);
  if (toggle) {
    const label = excluded ? "恢復此資料來源" : "排除此資料來源";
    toggle.title = label;
    toggle.setAttribute("aria-label", label);
  }
}

function syncAllSourceTabStates() {
  for (const tab of document.querySelectorAll(".source-tab[data-corpus]")) {
    syncSourceTabState(tab);
  }
}

function openPdfPreview(item) {
  const modal = $("pdfModal");
  if (!modal) return;
  const chunkId =
    item?.preview_chunk_id ||
    (item?.chunk_id && !item.chunk_id.startsWith("reference:") && !item.chunk_id.startsWith("document:") ? item.chunk_id : "") ||
    item?.chunk_id ||
    "";
  if (!chunkId) {
    return;
  }

  const title = evidenceFileTitle(item);
  const subtitle = item.source || "";
  const previewUrl = `/api/preview/content?chunk_ids=${encodeURIComponent(chunkId)}`;

  const titleEl = $("pdfModalTitle");
  if (titleEl) titleEl.textContent = title;
  const subtitleEl = $("pdfModalSubtitle");
  if (subtitleEl) {
    subtitleEl.textContent = subtitle;
    subtitleEl.style.display = subtitle ? "block" : "none";
  }

  const externalLink = $("pdfModalExternalLink");
  if (externalLink) {
    externalLink.href = previewUrl;
  }

  const loading = $("pdfModalLoading");
  const statusText = $("pdfModalStatusText");
  const frame = $("pdfModalFrame");

  if (loading) loading.classList.remove("hidden");
  if (statusText) statusText.textContent = "正在載入文件預覽...";

  if (frame) {
    frame.onload = () => {
      if (loading) loading.classList.add("hidden");
    };
    frame.onerror = () => {
      if (loading) {
        loading.classList.remove("hidden");
        if (statusText) statusText.textContent = "PDF 預覽載入失敗，請點選右上角「新分頁開啟」檢視。";
      }
    };
    frame.src = previewUrl;
  }

  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  $("pdfModalCloseBtn")?.focus();
}

function closePdfPreview() {
  const modal = $("pdfModal");
  if (!modal || modal.classList.contains("hidden")) return;
  modal.classList.add("hidden");
  const frame = $("pdfModalFrame");
  if (frame) {
    frame.onload = null;
    frame.onerror = null;
    frame.src = "about:blank";
  }
  document.body.style.overflow = "";
}

function renderQuickActions(suggestions) {
  state.suggestions = suggestions;
  const container = $("quickActions");
  container.innerHTML = "";
  const items = suggestions || [];
  const twoRow = items.length > 4;
  container.classList.toggle("two-row", twoRow);
  container.style.height = twoRow ? "74px" : "42px";
  container.style.maxHeight = twoRow ? "74px" : "42px";
  for (const item of items) {
    const button = document.createElement("button");
    button.className = "quick-chip";
    button.type = "button";
    button.textContent = item.label;
    button.dataset.label = item.label;
    button.dataset.instruction = item.instruction;
    button.disabled = state.busyCount > 0 || !latestDraftContent().trim();
    container.appendChild(button);
  }
}

function setQuickActionsDisabled(disabled) {
  for (const button of document.querySelectorAll(".quick-chip")) {
    button.disabled = disabled || !latestDraftContent().trim();
  }
}

function splitLines(text) {
  return String(text || "").split(/\r?\n/);
}

function diffTokens(text) {
  const tokens = [];
  const pattern = /[\p{Script=Han}]|[A-Za-z0-9]+|\s+|./gu;
  for (const match of String(text || "").matchAll(pattern)) {
    tokens.push({ text: match[0], start: match.index, end: match.index + match[0].length });
  }
  return tokens;
}

function changedTokenRanges(oldText, newText) {
  const oldTokens = diffTokens(oldText);
  const newTokens = diffTokens(newText);
  // Long unbroken OCR/PDF lines should remain responsive. The line-level
  // background still conveys the change when a character-level LCS is costly.
  if (oldTokens.length + newTokens.length > 700) {
    return {
      oldRanges: oldText ? [[0, oldText.length]] : [],
      newRanges: newText ? [[0, newText.length]] : [],
    };
  }
  const dp = Array.from({ length: oldTokens.length + 1 }, () => Array(newTokens.length + 1).fill(0));
  for (let i = oldTokens.length - 1; i >= 0; i -= 1) {
    for (let j = newTokens.length - 1; j >= 0; j -= 1) {
      dp[i][j] = oldTokens[i].text === newTokens[j].text
        ? dp[i + 1][j + 1] + 1
        : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const oldRanges = [];
  const newRanges = [];
  let i = 0;
  let j = 0;
  while (i < oldTokens.length || j < newTokens.length) {
    if (i < oldTokens.length && j < newTokens.length && oldTokens[i].text === newTokens[j].text) {
      i += 1;
      j += 1;
    } else if (j >= newTokens.length || (i < oldTokens.length && dp[i + 1][j] >= dp[i][j + 1])) {
      oldRanges.push([oldTokens[i].start, oldTokens[i].end]);
      i += 1;
    } else {
      newRanges.push([newTokens[j].start, newTokens[j].end]);
      j += 1;
    }
  }
  return { oldRanges, newRanges };
}

function pairChangedRows(rows) {
  const paired = [];
  for (let index = 0; index < rows.length;) {
    if (rows[index].type === "ctx") {
      paired.push(rows[index]);
      index += 1;
      continue;
    }
    const group = [];
    while (index < rows.length && rows[index].type !== "ctx") group.push(rows[index++]);
    const deleted = group.filter((row) => row.type === "del");
    const added = group.filter((row) => row.type === "add");
    const pairs = Math.min(deleted.length, added.length);
    for (let pair = 0; pair < pairs; pair += 1) {
      const oldText = deleted[pair].text.slice(2);
      const newText = added[pair].text.slice(2);
      const ranges = changedTokenRanges(oldText, newText);
      deleted[pair].wordRanges = ranges.oldRanges.map(([start, end]) => [start + 2, end + 2]);
      added[pair].wordRanges = ranges.newRanges.map(([start, end]) => [start + 2, end + 2]);
    }
    paired.push(...group);
  }
  return paired;
}

function buildLineDiff(oldText, newText) {
  const oldLines = splitLines(oldText);
  const newLines = splitLines(newText);
  const m = oldLines.length;
  const n = newLines.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i -= 1) {
    for (let j = n - 1; j >= 0; j -= 1) {
      dp[i][j] = oldLines[i] === newLines[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const rows = [];
  let i = 0;
  let j = 0;
  while (i < m && j < n) {
    if (oldLines[i] === newLines[j]) {
      rows.push({ type: "ctx", text: `  ${oldLines[i]}` });
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      rows.push({ type: "del", text: `- ${oldLines[i]}` });
      i += 1;
    } else {
      rows.push({ type: "add", text: `+ ${newLines[j]}` });
      j += 1;
    }
  }
  while (i < m) {
    rows.push({ type: "del", text: `- ${oldLines[i]}` });
    i += 1;
  }
  while (j < n) {
    rows.push({ type: "add", text: `+ ${newLines[j]}` });
    j += 1;
  }
  return pairChangedRows(rows);
}

function latestDraft() {
  return state.drafts.find((draft) => draft.id === state.selectedDraftId) || state.drafts[state.drafts.length - 1] || null;
}

function latestDraftContent() {
  return latestDraft()?.content || $("draftEditor").value || "";
}

function stripReferenceSection(text) {
  const lines = splitLines(text);
  const cutAt = lines.findIndex((line) => /^\s*(參考依據|使用依據)\s*[:：]?/.test(line));
  return (cutAt >= 0 ? lines.slice(0, cutAt) : lines).join("\n").trimEnd();
}

function stripCitationMarkers(text) {
  return String(text || "").replace(/\s*\[\d{1,2}(?:\s*[,，、]\s*\d{1,2})*\]/g, "");
}

function editableDraftContent(text) {
  return stripCitationMarkers(stripReferenceSection(text));
}

async function copyToClipboard(text) {
  if (!text) return;
  try {
    if (window.navigator && window.navigator.clipboard && typeof window.navigator.clipboard.writeText === "function") {
      await window.navigator.clipboard.writeText(text);
    } else {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.top = "0";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    addActivity("copied", "draft");
  } catch (err) {
    addActivity("copied (fallback)", "draft");
  }
}

function docxDownloadFilename(response, draft) {
  const fallback = `詳細報告_v${draft?.version || "current"}.docx`;
  const value = response.headers.get("Content-Disposition") || "";
  const encoded = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (!encoded) return fallback;
  try {
    return decodeURIComponent(encoded[1]);
  } catch (_error) {
    return fallback;
  }
}

async function downloadCurrentDraftDocx() {
  const button = $("downloadDocxBtn");
  const draft = latestDraft();
  if (!button || button.disabled || !state.runId || !draft?.id) return;

  setBusy(button, true);
  beginOperation("下載 DOCX", "正在建立 DOCX", `${draftDisplayName(draft)} 轉換為 Word 檔`, 35);
  try {
    const response = await fetch("/api/drafts/docx", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
      body: JSON.stringify({ run_id: state.runId, draft_id: draft.id }),
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      const error = new Error(data.error || `HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    const blob = await response.blob();
    if (!blob.size) throw new Error("DOCX 檔案內容為空");
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = objectUrl;
    link.download = docxDownloadFilename(response, draft);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 0);
    endOperation("DOCX 已下載", `${draftDisplayName(draft)} 已下載為 Word 檔`, true);
  } catch (error) {
    endOperation("DOCX 下載失敗", "目前無法建立 Word 檔，請稍後再試", false, error);
  } finally {
    setBusy(button, false);
    updateActionButtonsState();
  }
}

function displayDraftContent() {
  return stripReferenceSection(latestDraftContent());
}

function draftLineBounds(draftLine) {
  if (!draftLine) return null;
  const lines = splitLines(displayDraftContent());
  if (draftLine < 1 || draftLine > lines.length) return null;
  let start = 0;
  for (let index = 0; index < draftLine - 1; index += 1) {
    start += lines[index].length + 1;
  }
  return { start, end: start + lines[draftLine - 1].length };
}

function citationsForDraftLine(draftLine) {
  const bounds = draftLineBounds(draftLine);
  if (!bounds) return [];
  return state.citations.filter((item) => {
    if (item.draft_start_char === null || item.draft_end_char === null) return false;
    const start = Number(item.draft_start_char);
    const end = Number(item.draft_end_char);
    return Number.isFinite(start) && Number.isFinite(end) && start <= bounds.end && end >= bounds.start;
  });
}

function citationForMarker(lineCitations, evidenceIndex, draftLine, markerIndex, source) {
  const bounds = draftLineBounds(draftLine);
  if (!bounds) return null;
  const hasDiffPrefix =
    state.compareMode &&
    Boolean(previousDraftFor(latestDraft())) &&
    (/^[+\-] /.test(source) || source.startsWith("  "));
  const markerOffset = bounds.start + markerIndex - (hasDiffPrefix ? 2 : 0);
  const matchingEvidence = lineCitations.filter(
    (item) => Number(item.evidence_index) === evidenceIndex
  );
  const containing = matchingEvidence.find((item) => {
      const start = Number(item.draft_start_char);
      const end = Number(item.draft_end_char);
      return start <= markerOffset && markerOffset <= end;
    });
  if (containing) return containing;
  return (
    matchingEvidence
      .filter(
        (item) =>
          Number.isFinite(Number(item.draft_start_char)) &&
          Number.isFinite(Number(item.draft_end_char))
      )
      .sort((left, right) => {
        const leftDistance = Math.min(
          Math.abs(markerOffset - Number(left.draft_start_char)),
          Math.abs(markerOffset - Number(left.draft_end_char))
        );
        const rightDistance = Math.min(
          Math.abs(markerOffset - Number(right.draft_start_char)),
          Math.abs(markerOffset - Number(right.draft_end_char))
        );
        return leftDistance - rightDistance;
      })[0] || null
  );
}

function renderChangedText(text, start, end, wordRanges) {
  const ranges = (wordRanges || [])
    .map(([left, right]) => [Math.max(start, left), Math.min(end, right)])
    .filter(([left, right]) => right > left)
    .sort((left, right) => left[0] - right[0]);
  if (!ranges.length) return escapeHtml(text.slice(start, end));
  let html = "";
  let cursor = start;
  for (const [left, right] of ranges) {
    if (left > cursor) html += escapeHtml(text.slice(cursor, left));
    html += `<mark class="diff-word-change">${escapeHtml(text.slice(Math.max(cursor, left), right))}</mark>`;
    cursor = Math.max(cursor, right);
  }
  return html + escapeHtml(text.slice(cursor, end));
}

function renderCitedLine(text, rowType, draftLine = null, wordRanges = []) {
  const source = String(text || "");
  let html = "";
  let hasCitation = false;
  let cursor = 0;
  const lineCitations = citationsForDraftLine(draftLine);
  const citationPattern = /\[(C[1-9]\d*|\d{1,2}(?:\s*[,，、]\s*\d{1,2})*)\]/g;
  for (const match of source.matchAll(citationPattern)) {
    html += renderChangedText(source, cursor, match.index, wordRanges);
    cursor = match.index + match[0].length;
    if (match[1].startsWith("C")) {
      const citation = state.citations.find((item) => item.id === match[1] || item.citation_key === match[1]);
      hasCitation = true;
      if (citation) {
        const verified = !citation.unverified && Number.isInteger(Number(citation.evidence_index));
        html += `<button class="inline-citation${verified ? "" : " citation-unverified"}" type="button" data-evidence-index="${verified ? Number(citation.evidence_index) : 0}" data-citation-id="${escapeHtml(citation.id)}"${verified ? "" : ' data-unverified="true"'} title="${verified ? escapeHtml(citationTitle(citation.evidence_index)) : "引用標記尚未能對應到可驗證原文"}">${verified ? citationLabelHtml(citation.evidence_index) : "引用待確認"}</button>`;
      } else {
        html += `<button class="inline-citation citation-unverified" type="button" data-evidence-index="0" data-unverified="true" title="引用標記尚未能對應到可驗證原文">引用待確認</button>`;
      }
      continue;
    }
    const rawIndexes = match[1]
      .split(/\s*[,，、]\s*/)
      .map((value) => Number(value))
      .filter((index) => index >= 1 && index <= state.evidence.length);
    const indexes = [...new Set(rawIndexes)];
    for (const index of indexes) {
        hasCitation = true;
        const citation = citationForMarker(lineCitations, index, draftLine, match.index, source);
        const citationAttr = citation ? ` data-citation-id="${escapeHtml(citation.id)}"` : "";
        const lineAttr = citation?.support_quote ? ` data-line-text="${escapeHtml(citation.support_quote)}"` : "";
        const method = citation?.match_method ? ` · ${escapeHtml(citation.match_method)}` : "";
        html += `<button class="inline-citation" type="button" data-evidence-index="${index}"${citationAttr}${lineAttr} title="${escapeHtml(citationTitle(index))}">${citationLabelHtml(index)}</button>`;
    }
  }
  html += renderChangedText(source, cursor, source.length, wordRanges);
  const lineAttribute = draftLine ? ` data-draft-line="${draftLine}"` : "";
  return `<span class="diff-line ${rowType}${hasCitation ? " cited-block" : ""}"${lineAttribute}>${html || " "}</span>`;
}

function comparisonBaseDraft(current) {
  if (!current || state.drafts.length < 2) return null;
  const selectedVersion = state.comparisonBaseVersion || $("baseVersionSelect")?.value;
  const selected = state.drafts.find(
    (draft) => String(draft.version) === String(selectedVersion) && draft.id !== current.id
  );
  if (selected) return selected;
  const currentIndex = state.drafts.findIndex((draft) => draft.id === current.id);
  if (currentIndex > 0) return state.drafts[currentIndex - 1];
  return state.drafts.find((draft) => draft.id !== current.id) || null;
}

function previousDraftFor(current) {
  return comparisonBaseDraft(current);
}

function renderDiff() {
  const current = latestDraft();
  const base = comparisonBaseDraft(current);
  const rows = state.compareMode && base
    ? buildLineDiff(stripReferenceSection(base.content || ""), displayDraftContent())
    : splitLines(displayDraftContent()).map((line) => ({ type: "ctx", text: line }));
  let draftLine = 0;
  $("diffViewer").innerHTML = rows
    .map((row) => {
      if (row.type !== "del") draftLine += 1;
      return renderCitedLine(row.text, row.type, row.type === "del" ? null : draftLine, row.wordRanges);
    })
    .join("");
}

function setCompareMode(enabled) {
  const canCompare = state.diffMode && (Array.isArray(state.drafts) ? state.drafts.length : 0) >= 2;
  state.compareMode = Boolean(enabled && canCompare);
  const button = $("compareToggleBtn");
  if (button) {
    button.classList.toggle("active", state.compareMode);
    button.setAttribute("aria-pressed", state.compareMode ? "true" : "false");
  }
  $("baseVersionSelect")?.classList.toggle("hidden", !state.compareMode);
  syncVersionSelectionUI();
  if (state.diffMode) renderDiff();
  updateActionButtonsState();
}

function setDiffMode(enabled) {
  hideSelectionQuote();
  state.diffMode = enabled;
  $("editModeBtn").classList.toggle("active", !enabled);
  $("displayModeBtn").classList.toggle("active", enabled);
  if (!enabled) {
    $("draftEditor").value = editableDraftContent(latestDraftContent());
  }
  $("draftEditor").classList.toggle("hidden", enabled);
  $("diffViewer").classList.toggle("hidden", !enabled);
  updateActionButtonsState();
  if (enabled) renderDiff();
  renderCitationLinks();
}

function getDraftById(id) {
  return state.drafts.find((draft) => draft.id === id);
}

function shortVersionLabel(text) {
  const value = String(text || "");
  const rules = [
    [/口語|白話/, "口語化"],
    [/極簡|簡化|縮短|精簡|篇幅/, "精簡"],
    [/柔和|同理|親切/, "語氣柔和"],
    [/堅定|明確|限制/, "語氣堅定"],
    [/條列|分點|分項|結構/, "條列化"],
    [/正式|公文|行政/, "正式化"],
    [/引用|依據|法規|條文/, "強化依據"],
    [/電話|洽詢|單位|聯絡/, "補洽詢方式"],
  ];
  for (const [pattern, label] of rules) {
    if (pattern.test(value)) return label;
  }
  return value
    .replace(/^請將草稿/, "")
    .replace(/^請將回覆語氣調整得/, "")
    .replace(/^請將回覆語氣調整為/, "")
    .replace(/^請/, "")
    .replace(/草稿|回覆|調整|改成|修訂|使用者|指令/g, "")
    .replace(/[，。,\.].*$/, "")
    .trim()
    .slice(0, 8);
}

function sourceVersionLabel(source) {
  if (source === "llm") return "初稿";
  if (source === "llm_regenerate") return "更新資料再生成";
  if (source === "user_instruction") return "修訂";
  if (source === "user_edit") return "手動儲存";
  return source || "";
}

function draftDisplayName(draft, fallbackLabel = "") {
  if (!draft) return fallbackLabel;
  const label = state.versionLabels[draft.id] || fallbackLabel || sourceVersionLabel(draft.source);
  return `v${draft.version}${label ? ` ${label}` : ""}`;
}

function attachVersionToActivity(item, draftId, label = "", detail = "") {
  if (!item || !draftId) return;
  if (label) state.versionLabels[draftId] = label;
  const draft = getDraftById(draftId);
  const name = draftDisplayName(draft, label);
  const body = detail || label || sourceVersionLabel(draft?.source);
  updateVersionActivity(item, name, body, "done");
  item.dataset.draftId = draftId;
  item.classList.add("has-version");
  item.setAttribute("role", "button");
  item.tabIndex = 0;
  item.title = body || name;
  if (!$("versionMessages").contains(item)) {
    $("versionMessages").appendChild(item);
  }
  syncVersionSelectionUI();
  $("versionMessages").scrollTop = $("versionMessages").scrollHeight;
}

function syncVersionSelectionUI() {
  const current = latestDraft();
  const base = state.compareMode ? comparisonBaseDraft(current) : null;
  document.querySelectorAll("#versionMessages .chat-message.has-version").forEach((item) => {
    const selected = item.dataset.draftId === state.selectedDraftId;
    item.classList.toggle("selected-version", selected);
    item.classList.toggle("compare-base-version", item.dataset.draftId === base?.id);
    item.setAttribute("aria-pressed", String(selected));
  });
}

function loadDraftVersion(draft) {
  if (!draft) return;
  state.selectedDraftId = draft.id;
  if (state.comparisonBaseVersion === String(draft.version)) state.comparisonBaseVersion = null;
  syncVersionSelectionUI();
  renderDraftVersions();
  if (state.diffMode) {
    renderDiff();
  } else {
    $("draftEditor").value = editableDraftContent(draft.content || "");
  }
  renderCitationLinks();
  setTemporaryStatus("success", `已載入 v${draft.version}`, "草稿版本已切換");
  updateActionButtonsState();
}

function renderDraftVersions() {
  const select = $("baseVersionSelect");
  const selectedDraft = latestDraft();
  const previous = state.comparisonBaseVersion || select.value;
  select.innerHTML = `<option value="">比較基準版本</option>`;
  for (const draft of state.drafts) {
    if (draft.id === selectedDraft?.id) continue;
    const option = document.createElement("option");
    option.value = String(draft.version);
    option.textContent = draftDisplayName(draft);
    select.appendChild(option);
  }
  if ([...select.options].some((option) => option.value === String(previous))) {
    select.value = String(previous);
  } else {
    const fallback = comparisonBaseDraft(selectedDraft);
    select.value = fallback ? String(fallback.version) : "";
  }
  state.comparisonBaseVersion = select.value || null;
  if (state.diffMode) renderDiff();
  syncVersionSelectionUI();
  updateActionButtonsState();
}

async function refreshDraftVersions() {
  if (!state.runId) {
    state.drafts = [];
    renderDraftVersions();
    return;
  }
  try {
    const data = await api(`/api/drafts?${new URLSearchParams({ run_id: state.runId }).toString()}`);
    state.drafts = data.drafts || [];
    if (!state.drafts.some((draft) => draft.id === state.selectedDraftId)) {
      state.selectedDraftId = state.drafts[state.drafts.length - 1]?.id || null;
    }
    renderDraftVersions();
  } catch (error) {
    addActivity("draft versions", error.message, "error");
  }
}

async function refreshSuggestions() {
  const requestVersion = ++state.suggestionRequestVersion;
  const request = $("requestInput").value.trim();
  const draft = latestDraftContent().trim();
  try {
    const data = await api("/api/suggestions", {
      method: "POST",
      body: JSON.stringify({
        request,
        draft,
        evidence_ids: usableCurrentEvidence().map((item) => item.evidence_id),
        ...(state.evidenceSnapshotId ? { evidence_snapshot_id: state.evidenceSnapshotId } : {}),
        ...(state.runId ? { run_id: state.runId } : {}),
      }),
    });
    if (requestVersion === state.suggestionRequestVersion) {
      renderQuickActions(data.suggestions || []);
      recordStatus("success", "快速調整選項已更新", "可選擇調整方向繼續修訂報告");
    }
  } catch (error) {
    if (requestVersion !== state.suggestionRequestVersion) return;
    recordStatus("error", "快速調整選項產生失敗", "報告已保留，可稍後再試");
    addActivity("quick actions", `使用預設選項 · ${error.message}`, "error");
    renderQuickActions([]);
  }
}

async function loadFallbackSuggestions() {
  const requestVersion = ++state.suggestionRequestVersion;
  try {
    const data = await api("/api/suggestions", {
      method: "POST",
      body: JSON.stringify({}),
    });
    if (requestVersion === state.suggestionRequestVersion) {
      renderQuickActions(data.suggestions || []);
    }
  } catch (error) {
    if (requestVersion !== state.suggestionRequestVersion) return;
    addActivity("quick actions", `無法載入預設選項 · ${error.message}`, "error");
  }
}

async function searchEvidence(searchQuery = null) {
  if (state.busyCount > 0) return;
  const button = $("searchToggleBtn");
  const query = (searchQuery !== null ? searchQuery : $("sourceSearchInput").value.trim()) || $("requestInput").value.trim();
  if (!query) return;
  state.queryHighlightTerms = tokenizeSearchQuery(query);
  const corpuses = includedDraftCorpuses();
  if (!corpuses.length) {
    setTemporaryStatus("error", "無資料來源", "請至少保留一個資料來源");
    return;
  }
  if (!corpuses.includes(state.activeEvidenceCorpus)) {
    setEvidenceCorpus(corpuses[0]);
  }
  setBusy(button, true);
  const corpusLabel = corpuses.map(corpusDisplayName).join("、");
  beginOperation(`手動搜尋（${corpusLabel}）`, "正在送出檢索請求", `查詢 ${corpusLabel}`, 0);
  try {
    stepOperation("搜尋中", `${corpusLabel} 搜尋中`, 42, true);
    const data = await api("/api/search", {
      method: "POST",
      body: JSON.stringify({ q: query, mode: "vector", corpuses }),
    });
    const newItems = data.evidence || [];
    const failures = (data.failures || []).map(
      (failure) => `${corpusDisplayName(failure.corpus)}：${failure.error || "搜尋失敗"}`
    );
    state.evidenceSnapshotId = data.evidence_snapshot_id || state.evidenceSnapshotId;
    state.retrievalAudit = {};
    state.reviewedEvidence = [];
    stepOperation("整理搜尋結果", `找到 ${newItems.length} 筆相關資料`, 86);
    state.highlightedEvidence = null;
    state.highlightedCitationId = null;

    // Merge newItems into state.evidence so evidence from other corpuses is preserved
    const byCorpus = {};
    for (const item of (state.evidence || [])) {
      const c = item.corpus || "reference";
      if (!byCorpus[c]) byCorpus[c] = [];
      byCorpus[c].push(item);
    }
    for (const c of corpuses) {
      byCorpus[c] = newItems.filter((it) => (it.corpus || "reference") === c);
    }
    const merged = [];
    for (const c of DRAFT_SOURCE_CORPUSES) {
      if (byCorpus[c]) merged.push(...byCorpus[c]);
    }
    state.evidence = merged.length ? merged : newItems;
    renderEvidence(state.evidence);
    renderRetrievalAudit();
    endOperation(
      failures.length ? "部分資料來源搜尋完成" : "所有資料來源搜尋完成",
      failures.length ? `找到 ${newItems.length} 筆；部分來源暫時無法搜尋` : `找到 ${newItems.length} 筆相關資料`,
      true
    );
  } catch (error) {
    endOperation("搜尋失敗", "資料來源暫時無法搜尋，請稍後再試", false, error);
  } finally {
    setBusy(button, false);
  }
}

async function applyDraftResponse(data, draftJob, label = "初稿", detail = "模型產生初稿") {
  state.runId = data.run_id;
  $("draftEditor").value = editableDraftContent(data.draft || "");
  state.citations = data.citations || [];
  state.reviewedEvidence = data.reviewed_evidence || state.reviewedEvidence;
  state.retrievalAudit = data.retrieval_audit || state.retrievalAudit;
  state.highlightedEvidence = null;
  state.highlightedCitationId = null;
  state.highlightText = "";
  state.hasPendingEvidenceSelection = false;
  renderEvidence(data.evidence || []);
  renderRetrievalAudit();
  updateActivity(draftJob, "draft_created", data.run_id, "done");

  await refreshDraftVersions();
  state.selectedDraftId = data.draft_id || state.selectedDraftId;
  const createdDraft = getDraftById(data.draft_id);
  updateActivity(draftJob, "draft_created", draftDisplayName(createdDraft, label), "done");
  attachVersionToActivity(draftJob, data.draft_id, label, detail);
  renderDraftVersions();
  setDiffMode(true);
  refreshSuggestions();
}

function documentStreamStatus(event, data) {
  if (event === "parallel_preparation_started") return {
    title: "正在評估並整理資料來源", detail: "同時檢查補讀需求與整理可引用的原文", activity: "context_compression"
  };
  if (event === "parallel_preparation_waiting") return {
    title: "正在完成資料整理", detail: "補讀評估已結束，等待資料來源整理完成", activity: "context_compression"
  };
  if (event === "parallel_preparation_merging") return {
    title: "正在整合資料來源", detail: "整合補充原文並檢查資料範圍", activity: "context_compression"
  };
  const title = data.title || data.document_id || "文件";
  switch (event) {
    case "citation_repair_started":
      return { title: "正在修正報告", detail: "依檢查結果修正引用、內容與結構，請稍候", activity: "citation_repair" };
    case "citation_repair_completed":
      return { title: "報告修正完成", detail: "已完成驗證，準備儲存報告", activity: "citation_repair" };
    case "report_quality_started":
      return { title: "正在檢查報告內容", detail: "核對數據、條件、引用與需求涵蓋；畫面內容尚待確認", activity: "report_quality" };
    case "report_quality_completed":
      return { title: "報告內容檢查完成", detail: "已完成本次內容檢查，準備儲存報告", activity: "report_quality" };

    case "document_planning_started":
      return { title: "正在評估補讀需求", detail: "判斷是否需要更多搜尋結果或文件原文", activity: "agent_planning" };
    case "document_planning_completed":
      return { title: "補讀評估完成", detail: data.reason || "開始整理可引用的資料", activity: "agent_finish" };
    case "document_read_started":
      return { title: "正在補讀文件", detail: `${title}：${data.reason || "取得原文上下文"}`, activity: "draft_retrieve" };
    case "document_read_completed":
      return { title: "文件補讀完成", detail: `${title}；本次新增頁碼：${(data.pages_read || []).join("、") || "無"}${!data.complete || (data.incomplete_pages || []).length ? "；文件有尚未完整解析的頁面" : ""}${(data.omitted_pages || []).length ? "；部分內容因讀取上限未納入" : ""}${(data.unavailable_requested_pages || []).length ? "；指定頁面不存在或尚未完整解析" : ""}`, activity: "draft_retrieve" };
    case "document_read_failed":
    case "document_read_skipped":
      return { title: "沿用已取得資料", detail: data.reason || "補讀未取得新資料", activity: "agent_planning_fallback" };
    default:
      return null;
  }
}

function installWorkflowInspectorShortcut() {
  const brand = document.getElementById("organizationName");
  if (!brand) return;
  let clicks = [];
  brand.addEventListener("click", () => {
    const now = Date.now();
    clicks = clicks.filter((time) => now - time < 3000);
    clicks.push(now);
    if (clicks.length >= 5) {
      clicks = [];
      window.location.assign(`${window.location.protocol}//${window.location.hostname}:8082/`);
    }
  });
}

installWorkflowInspectorShortcut();

function draftStreamStatus(event, data) {
  const documentStatus = documentStreamStatus(event, data);
  if (documentStatus) return documentStatus;
  const count = Number(data.evidence_count || data.candidate_count || 0);
  const tag = data.corpus_label ? `${data.corpus_label} —` : "";
  const isReviewedGenerationUnit = data.input_kind === "reviewed_generation_units";

  switch (event) {
    case "topic_decomposition_started":
      return {
        title: "正在拆解題目",
        detail: "正在等待模型建立較精確的搜尋查詢詞",
        activity: "topic_decomposition",
      };

    case "topic_decomposition_completed":
      return {
        title: "題目拆解完成",
        detail: `已建立 ${Number(data.query_count || 1)} 個搜尋查詢詞，準備開始檢索`,
        activity: "topic_decomposition",
      };

    case "retrieval_query_started":
      return {
        title: `${data.round_number > 1 ? "執行補充檢索" : "正在檢索資料"}`,
        detail: `${tag} 第 ${data.round_number || 1} 輪、第 ${data.search_number || 1} 次搜尋：「${data.query || ""}」`,
        activity: "draft_retrieve",
      };

    case "retrieval_query_completed":
      {
        const cumulativeChunks = Number(data.cumulative_chunk_count || 0);
        const cumulativeDocuments = Number(data.cumulative_document_count || 0);
        const cumulative = cumulativeChunks
          ? `；累計 ${cumulativeChunks} 個命中區段，去重後 ${cumulativeDocuments} 份文件`
          : "";
      return {
        title: `檢索完成`,
        detail: `${tag} 第 ${data.round_number || 1} 輪、第 ${data.search_number || 1} 次找到 ${count} 個命中區段${cumulative}${
          data.failure_count
            ? `，另有 ${data.failure_count} 個來源讀取失敗`
            : ""
        }`,
        activity: "draft_retrieve",
      };
      }

    case "retrieval_hits_collected":
      return {
        title: "已建立文件審閱清單",
        detail: `${tag} 本次 ${Number(data.chunk_count || 0)} 個命中區段；累計 ${Number(data.cumulative_chunk_count || 0)} 個命中區段，依文件去重後為 ${Number(data.cumulative_document_count || 0)} 份`,
        activity: "draft_retrieve",
      };

    case "agent_planning_started":
      return {
        title: `正在評估檢索結果`,
        detail: `${tag} 分析 ${count} 筆候選資料來源，判斷是否需要進一步搜尋`,
        activity: "agent_planning",
      };

    case "agent_decision":
      return data.action === "search"
        ? {
            title: `需要補充資料`,
            detail: `${tag} 下一輪將搜尋：「${data.query || ""}」`,
            activity: "agent_follow_up",
          }
        : {
            title: `資料已足夠`,
            detail: `${tag} 停止補充檢索，開始整理可供回答使用的原文內容`,
            activity: "agent_finish",
          };

    case "agent_planning_fallback":
      return {
        title: `沿用目前檢索結果`,
        detail: `${tag} 未找到適合進一步執行的查詢，將使用現有資料繼續處理`,
        activity: "agent_planning_fallback",
      };

    case "context_compression_started":
      return {
        title: isReviewedGenerationUnit ? "正在整理生成內容" : "正在整理資料來源",
        detail: isReviewedGenerationUnit
          ? `${tag} 從 ${count} 段已審閱、建議採用的原文單元中選取可追溯的節錄`
          : `${tag} 從 ${count} 筆候選資料來源中挑選與問題最相關的原文片段`,
        activity: "context_compression",
      };

    case "context_compression_completed":
      return {
        title: isReviewedGenerationUnit ? "生成內容已整理完成" : "資料來源已整理完成",
        detail: isReviewedGenerationUnit
          ? `${tag} 保留 ${count} 段可追溯原文節錄，共 ${Number(data.char_count || 0).toLocaleString("zh-TW")} 字`
          : `${tag} 保留 ${count} 筆資料來源，共 ${Number(data.char_count || 0).toLocaleString("zh-TW")} 字${
          data.used_fallback ? "（已改用現有資料完成整理）" : ""
        }`,
        activity: "context_ready",
      };

    case "generation_context_compacted":
      return {
        title: "生成內容已依字數預算整理",
        detail: `${tag} ${Number(data.original_unit_count || 0)} 段已審閱原文單元共 ${Number(data.original_character_count || 0).toLocaleString("zh-TW")} 字，超過 ${Number(data.allowed_character_count || 0).toLocaleString("zh-TW")} 字預算；保留 ${Number(data.selected_unit_count || 0)} 段可追溯原文節錄，共 ${Number(data.compacted_character_count || 0).toLocaleString("zh-TW")} 字`,
        activity: "context_ready",
      };

    case "generation_evidence_ready":
      return {
        title: "報告生成資料已備妥",
        detail: `${tag} 已備妥 ${Number(data.selected_document_count || 0)} 份文件的 ${Number(data.selected_unit_count || 0)} 段${data.context_compacted ? "可追溯原文節錄" : "已審閱原文單元"}，共 ${Number(data.selected_character_count || 0).toLocaleString("zh-TW")} 字`,
        activity: "context_ready",
      };

    case "evidence_snapshot_loaded":
      return {
        title: "已載入先前資料來源",
        detail: `使用先前保留的 ${count} 筆資料來源 重新生成草稿`,
        activity: "evidence_snapshot_loaded",
      };

    case "run_evidence_loaded":
      return {
        title: "已載入本次資料來源",
        detail: `使用本次任務已選定的 ${count} 筆資料來源 重新生成草稿`,
        activity: "run_evidence_loaded",
      };

    case "draft_run_ready":
      return {
        title: "草稿資料準備完成",
        detail: `已備妥 ${count} 段供報告生成的原文內容，即將撰寫報告`,
        activity: "draft_run_ready",
      };

    case "citation_plan_started":
      return {
        title: "正在固定引用位置",
        detail: `直接固定 ${count} 段已選原文的位置，不等待額外引用模型`,
        activity: "citation_planning",
      };

    case "citation_plan_repair_started":
      return {
        title: "正在重新核對引用",
        detail: "第一次引用計畫未通過逐字定位，正在進行一次限定重試",
        activity: "citation_repair",
      };

    case "citation_plan_repair_completed":
      return {
        title: "引用重新核對完成",
        detail: `已確認 ${Number(data.citation_count || 0)} 處可定位原文`,
        activity: "citation_repair",
      };

    case "citation_plan_ready":
      return {
        title: "引用片段已備妥",
        detail: `已備妥 ${Number(data.citation_count || 0)} 個可定位原文片段，下一步開始撰寫完整報告`,
        activity: "citations_ready",
      };

    case "citations_ready":
      return {
        title: "引用片段已備妥",
        detail: `已備妥 ${data.citations?.length || 0} 個可定位原文片段`,
        activity: "citations_ready",
      };

    case "report_generation_started":
      return {
        title: "開始撰寫完整報告",
        detail: `從 ${Number(data.citation_count || 0)} 個已固定原文片段選取最貼近內容的引用，正文即將持續輸出`,
        activity: "vLLM_draft",
      };

    case "citation_validation_warning":
      return {
        title: "報告已完成，引用待補驗",
        detail: "正文會保存；本次未建立可定位的引用連結，請檢視內容後再重新生成",
        activity: "citation_repair",
      };

    case "draft_generation_started":
      return {
        title: "正在生成草稿",
        detail: "內容持續輸出中",
        activity: "vLLM_draft",
      };

    default:
      return window.DrafterWorkflow?.statusForEvent(event, data) || null;
  }
}

function createMandatoryReviewProgressTracker() {
  let total = 0;
  const terminalCandidateIds = new Set();
  const titleForProgress = (finished = terminalCandidateIds.size) =>
    `正在審閱文件（已完成 ${finished}/${total || "?"}）`;

  return (event, data) => {
    const documentTitle = data.title || data.candidate_id || "文件";

    if (event === "document_review_queue_ready") {
      const queuedCount = Number(data.document_count || 0);
      if (Number.isFinite(queuedCount) && queuedCount > 0) {
        total = Math.max(total, terminalCandidateIds.size + queuedCount);
      }
      return {
        title: total ? `建立文件審閱佇列（${terminalCandidateIds.size}/${total}）` : "建立文件審閱佇列",
        detail: queuedCount ? `新增 ${queuedCount} 份命中文件，將逐份審閱` : "正在建立所有命中文件的審閱佇列",
        activity: "document_review",
      };
    }
    const declaredTotal = Number(data.document_total || 0);
    if (Number.isFinite(declaredTotal) && declaredTotal > 0 && total === 0) total = declaredTotal;
    if (event === "document_review_started") {
      const batch = Number(data.batch_total || 1) > 1 ? `，第 ${data.batch_index || 1}/${data.batch_total} 批` : "";
      return {
        title: titleForProgress(),
        detail: `正在審閱：${documentTitle}${batch}`,
        activity: "document_review",
      };
    }
    if (event === "document_review_completed" || event === "document_review_failed") {
      const candidateId = String(data.candidate_id || "");
      if (candidateId) terminalCandidateIds.add(candidateId);
      const outcome = event === "document_review_completed" ? "已完成審閱" : "審閱失敗，已保留原因";
      return {
        title: titleForProgress(),
        detail: `${outcome}：${documentTitle}`,
        activity: "document_review",
      };
    }
    if (event === "document_review_all_completed") {
      const finished = terminalCandidateIds.size || total;
      return {
        title: `文件審閱完成（${finished}/${total || finished}）`,
        detail: data.all_documents_processed ? "所有命中文件均已完成處理，準備整理報告生成資料" : "文件審閱未完整，保留原因並停止自動生成",
        activity: "document_review",
      };
    }
    return null;
  };
}

function createDraftStreamHandler(retrieveJob, createDraftJob) {
  const preview = createIncrementalDraftPreview();
  const mandatoryReviewProgress = createMandatoryReviewProgressTracker();
  let textStarted = false;

  return (event, data) => {
    if (event === "draft_model_started") {
      stepOperation("正在確認引用原文位置", "正在選取引用原文並核對資料來源中的位置", 0, true);
      return;
    }
    if (event === "draft_timing") return;
    if (event === "draft_generation_started") textStarted = true;
    if (event === "complete") {
      preview.stop();
      return;
    }

    const reviewStatus = mandatoryReviewProgress(event, data);
    if (reviewStatus) {
      stepOperation(reviewStatus.title, reviewStatus.detail, 0, true);
      updateActivity(retrieveJob, reviewStatus.activity, reviewStatus.detail, "pending");
      return;
    }

    if (
      event === "draft_run_ready" ||
      event === "evidence_snapshot_loaded" ||
      event === "run_evidence_loaded"
    ) {
      if (data.retrieval_audit) state.retrievalAudit = data.retrieval_audit;
      if (Array.isArray(data.reviewed_evidence)) state.reviewedEvidence = data.reviewed_evidence;
      if (data.run_id) state.runId = data.run_id;
      if (Array.isArray(data.evidence) && data.evidence.length) {
        state.evidence = data.evidence;
        renderEvidence(state.evidence);
        updateActivity(retrieveJob, "draft_retrieve", `${state.evidence.length} 筆資料來源`, "done");
      }
      renderRetrievalAudit();
    }

    if (event === "citations_ready") {
      if (Array.isArray(data.citations) && data.citations.length) {
        state.citations = data.citations;
      }
      if (!textStarted) {
        stepOperation("引用片段已備妥", `已備妥 ${data.citations?.length || 0} 個可定位原文片段`, 0, true);
      } else {
        recordStatus("running", "引用片段已備妥", `已備妥 ${data.citations?.length || 0} 個可定位原文片段`);
      }
      return;
    }

    if (event === "draft_delta") {
      preview.append(data.text);
      return;
    }
    const status = draftStreamStatus(event, data);
    if (!status) return;
    const isGeneration = event === "draft_generation_started";
    const job = isGeneration ? createDraftJob() : retrieveJob;
    stepOperation(status.title, status.detail, 0, true);
    updateActivity(job, status.activity, status.detail, "pending");
  };
}

async function draftReply() {
  if (state.activeAbortController) {
    pauseCurrentOperation();
    return;
  }
  if (state.busyCount > 0) return;
  const button = $("requestDraftBtn");
  flashButton(button);
  const request = $("requestInput").value.trim();
  if (!request) return;
  syncAllSourceTabStates();
  const includedCorpuses = includedDraftCorpuses();
  if (!includedCorpuses.length) {
    setTemporaryStatus("error", "無資料來源", "請至少保留一個資料來源");
    return;
  }
  if (!includedCorpuses.includes(state.activeEvidenceCorpus)) {
    setEvidenceCorpus(includedCorpuses[0]);
  }
  const includedCorpusLabel = includedCorpuses.map(corpusDisplayName).join("、");
  resetDraftWorkspace();
  state.queryHighlightTerms = tokenizeSearchQuery(request);

  const controller = new AbortController();
  state.activeAbortController = controller;
  state.isPaused = false;
  updateFlowButtonsState(true, "request");
  setBusy(button, true);

  beginOperation("生成詳細報告", "等待檢索事件", `將使用 ${includedCorpusLabel} 搜尋資料`, 0);
  const retrieveJob = addActivity("draft_retrieve", `包含 ${includedCorpusLabel}`, "pending");
  let draftJob = null;
  try {
    const data = await streamDraft(
      { request, included_corpuses: includedCorpuses, temperature: 0 },
      createDraftStreamHandler(retrieveJob, () => {
        if (!draftJob) draftJob = addActivity("vLLM_draft", "模型開始即時輸出報告", "pending");
        return draftJob;
      }),
      controller.signal
    );
    updateActivity(retrieveJob, "draft_retrieve", `${(data.evidence || []).length} 筆資料來源`, "done");
    if (!draftJob) draftJob = addActivity("vLLM_draft", "模型回傳報告", "pending");
    stepOperation("驗證並儲存報告", "正在驗證引用並建立版本", 0, true);
    await applyDraftResponse(data, draftJob, "初始報告", "完整檢索後產生詳細報告");
    endOperation("報告完成", "詳細報告已生成", true);
  } catch (error) {
    if (controller.signal.aborted || error.name === "AbortError" || state.isPaused) {
      updateActivity(retrieveJob, "draft_retrieve paused", "使用者已暫停", "done");
      if (draftJob) updateActivity(draftJob, "vLLM_draft paused", "已暫停生成", "done");
      endOperation("已暫停生成", "報告生成已由使用者暫停，已保留目前內容", true);
      recordStatus("idle", "已暫停生成", "報告生成已暫停，已保留目前內容");
      return;
    }
    updateActivity(retrieveJob, "draft error", error.message, "error");
    updateActivity(draftJob, "vLLM_draft error", error.message, "error");
    const isValidationFailure = error.message && (
      error.message.includes("validation failed") ||
      error.message.includes("empty draft") ||
      error.message.includes("empty content")
    );
    const detail = isValidationFailure
      ? "報告格式驗證未通過，請重試或直接手動儲存畫面預覽"
      : (error.message || "目前無法生成報告，請稍後再試");
    endOperation("報告失敗", detail, false, error);
  } finally {
    state.activeAbortController = null;
    state.isPaused = false;
    updateFlowButtonsState(false);
    setBusy(button, false);
  }
}

async function regenerateDraftFromCurrentEvidence() {
  if (state.activeAbortController) {
    pauseCurrentOperation();
    return;
  }
  const button = $("sourceDraftBtn");
  if (button?.disabled) return;
  if (state.busyCount > 0) return;
  flashButton(button);
  const request = $("requestInput").value.trim();
  syncAllSourceTabStates();
  const evidence = usableCurrentEvidence();
  if (!request) return;
  if (!evidence.length) {
    setTemporaryStatus("error", "沒有可用資料", "請先搜尋並保留資料來源");
    return;
  }

  const controller = new AbortController();
  state.activeAbortController = controller;
  state.isPaused = false;
  updateFlowButtonsState(true, "source");
  setBusy(button, true);

  beginOperation("以更新後資料重新生成", "等待報告事件", "準備使用目前選用的資料", 0);
  const retrieveJob = addActivity("source_evidence_selected", `${evidence.length} 筆資料來源`, "pending");
  let draftJob = null;
  try {
    const data = await streamDraft(
      {
        request,
        temperature: 0,
        evidence_ids: evidence.map((item) => item.evidence_id),
        ...(state.evidenceSnapshotId ? { evidence_snapshot_id: state.evidenceSnapshotId } : {}),
        ...(state.runId ? { run_id: state.runId } : {}),
      },
      createDraftStreamHandler(retrieveJob, () => {
        if (!draftJob) draftJob = addActivity("vLLM_regenerate", "模型開始即時輸出報告", "pending");
        return draftJob;
      }),
      controller.signal
    );
    updateActivity(retrieveJob, "source_evidence_selected", `${(data.evidence || []).length} 筆資料來源`, "done");
    if (!draftJob) draftJob = addActivity("vLLM_regenerate", "模型回傳報告", "pending");
    stepOperation("驗證並儲存報告", "正在驗證引用並建立版本", 0, true);
    await applyDraftResponse(data, draftJob, "更新資料再生成", "使用資料來源區塊目前資料來源 重新生成報告");
    endOperation("報告已重新生成", "已使用目前資料更新報告", true);
  } catch (error) {
    if (controller.signal.aborted || error.name === "AbortError" || state.isPaused) {
      updateActivity(retrieveJob, "source_evidence_selected paused", "使用者已暫停", "done");
      if (draftJob) updateActivity(draftJob, "vLLM_regenerate paused", "已暫停生成", "done");
      endOperation("已暫停生成", "報告重新生成已由使用者暫停，已保留目前內容", true);
      recordStatus("idle", "已暫停生成", "報告重新生成已暫停，已保留目前內容");
      return;
    }
    updateActivity(draftJob, "vLLM_regenerate error", error.message, "error");
    const isValidationFailure = error.message && (
      error.message.includes("validation failed") ||
      error.message.includes("empty draft") ||
      error.message.includes("empty content")
    );
    const detail = isValidationFailure
      ? "報告格式驗證未通過，請重試或直接手動儲存畫面預覽"
      : (error.message || "目前無法重新生成報告，請稍後再試");
    endOperation("重新生成失敗", detail, false, error);
  } finally {
    state.activeAbortController = null;
    state.isPaused = false;
    updateFlowButtonsState(false);
    setBusy(button, false);
  }
}

async function reviseDraft(instruction, labelHint = "", displayInstruction = instruction) {
  if (state.busyCount > 0) return;
  const draft = latestDraftContent().trim();
  const request = $("requestInput").value.trim();
  if (!draft) {
    $("requestInput").value = `${request}\n\n補充指令：${displayInstruction}`.trim();
    setTemporaryStatus("error", "目前沒有報告", "指令已補入題目，請先檢索並生成詳細報告");
    return;
  }
  const button = $("sendCommandBtn") || $("commandInput");
  setBusy(button, true);
  const opName = labelHint || (displayInstruction.length > 16 ? `${displayInstruction.slice(0, 14)}...` : displayInstruction);
  beginOperation(`快速調整（${opName}）`, "正在分析修訂指令", displayInstruction, 0);
  const job = addActivity("revise_draft", displayInstruction, "pending");

  const preview = createIncrementalDraftPreview();

  const onRevisionEvent = (event, data) => {
    const documentStatus = documentStreamStatus(event, data);
    if (documentStatus) {
      stepOperation(documentStatus.title, documentStatus.detail, 0, true);
      return;
    }
    if (event === "revision_intent_classified") {
      const reason = data.reason || (data.needs_search ? "偵測到需擴充新事實" : "格式與語氣修訂");
      if (data.needs_search) {
        stepOperation("啟動補充檢索", `[快速調整] ${reason}`, 20, true);
        const queryText = (data.queries && data.queries.length) ? `（搜尋：${data.queries.join("、")}）` : "";
        recordStatus("pending", "快速調整：啟動補充檢索", `${reason}${queryText}`);
      } else {
        stepOperation("風格結構修訂", `[快速調整] ${reason}`, 30, true);
        recordStatus("pending", "快速調整：風格/結構修訂", reason);
      }
      return;
    }

    if (event === "retrieval_query_started") {
      const tag = data.corpus_label ? `[${data.corpus_label}] ` : "";
      stepOperation(`補充檢索中`, `${tag} 搜尋：「${data.query || ""}」`, 40, true);
      return;
    }

    if (event === "retrieval_query_completed") {
      const tag = data.corpus_label ? `[${data.corpus_label}] ` : "";
      stepOperation(`補充檢索完成`, `${tag} 找到 ${data.evidence_count || 0} 筆候選資料來源`, 60, true);
      return;
    }

    if (event === "revision_evidence_merged") {
      stepOperation("整合補充資料", `共整理 ${data.total_count} 筆資料來源（新增 ${data.supplemental_count} 筆）`, 70, true);
      recordStatus("done", "快速調整：已補充資料來源", `找到 ${data.supplemental_count} 筆新資料來源並整合至資料來源清單`);
      return;
    }

    if (event === "revision_drafting_started") {
      stepOperation("正在修訂報告", `模型開始依據最新資料來源修訂報告`, 80, true);
      return;
    }

    if (event === "draft_delta") {
      preview.append(data.text);
      return;
    }

    if (event === "complete") {
      preview.stop();
      return;
    }

    if (event === "citations_ready") {
      if (Array.isArray(data.citations) && data.citations.length) {
        state.citations = data.citations;
      }
      return;
    }
    const status = draftStreamStatus(event, data);
    if (status) {
      stepOperation(status.title, status.detail, 90, true);
      updateActivity(job, status.activity, status.detail, "pending");
    }
  };

  try {
    const data = await streamSSE(
      "/api/revise/stream",
      {
        run_id: state.runId,
        request,
        draft,
        instruction,
        display_instruction: displayInstruction,
        evidence_ids: usableCurrentEvidence().map((item) => item.evidence_id),
        ...(state.evidenceSnapshotId ? { evidence_snapshot_id: state.evidenceSnapshotId } : {}),
      },
      onRevisionEvent
    );

    const warnings = Array.isArray(data.warnings) ? data.warnings : [];
    $("draftEditor").value = data.draft || "";
    state.citations = data.citations || [];
    state.highlightedCitationId = null;
    if (Array.isArray(data.evidence) && data.evidence.length) {
      state.evidence = data.evidence;
      renderEvidence(state.evidence);
    }
    renderCitationLinks();
    if (data.draft_id) await refreshDraftVersions();
    state.selectedDraftId = data.draft_id || state.selectedDraftId;
    const label = labelHint || shortVersionLabel(displayInstruction) || "修訂";
    const revisedDraft = getDraftById(data.draft_id);
    updateActivity(job, "revise_done", data.draft_id ? draftDisplayName(revisedDraft, label) : "not saved", "done");
    attachVersionToActivity(job, data.draft_id, label, displayInstruction);
    renderDraftVersions();
    setDiffMode(true);
    endOperation(
      warnings.length ? "修訂完成但有警示" : "修訂完成",
      warnings.length ? warnings.join("；") : "草稿已更新",
      true
    );
    refreshSuggestions();
  } catch (error) {
    updateActivity(job, "revise_error", error.message, "error");
    endOperation("修訂失敗", error.message || "目前無法修訂草稿，請稍後再試", false, error);
  } finally {
    preview.stop();
    setBusy(button, false);
  }
}

async function sendCommand() {
  const input = $("commandInput");
  const displayInstruction = input.value.trim();
  if (!displayInstruction) return;
  const instruction = expandCommandReferences(displayInstruction);
  input.value = "";
  updateCharCounter(input);
  await reviseDraft(instruction, "", displayInstruction);
}

async function saveDraft() {
  const button = $("saveDraftBtn");
  if (button?.disabled) return;
  if (!state.runId) {
    addActivity("save skipped", "no active run");
    return;
  }
  const content = (state.diffMode ? latestDraftContent() : $("draftEditor").value).trim();
  if (!content) return;
  setBusy(button, true);
  beginOperation("儲存草稿版本", "正在儲存草稿", "寫入版本紀錄", 35);
  const job = addActivity("draft_save", "寫入 draft_versions", "pending");
  try {
    const data = await api("/api/save-draft", {
      method: "POST",
      body: JSON.stringify({ run_id: state.runId, content }),
    });
    await refreshDraftVersions();
    state.selectedDraftId = data.draft_id || state.selectedDraftId;
    const savedDraft = getDraftById(data.draft_id);
    updateActivity(job, "draft_saved", draftDisplayName(savedDraft, "手動儲存"), "done");
    attachVersionToActivity(job, data.draft_id, "手動儲存", "使用者手動儲存目前草稿");
    renderDraftVersions();
    setDiffMode(true);
    endOperation("草稿已儲存", "已新增一筆版本紀錄", true);
  } catch (error) {
    updateActivity(job, "save error", error.message, "error");
    endOperation("儲存失敗", "目前無法儲存草稿", false, error);
  } finally {
    setBusy(button, false);
  }
}

async function sendFeedback() {
  if (!state.runId) {
    addActivity("feedback skipped", "no active run");
    return;
  }
  if (!state.selectedRating) {
    addActivity("feedback skipped", "rating missing");
    return;
  }
  const button = $("feedbackBtn") || $("feedbackNote");
  setBusy(button, true);
  beginOperation("送出滿意度回饋", "正在送出回饋", "送出評價紀錄", 35);
  const job = addActivity("feedback_save", state.selectedRating, "pending");
  try {
    const data = await api("/api/feedback", {
      method: "POST",
      body: JSON.stringify({
        run_id: state.runId,
        rating: state.selectedRating,
        note: $("feedbackNote").value,
        draft_content: state.diffMode ? latestDraftContent() : $("draftEditor").value,
      }),
    });
    updateActivity(job, "feedback_saved", data.feedback_id, "done");
    setFeedbackPanelOpen(false);
    $("feedbackNote").value = "";
    updateCharCounter($("feedbackNote"));
    endOperation("回饋已送出", "謝謝你的回饋", true);
  } catch (error) {
    updateActivity(job, "feedback error", error.message, "error");
    endOperation("回饋失敗", "目前無法送出回饋", false, error);
  } finally {
    setBusy(button, false);
  }
}

function bindSplitters() {
  const workspace = document.querySelector(".workspace");
  const leftPane = document.querySelector(".request-pane");
  const centerPane = document.querySelector(".draft-pane");
  const rightPane = document.querySelector(".source-pane");
  const requestPane = leftPane;
  const versionPane = document.querySelector(".version-pane");
  const requestInput = $("requestInput");
  const quickActions = $("quickActions");
  const columnWidths = {
    centerMinimum: 620,
    sideMinimum: 200,
    sideCollapseThreshold: 160,
    sideExpandThreshold: 56,
  };

  function setColumns(left, center, right) {
    workspace.style.gridTemplateColumns = `${left}px var(--splitter-track) ${center}px var(--splitter-track) ${right}px`;
    workspace.classList.toggle("left-side-collapsed", left === 0);
    workspace.classList.toggle("right-side-collapsed", right === 0);
  }

  function currentColumns() {
    return {
      left: leftPane.getBoundingClientRect().width,
      center: centerPane.getBoundingClientRect().width,
      right: rightPane.getBoundingClientRect().width,
    };
  }

  function clamp(value, minimum, maximum) {
    return Math.min(Math.max(value, minimum), maximum);
  }

  function sidePaneWidth(startWidth, desiredWidth, maximumWidth) {
    if (startWidth === 0) {
      if (desiredWidth < columnWidths.sideExpandThreshold) return 0;
      return clamp(desiredWidth, columnWidths.sideMinimum, maximumWidth);
    }
    if (desiredWidth < columnWidths.sideCollapseThreshold) return 0;
    return clamp(desiredWidth, columnWidths.sideMinimum, maximumWidth);
  }

  function dragColumns(splitter, move) {
    if (!splitter) return;
    splitter.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      splitter.setPointerCapture(event.pointerId);
      const startX = event.clientX;
      const start = currentColumns();
      const onMove = (moveEvent) => move(start, moveEvent.clientX - startX);
      const onUp = () => {
        splitter.removeEventListener("pointermove", onMove);
        splitter.removeEventListener("pointerup", onUp);
        splitter.classList.remove("dragging");
      };
      splitter.classList.add("dragging");
      splitter.addEventListener("pointermove", onMove);
      splitter.addEventListener("pointerup", onUp);
    });
  }

  if (workspace && leftPane && centerPane && rightPane) {
    dragColumns(document.querySelector('[data-splitter="left"]'), (start, delta) => {
      const nextLeft = sidePaneWidth(
        start.left,
        start.left + delta,
        start.left + start.center - columnWidths.centerMinimum
      );
      setColumns(nextLeft, start.center + start.left - nextLeft, start.right);
    });
    dragColumns(document.querySelector('[data-splitter="right"]'), (start, delta) => {
      const nextRight = sidePaneWidth(
        start.right,
        start.right - delta,
        start.right + start.center - columnWidths.centerMinimum
      );
      setColumns(start.left, start.center + start.right - nextRight, nextRight);
    });
  }

  function dragHeight(splitter, target, apply) {
    if (!splitter || !target) return;
    splitter.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      splitter.setPointerCapture(event.pointerId);
      const startY = event.clientY;
      const startHeight = target.getBoundingClientRect().height;
      const onMove = (moveEvent) => apply(startHeight + moveEvent.clientY - startY);
      const onUp = () => {
        splitter.removeEventListener("pointermove", onMove);
        splitter.removeEventListener("pointerup", onUp);
        splitter.removeEventListener("pointercancel", onUp);
        splitter.classList.remove("dragging");
      };
      splitter.classList.add("dragging");
      splitter.addEventListener("pointermove", onMove);
      splitter.addEventListener("pointerup", onUp);
      splitter.addEventListener("pointercancel", onUp);
    });
  }

  dragHeight(document.querySelector('[data-splitter="request-draft"]'), requestPane, (height) => {
    const requestMinimum = 94;
    const versionMinimum = 72;
    const quickMinimum = quickActions?.classList.contains("two-row") ? 244 : 164;
    const workspaceStyle = getComputedStyle(workspace);
    const contentHeight = workspace.clientHeight
      - parseFloat(workspaceStyle.paddingTop)
      - parseFloat(workspaceStyle.paddingBottom);
    const splitterTrack = parseFloat(workspaceStyle.getPropertyValue("--splitter-track")) || 6;
    const rowGap = parseFloat(workspaceStyle.rowGap) || 0;
    const separatorSpace = (splitterTrack * 2) + (rowGap * 4);
    const maximum = Math.max(requestMinimum, contentHeight - versionMinimum - quickMinimum - separatorSpace);
    workspace.style.setProperty("--request-row", `${Math.max(requestMinimum, Math.min(maximum, height))}px`);
  });
  dragHeight(document.querySelector('[data-splitter="version-quick"]'), versionPane, (height) => {
    const quickMinimum = quickActions?.classList.contains("two-row") ? 244 : 164;
    const workspaceStyle = getComputedStyle(workspace);
    const contentHeight = workspace.clientHeight
      - parseFloat(workspaceStyle.paddingTop)
      - parseFloat(workspaceStyle.paddingBottom);
    const splitterTrack = parseFloat(workspaceStyle.getPropertyValue("--splitter-track")) || 6;
    const rowGap = parseFloat(workspaceStyle.rowGap) || 0;
    const separatorSpace = (splitterTrack * 2) + (rowGap * 4);
    const maximum = Math.max(72, contentHeight - requestPane.getBoundingClientRect().height - quickMinimum - separatorSpace);
    const nextHeight = Math.max(72, Math.min(maximum, height));
    workspace.style.setProperty("--version-row", `${nextHeight}px`);
    workspace.style.setProperty("--quick-row", `minmax(${quickMinimum}px, 1fr)`);
  });
}

function bindCollapseToggles() {
  const targets = {
    request: [".request-input-wrapper", '[data-splitter="request-draft"]'],
    source: [".source-tabs", "retrievalAuditPanel", "evidenceList"],
    draft: [".draft-body"],
    versions: ["versionMessages", '[data-splitter="version-quick"]'],
    quick: ["quickActions", ".quick-pane .chat-input-row"],
  };

  function resolveTarget(token) {
    if (token.startsWith(".") || token.startsWith("[")) return document.querySelector(token);
    return $(token);
  }

  for (const button of document.querySelectorAll(".collapse-toggle")) {
    button.addEventListener("click", () => {
      const key = button.dataset.collapseTarget;
      const elements = (targets[key] || []).map(resolveTarget).filter(Boolean);
      const collapsed = button.textContent.trim() === "-";
      for (const element of elements) {
        element.classList.toggle("is-collapsed", collapsed);
      }
      button.closest(".pane")?.classList.toggle("section-collapsed", collapsed);
      document.querySelector(".workspace")?.classList.toggle(`${key}-section-collapsed`, collapsed);
      button.textContent = collapsed ? "+" : "-";
      button.setAttribute("aria-expanded", collapsed ? "false" : "true");
      button.title = collapsed ? "恢復區塊" : "最小化區塊";
    });
  }
}

function bindEvents() {
  $("requestDraftBtn").addEventListener("click", () => {
    if (state.activeAbortController) {
      pauseCurrentOperation();
    } else {
      draftReply();
    }
  });
  $("sourceDraftBtn").addEventListener("click", () => {
    if ($("sourceDraftBtn").disabled) return;
    if (state.activeAbortController) {
      pauseCurrentOperation();
    } else {
      regenerateDraftFromCurrentEvidence();
    }
  });
  $("saveDraftBtn").addEventListener("click", saveDraft);
  $("themeToggleBtn").addEventListener("click", () => {
    setTheme(state.theme === "dark" ? "light" : "dark");
  });
  if ($("feedbackBtn")) $("feedbackBtn").addEventListener("click", sendFeedback);
  $("quoteSelectionBtn").addEventListener("mousedown", (event) => {
    event.preventDefault();
  });
  $("quoteSelectionBtn").addEventListener("click", commitPendingReference);
  const openEvidencePreviewFromTarget = (target) => {
    const clickable = target.closest(".meta-source-clickable");
    if (!clickable) return false;
    const evidenceIndex = Number(clickable.dataset.evidenceIndex);
    const item = state.evidence[evidenceIndex - 1];
    openPdfPreview(item || { chunk_id: clickable.dataset.chunkId, source: clickable.textContent.trim() });
    return true;
  };
  for (const sourceContentList of [$("evidenceList"), $("documentAuditList")]) {
    sourceContentList?.addEventListener("mouseup", handleEvidenceReferenceSelection);
    sourceContentList?.addEventListener("click", (event) => {
      if (!openEvidencePreviewFromTarget(event.target)) return;
      event.preventDefault();
      event.stopPropagation();
    });
    sourceContentList?.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      if (!openEvidencePreviewFromTarget(event.target)) return;
      event.preventDefault();
      event.stopPropagation();
    });
  }
  $("documentAuditFilters")?.addEventListener("click", (event) => {
    const button = event.target.closest("[data-document-audit-filter]");
    if (!button) return;
    state.documentAuditFilter = button.dataset.documentAuditFilter || "all";
    renderRetrievalAudit();
  });
  $("documentAuditList")?.addEventListener("click", (event) => {
    const preview = event.target.closest("[data-audit-preview]");
    if (preview) {
      event.preventDefault();
      openPdfPreview({ preview_chunk_id: preview.dataset.auditPreview, subject: preview.dataset.auditTitle || "文件" });
      return;
    }
    const button = event.target.closest("[data-reviewed-evidence-id]");
    if (button) updateReviewedEvidenceSelection(button.dataset.reviewedEvidenceId, button.dataset.reviewedAction);
  });
  $("retrievalAuditPanel")?.addEventListener("click", (event) => {
    const detailsToggle = event.target.closest("[data-retrieval-audit-details-toggle]");
    if (detailsToggle) {
      state.retrievalAuditDetailsOpen = !state.retrievalAuditDetailsOpen;
      renderRetrievalAudit();
      return;
    }
    const button = event.target.closest("[data-regenerate-from-selection]");
    if (button) regenerateDraftFromCurrentEvidence();
  });
  $("pdfModalCloseBtn")?.addEventListener("click", closePdfPreview);
  $("pdfModal")?.addEventListener("click", (event) => {
    if (event.target === $("pdfModal")) {
      closePdfPreview();
    }
  });
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      const modal = $("pdfModal");
      if (modal && !modal.classList.contains("hidden")) {
        closePdfPreview();
      }
    }
  });
  $("requestInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      if (!$("requestDraftBtn").disabled && !state.activeAbortController) draftReply();
    }
  });
  $("requestInput").addEventListener("mouseup", (event) => handleTextareaReferenceSelection("request", $("requestInput"), event));
  $("requestInput").addEventListener("keyup", (event) => {
    if (event.key === "Shift" || event.shiftKey || ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
      handleTextareaReferenceSelection("request", $("requestInput"), event);
    }
  });
  $("feedbackPanelToggle")?.addEventListener("click", () => {
    const isOpen = $("floatingFeedbackRow")?.classList.contains("expanded");
    setFeedbackPanelOpen(!isOpen);
  });
  $("feedbackNoteToggle").addEventListener("click", () => {
    setFeedbackPanelOpen(true);
    const wrap = $("inlineFeedbackWrap");
    const isExpanded = wrap.classList.toggle("expanded");
    $("feedbackNoteToggle")?.classList.toggle("active", isExpanded);
    if (isExpanded) $("feedbackNote").focus();
  });
  if ($("feedbackSubmitBtn")) {
    $("feedbackSubmitBtn").addEventListener("click", () => {
      sendFeedback();
    });
  }
  if ($("sendCommandBtn")) $("sendCommandBtn").addEventListener("click", sendCommand);
  $("commandInput").addEventListener("keydown", (event) => {
    if (deleteReferenceToken(event, $("commandInput"))) return;
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendCommand();
    }
  });
  $("commandInput").addEventListener("mouseup", () => selectReferenceTokenAtCursor($("commandInput")));
  $("feedbackNote").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendFeedback();
      $("inlineFeedbackWrap").classList.remove("expanded");
    }
  });
  const header = $("topbar");
  const topbarResizeHandle = $("topbarResizeHandle");
  let topbarExpandedHeight = Math.max(1, Math.round(header.getBoundingClientRect().height));
  const updateTopbarResizeState = () => {
    const collapsed = header.classList.contains("collapsed");
    if (!collapsed) topbarExpandedHeight = Math.max(1, Math.round(header.getBoundingClientRect().height));
    topbarResizeHandle.setAttribute("aria-valuemax", String(topbarExpandedHeight));
    topbarResizeHandle.setAttribute("aria-valuenow", collapsed ? "0" : String(topbarExpandedHeight));
    topbarResizeHandle.title = collapsed ? "向下拖曳以展開標題列" : "向上拖曳以收合標題列";
  };
  const setTopbarCollapsed = (collapsed) => {
    if (collapsed === header.classList.contains("collapsed")) return;
    if (collapsed) topbarExpandedHeight = Math.max(1, Math.round(header.getBoundingClientRect().height));
    header.classList.toggle("collapsed", collapsed);
    requestAnimationFrame(updateTopbarResizeState);
  };
  const headerResizeObserver = new ResizeObserver(updateTopbarResizeState);
  headerResizeObserver.observe(header);
  updateTopbarResizeState();
  topbarResizeHandle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    const startY = event.clientY;
    const startedCollapsed = header.classList.contains("collapsed");
    let committed = false;
    topbarResizeHandle.setPointerCapture(event.pointerId);
    topbarResizeHandle.classList.add("dragging");
    const onMove = (moveEvent) => {
      if (committed) return;
      const delta = moveEvent.clientY - startY;
      if (!startedCollapsed && delta <= -8) {
        committed = true;
        setTopbarCollapsed(true);
      } else if (startedCollapsed && delta >= 8) {
        committed = true;
        setTopbarCollapsed(false);
      }
    };
    const onEnd = () => {
      topbarResizeHandle.removeEventListener("pointermove", onMove);
      topbarResizeHandle.removeEventListener("pointerup", onEnd);
      topbarResizeHandle.removeEventListener("pointercancel", onEnd);
      topbarResizeHandle.classList.remove("dragging");
    };
    topbarResizeHandle.addEventListener("pointermove", onMove);
    topbarResizeHandle.addEventListener("pointerup", onEnd);
    topbarResizeHandle.addEventListener("pointercancel", onEnd);
  });
  topbarResizeHandle.addEventListener("keydown", (event) => {
    if (event.key === "ArrowUp" || event.key === "Home") {
      event.preventDefault();
      setTopbarCollapsed(true);
    } else if (event.key === "ArrowDown" || event.key === "End") {
      event.preventDefault();
      setTopbarCollapsed(false);
    }
  });
  /* Source search toggle */
  $("searchToggleBtn").addEventListener("click", () => {
    const wrap = $("inlineSearchWrap");
    const isExpanded = wrap.classList.toggle("expanded");
    $("searchToggleBtn").classList.toggle("active", isExpanded);
    $("searchToggleBtn").setAttribute("aria-expanded", String(isExpanded));
    if (isExpanded) $("sourceSearchInput").focus();
  });
  $("sourceSearchInput").addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      $("inlineSearchWrap").classList.remove("expanded");
      $("searchToggleBtn").classList.remove("active");
      $("searchToggleBtn").setAttribute("aria-expanded", "false");
      $("searchToggleBtn").focus();
      return;
    }
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      const query = $("sourceSearchInput").value.trim();
      if (query) {
        $("inlineSearchWrap").classList.remove("expanded");
        $("searchToggleBtn").classList.remove("active");
        $("searchToggleBtn").setAttribute("aria-expanded", "false");
        searchEvidence(query);
      }
    }
  });
  $("quickActions").addEventListener("click", (event) => {
    const button = event.target.closest(".quick-chip");
    if (!button || button.disabled || state.busyCount > 0 || !latestDraftContent().trim()) return;
    const instruction = button.dataset.instruction || button.textContent;
    reviseDraft(instruction, button.dataset.label || button.textContent);
  });
  $("quickActions").addEventListener(
    "wheel",
    (event) => {
      if (Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
      event.preventDefault();
      $("quickActions").scrollLeft += event.deltaY;
    },
    { passive: false }
  );
  const sourceTabs = document.querySelector(".source-tabs");
  sourceTabs?.addEventListener(
    "wheel",
    (event) => {
      if (sourceTabs.scrollWidth <= sourceTabs.clientWidth || Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
      event.preventDefault();
      sourceTabs.scrollLeft += event.deltaY;
    },
    { passive: false }
  );
  sourceTabs?.addEventListener("click", (event) => {
    const excludeBtn = event.target.closest(".exclude-toggle");
    if (excludeBtn) {
      event.stopPropagation();
      const tab = excludeBtn.closest(".source-tab[data-corpus]");
      if (!tab) return;
      const corpus = tab.dataset.corpus;
      if (state.excludedCorpuses.has(corpus)) {
        state.excludedCorpuses.delete(corpus);
      } else {
        state.excludedCorpuses.add(corpus);
      }
      syncSourceTabState(tab);
      if (state.activeEvidenceCorpus === corpus && state.excludedCorpuses.has(corpus)) {
        const fallback = firstIncludedCorpus();
        if (fallback) setEvidenceCorpus(fallback);
      }
      renderEvidence(state.evidence);
      return;
    }
    const tab = event.target.closest(".source-tab[data-corpus]");
    if (!tab || tab.disabled || state.excludedCorpuses.has(tab.dataset.corpus)) return;
    setEvidenceCorpus(tab.dataset.corpus);
    renderEvidence(state.evidence);
  });
  $("versionMessages").addEventListener("click", (event) => {
    const message = event.target.closest(".chat-message.has-version");
    if (!message) return;
    loadDraftVersion(getDraftById(message.dataset.draftId));
  });
  $("versionMessages").addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const message = event.target.closest(".chat-message.has-version");
    if (!message) return;
    event.preventDefault();
    loadDraftVersion(getDraftById(message.dataset.draftId));
  });
  $("diffViewer").addEventListener("click", (event) => {
    const button = event.target.closest(".inline-citation");
    if (!button) return;
    if (button.dataset.unverified === "true") {
      setTemporaryStatus("warning", "引用待確認", "此引用標記沒有可驗證的來源原文，未連結到資料來源。");
      return;
    }
    focusEvidence(Number(button.dataset.evidenceIndex), button.dataset.citationId || null, button.dataset.lineText || "");
  });
  function triggerFontFeedback(btn) {
    btn.classList.add("active-feedback");
    window.setTimeout(() => btn.classList.remove("active-feedback"), 200);
  }
  $("fontDecreaseBtn").addEventListener("click", () => {
    triggerFontFeedback($("fontDecreaseBtn"));
    setDraftFontSize(state.draftFontSize - 1);
  });
  $("fontIncreaseBtn").addEventListener("click", () => {
    triggerFontFeedback($("fontIncreaseBtn"));
    setDraftFontSize(state.draftFontSize + 1);
  });
  $("compareToggleBtn").addEventListener("click", () => {
    if ($("compareToggleBtn").disabled) return;
    setCompareMode(!state.compareMode);
  });
  $("copyBtn").addEventListener("click", async () => {
    const btn = $("copyBtn");
    if (btn.disabled) return;
    const text = editableDraftContent(state.diffMode ? latestDraftContent() : $("draftEditor").value).trim();
    if (!text) return;
    await copyToClipboard(text);
    btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
    btn.classList.add("copied");
    window.setTimeout(() => {
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
      btn.classList.remove("copied");
    }, 1500);
  });
  $("downloadDocxBtn").addEventListener("click", downloadCurrentDraftDocx);
  $("editModeBtn").addEventListener("click", () => setDiffMode(false));
  $("displayModeBtn").addEventListener("click", () => setDiffMode(true));
  $("baseVersionSelect").addEventListener("change", () => {
    state.comparisonBaseVersion = $("baseVersionSelect").value || null;
    if (state.diffMode) renderDiff();
    syncVersionSelectionUI();
    updateActionButtonsState();
  });
  $("draftEditor").addEventListener("input", () => {
    if (state.diffMode) renderDiff();
    renderCitationLinks();
    updateActionButtonsState();
  });
  $("draftEditor").addEventListener("mouseup", (event) => handleTextareaReferenceSelection("draft", $("draftEditor"), event));
  $("draftEditor").addEventListener("keyup", (event) => {
    if (event.key === "Shift" || event.shiftKey || ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
      handleTextareaReferenceSelection("draft", $("draftEditor"), event);
    }
  });
  $("diffViewer").addEventListener("mouseup", handleDisplayDraftReferenceSelection);
  document.addEventListener("mousedown", (event) => {
    if (
      event.target.closest("#quoteSelectionBtn") ||
      event.target.closest("#requestInput") ||
      event.target.closest("#draftEditor") ||
      event.target.closest("#diffViewer") ||
      event.target.closest("#evidenceList")
    ) {
      return;
    }
    hideSelectionQuote();
  });
  const statusPanel = $("statusPanel");
  if (statusPanel) {
    statusPanel.addEventListener("click", () => setStatusHistoryOpen(statusPanel.getAttribute("aria-expanded") !== "true"));
  }
  document.addEventListener("click", (event) => {
    if (!event.target.closest("#statusControl")) setStatusHistoryOpen(false);
  });
  for (const button of document.querySelectorAll(".rating")) {
    button.addEventListener("click", async () => {
      const rating = button.dataset.rating;
      const isAlreadySelected = button.classList.contains("selected");
      document.querySelectorAll(".rating").forEach((item) => {
        item.classList.remove("selected");
        item.classList.remove("pop-active");
      });

      if (isAlreadySelected) {
        state.selectedRating = null;
        return;
      }

      state.selectedRating = rating;
      button.classList.add("selected");
      button.classList.add("pop-active");
      window.setTimeout(() => button.classList.remove("pop-active"), 400);

      if (state.runId) {
        await sendFeedback();
      }
    });
  }
}

async function initializeApp() {
  bindCatControls();
  updateCatVisibility();
  bindEvents();
  bindCharCounters();
  bindSplitters();
  bindCollapseToggles();
  setTheme(initialTheme());
  setDraftFontSize(state.draftFontSize);
  syncAllSourceTabStates();
  renderEvidence([]);
  renderRetrievalAudit();
  renderQuickActions([]);
  setCompareMode(false);
  setDiffMode(true);
  updateActionButtonsState();
  await Promise.all([loadUiText(), loadFallbackSuggestions()]);
  setOperationState({
    state: "idle",
    title: state.uiText.idle_status_title || "待命",
    detail: state.uiText.idle_status_detail || "輸入題目後可搜尋資料或生成詳細報告",
    progress: 0,
  });
  if (document.fonts?.ready) await document.fonts.ready;
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  document.body.classList.remove("app-booting");
}

void initializeApp();
