# v0.1.0 7c9da0d topic-decomposition progress hotfix

This small overlay is explicitly for the existing v0.1.0 deployment built from
`7c9da0d6d8f479d8263a79329b89822178b2d172`. It displays 「正在拆解題目」 while
the model creates search terms before the first retrieval event, then displays
「題目拆解完成」 before ordinary retrieval begins.

It mounts only these files read-only into the existing images:

- `overlay/letter_poc/services/retrieval.py` →
  `/app/letter_poc/services/retrieval.py`
- `overlay/web/app.js` → `/app/web/app.js`
- `overlay/web/index.html` → `/app/web/index.html`
- `overlay/web/workflow-data.js` → `/app/web/workflow-data.js`

The prompt-inspector also mounts `workflow-data.js`. No image, prompt
catalogue, `.env`, database schema, or PostgreSQL volume changes. This does not
include a retry for an empty chat-model response.

## Install

Extract the archive anywhere readable by Docker and run:

```sh
./apply_hotfix.sh /path/to/drafter-report-0.1.0-7c9da0d
```

The script verifies checksums and the target `release.json` commit before it
recreates only `app` and `prompt-inspector`. Once both services are healthy,
use `Ctrl+F5` once in the browser.

## Rollback

Run the existing deployment without the override:

```sh
cd /path/to/drafter-report-0.1.0-7c9da0d
docker compose --env-file .env up -d --pull never --force-recreate app prompt-inspector
```

Do not use `docker compose down --volumes`.
