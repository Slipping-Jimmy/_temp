# v0.1.0 7c9da0d complete UI and citation hotfix r5

This small overlay upgrades the installed
`7c9da0d6d8f479d8263a79329b89822178b2d172` base to the runtime behavior of
the verified `12d29ce` candidate without transferring Docker images.

It includes the previously reported UI corrections:

- real quick-adjustment document-review progress instead of generic workflow
  descriptions;
- compact paragraph-level citation placement, bounded citation fragments, and
  document-title fallback instead of excessive unnamed citation chips; inline
  buttons retain the original six-character source-title abbreviation plus
  `...` rather than displaying only a numeric `[n]` marker;
- C-style grouped markers such as `[C5, C39]` are normalized into two verified,
  clickable source buttons; historical groups without saved source metadata are
  explicitly shown as unverified buttons rather than raw IDs;
- visible topic-decomposition wait before the first search query.
- source-pane filters simplified to `全部` / `報告引用` / `報告未引用`; parse
  completeness and failure states are shown on the relevant information card;
- the three source-pane filter labels use three truly equal-width columns;
- manual-search cards are included in the next regeneration by default and can
  be excluded/re-added individually without sending source text from the
  browser; the pending `套用並重新生成` action is an underlined text link.

The overlay mounts these current runtime files read-only into the app image:

- `letter_poc/domain/evidence.py`
- `letter_poc/services/drafting.py`
- `letter_poc/services/citation_ids.py`
- `letter_poc/services/retrieval.py`
- `web/app.js`, `web/index.html`, `web/styles.css`, and `web/workflow-data.js`

It also supplies the updated prompt catalogue. Prompt Inspector writes future
catalogue edits to the hotfix overlay's `overlay/letter_poc/prompts.yaml`, not
the old base directory. No image, `.env`, database schema, or PostgreSQL volume
is replaced. It does not add a retry for an upstream empty model response.

## Install

Extract the archive anywhere readable by Docker and run:

```sh
./apply_hotfix.sh /path/to/drafter-report-0.1.0-7c9da0d
```

The script verifies the exact target revision, its overlay checksums, and the
combined Compose configuration before recreating only app and prompt-inspector.
It also fixes the bind-mounted file/directory modes after extraction. Once both
services are healthy, use `Ctrl+F5` once in the browser.

## Rollback

Run the base deployment without the override:

```sh
cd /path/to/drafter-report-0.1.0-7c9da0d
docker compose --env-file .env up -d --pull never --force-recreate app prompt-inspector
```

Do not use `docker compose down --volumes`.
