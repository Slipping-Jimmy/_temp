# Unthrottled load test: unthrottled-20261020T080551Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_5c | sse_burst | 5 | 15 | 15 | 15 | 0.00 | 11 | 73.33 | 0 | 0 | 734.9 | 1038.2 | 1083.1 | 1.0 |
| stage_002_sse_burst_10c | sse_burst | 10 | 30 | 30 | 29 | 3.33 | 6 | 20.69 | 0 | 0 | 927.1 | 1534.7 | 1554.4 | 8.6 |
  - errors: `{"sse_record_save_error": 1}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
