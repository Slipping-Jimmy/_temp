# Unthrottled load test: unthrottled-20261021T105151Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_150c | sse_burst | 150 | 450 | 450 | 156 | 65.33 | 70 | 44.87 | 0 | 0 | 18932.4 | 21169.1 | 21426.0 | 175.1 |
  - errors: `{"client_sse_absolute_timeout": 2, "sse_missing_done_marker": 69, "sse_no_content": 223}`
| stage_002_sse_burst_200c | sse_burst | 200 | 600 | 600 | 1 | 99.83 | 1 | 100.00 | 0 | 200 | 12181.5 | 12181.5 | 12181.5 | 231.8 |
  - errors: `{"conversation_http_error": 189, "preparation_ConnectionError": 11, "sse_no_content": 399}`
| stage_003_sse_burst_250c | sse_burst | 250 | 750 | 750 | 0 | 100.00 | 0 | 0.00 | 0 | 750 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 727, "preparation_ConnectionError": 23}`
| stage_004_sse_burst_300c | sse_burst | 300 | 900 | 900 | 0 | 100.00 | 0 | 0.00 | 0 | 900 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 842, "preparation_ConnectionError": 58}`
| stage_005_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 0 | 100.00 | 0 | 0.00 | 0 | 1050 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 989, "preparation_ConnectionError": 61}`
| stage_006_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 0 | 100.00 | 0 | 0.00 | 0 | 1200 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 1121, "preparation_ConnectionError": 79}`
| stage_007_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 0 | 100.00 | 0 | 0.00 | 0 | 1350 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 1244, "preparation_ConnectionError": 106}`
| stage_008_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 0 | 100.00 | 0 | 0.00 | 0 | 1500 | N/A | N/A | N/A | N/A |
  - errors: `{"conversation_http_error": 1409, "preparation_ConnectionError": 91}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
