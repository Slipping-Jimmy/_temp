# Unthrottled load test: unthrottled-20261021T095112Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_55c | sse_burst | 55 | 165 | 165 | 162 | 1.82 | 13 | 8.02 | 0 | 0 | 6052.3 | 6523.0 | 12503.2 | 57.2 |
  - errors: `{"sse_missing_done_marker": 3}`
| stage_002_sse_burst_60c | sse_burst | 60 | 180 | 180 | 178 | 1.11 | 38 | 21.35 | 0 | 0 | 6896.7 | 7325.8 | 7941.6 | 61.2 |
  - errors: `{"client_sse_absolute_timeout": 2}`
| stage_003_sse_burst_65c | sse_burst | 65 | 195 | 195 | 191 | 2.05 | 30 | 15.71 | 0 | 0 | 7182.7 | 7750.3 | 8677.6 | 66.5 |
  - errors: `{"client_sse_absolute_timeout": 1, "sse_missing_done_marker": 3}`
| stage_004_sse_burst_70c | sse_burst | 70 | 210 | 210 | 206 | 1.90 | 47 | 22.82 | 0 | 0 | 7819.6 | 8500.9 | 10417.0 | 68.7 |
  - errors: `{"client_sse_absolute_timeout": 3, "sse_missing_done_marker": 1}`
| stage_005_sse_burst_75c | sse_burst | 75 | 225 | 225 | 225 | 0.00 | 48 | 21.33 | 0 | 0 | 8771.5 | 9648.9 | 9689.5 | 87.8 |
| stage_006_sse_burst_80c | sse_burst | 80 | 240 | 240 | 235 | 2.08 | 42 | 17.87 | 0 | 0 | 9631.0 | 10696.6 | 12429.7 | 88.8 |
  - errors: `{"client_sse_absolute_timeout": 1, "sse_missing_done_marker": 4}`
| stage_007_sse_burst_85c | sse_burst | 85 | 255 | 255 | 254 | 0.39 | 41 | 16.14 | 0 | 0 | 10462.5 | 11748.2 | 13948.6 | 108.1 |
  - errors: `{"client_sse_absolute_timeout": 1}`
| stage_008_sse_burst_90c | sse_burst | 90 | 270 | 270 | 269 | 0.37 | 59 | 21.93 | 0 | 0 | 11256.4 | 12653.3 | 12809.1 | 108.5 |
  - errors: `{"client_sse_absolute_timeout": 1}`
| stage_009_sse_burst_95c | sse_burst | 95 | 285 | 285 | 275 | 3.51 | 42 | 15.27 | 0 | 0 | 12469.1 | 13663.7 | 14040.5 | 115.7 |
  - errors: `{"client_sse_absolute_timeout": 1, "sse_missing_done_marker": 6, "sse_no_content": 3}`
| stage_010_sse_burst_100c | sse_burst | 100 | 300 | 300 | 296 | 1.33 | 27 | 9.12 | 0 | 0 | 13329.4 | 14040.9 | 14446.4 | 132.1 |
  - errors: `{"client_sse_absolute_timeout": 3, "sse_missing_done_marker": 1}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
