# Unthrottled load test: unthrottled-20261022T071013Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_150c | sse_burst | 150 | 450 | 450 | 442 | 1.78 | 51 | 11.54 | 0 | 0 | 22471.6 | 25622.8 | 70356.4 | 176.6 |
  - errors: `{"client_sse_absolute_timeout": 7, "sse_no_content": 1}`
| stage_002_sse_burst_200c | sse_burst | 200 | 600 | 600 | 406 | 32.33 | 38 | 9.36 | 0 | 0 | 32127.7 | 72808.4 | 74746.1 | 218.3 |
  - errors: `{"client_sse_absolute_timeout": 12, "sse_no_content": 180, "sse_record_save_error": 2}`
| stage_003_sse_burst_250c | sse_burst | 250 | 750 | 750 | 577 | 23.07 | 113 | 19.58 | 0 | 0 | 34738.3 | 44715.4 | 83864.8 | 338.8 |
  - errors: `{"client_sse_absolute_timeout": 9, "sse_model_communication_error": 1, "sse_no_content": 157, "sse_record_save_error": 6}`
| stage_004_sse_burst_300c | sse_burst | 300 | 900 | 900 | 729 | 19.00 | 88 | 12.07 | 0 | 0 | 40571.2 | 53329.9 | 94013.2 | 415.0 |
  - errors: `{"client_sse_absolute_timeout": 3, "sse_no_content": 164, "sse_record_save_error": 4}`
| stage_005_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 747 | 28.86 | 132 | 17.67 | 0 | 0 | 41377.9 | 53444.4 | 98400.4 | 417.3 |
  - errors: `{"client_sse_absolute_timeout": 26, "sse_model_communication_error": 1, "sse_no_content": 270, "sse_record_save_error": 6}`
| stage_006_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 936 | 22.00 | 244 | 26.07 | 0 | 0 | 52278.8 | 92524.9 | 105689.4 | 466.3 |
  - errors: `{"client_sse_absolute_timeout": 87, "sse_model_communication_error": 1, "sse_no_content": 176}`
| stage_007_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 624 | 53.78 | 162 | 25.96 | 28 | 0 | 55037.2 | 95644.6 | 122125.6 | 491.5 |
  - errors: `{"client_sse_absolute_timeout": 88, "sse_model_communication_error": 112, "sse_no_content": 519, "sse_record_save_error": 7}`
  - 60-second cutoff candidates: **28**
  - timeout basis: `{"first_token": 28}`
| stage_008_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 1350 | 10.00 | 255 | 18.89 | 636 | 0 | 68354.7 | 88026.5 | 125484.5 | 717.7 |
  - errors: `{"client_sse_absolute_timeout": 50, "sse_model_communication_error": 6, "sse_no_content": 92, "sse_record_save_error": 2}`
  - 60-second cutoff candidates: **636**
  - timeout basis: `{"first_token": 636}`

## 60-second cutoff boundary

The first cutoff candidate occurred at **stage_007_sse_burst_450c** (target=450, count=28).

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
