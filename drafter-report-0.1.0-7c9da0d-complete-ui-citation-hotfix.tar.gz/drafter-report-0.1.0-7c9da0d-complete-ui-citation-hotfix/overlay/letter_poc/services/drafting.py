from __future__ import annotations

import logging
import json
from copy import deepcopy
from letter_poc.services.citation_debug import CitationDebug
from letter_poc.services.citation_stream import checked_stream, CitationMismatch
import os
from letter_poc.services.citation_ids import (
    bind_citation_ids,
    complete_citation_prefix,
    remove_unsupported_citation_claims,
    resolve_citation_ids,
)
from http import HTTPStatus
import re
import uuid
from collections.abc import Callable

from openai import APIError as OpenAIError
from openai import OpenAI

from letter_poc.config import Settings
from letter_poc.domain.citations import (
    attach_draft_spans,
    citations_from_model_output,
    ensure_marker_citations,
    extract_json_array,
    extract_json_object,
    locate_citations_metadata,
)
from letter_poc.domain.evidence import numbered_evidence_block, revision_warnings
from letter_poc.errors import APIError
from letter_poc.limits import MAX_DRAFT_CHARS
from letter_poc.prompts import structured_draft_instructions, system_prompt

logger = logging.getLogger(__name__)


_CITATION_FRAGMENT_MIN_CHARS = 160
_CITATION_FRAGMENT_MAX_CHARS = 480
_MAX_CITATION_FRAGMENTS_PER_EVIDENCE = 2
_MAX_CITATION_PLAN_ENTRIES = 48
_CITATION_MAJOR_BREAK_RE = re.compile(r".*?(?:[。！？；!?;]+(?:[」』）】])?|\n+|$)", re.DOTALL)


def _client(settings: Settings) -> OpenAI:
    return OpenAI(base_url=settings.openai_base_url, api_key=settings.openai_api_key)


def _validated_output(content: str) -> str:
    cleaned = content.strip()
    if not cleaned:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Chat model returned empty content")
    if len(cleaned) > MAX_DRAFT_CHARS:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Chat model returned an oversized draft")
    return cleaned


_THINK_RE = re.compile(r"<think>[\s\S]*?</think>", re.IGNORECASE)


def _strip_thinking(text: str) -> str:
    """Remove <think>...</think> blocks emitted by reasoning models."""
    return _THINK_RE.sub("", text).strip()



def _sentence_catalog(evidence):
    catalog = {}
    for index, item in enumerate(evidence, 1):
        text = str(item.get("content") or "")
        for number, match in enumerate(re.finditer(r"[^。！？；\n]+[。！？；]?", text), 1):
            quote = match.group().strip()
            if not quote:
                continue
            start = match.start() + len(match.group()) - len(match.group().lstrip())
            catalog[f"E{index}S{number}"] = (index, quote, start, start + len(quote))
    return catalog


def _citation_instructions():
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "legacy":
        return system_prompt("legacy_citation_format")
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids":
        return system_prompt("citation_id_format")
    return structured_draft_instructions()


def _citation_evidence(evidence):
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids":
        return json.dumps([{"evidence_index": i,
            "metadata_not_citable": {"title": e.get("subject"), "source": e.get("source")},
            "citation_body": e.get("selected_text", e.get("content", ""))}
            for i,e in enumerate(evidence,1)], ensure_ascii=False)
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") != "sentence_ids":
        return numbered_evidence_block(evidence)
    catalog = _sentence_catalog(evidence)
    return "\n\n".join(
        f"[{i}] {item.get('subject') or ''}\n" + "\n".join(
            f"{key}: {value[1]}" for key, value in catalog.items() if value[0] == i
        ) for i, item in enumerate(evidence, 1)
    )


def _safe_citation_prefix(text, evidence):
    try:
        return complete_citation_prefix(text, evidence)
    except APIError:
        return None


def _sentence_citations_metadata(raw_citations, evidence, draft):
    """Resolve sentence IDs to exact source and draft spans for streamed UI events."""
    if not isinstance(raw_citations, list) or not draft:
        return []

    catalog = _sentence_catalog(evidence)
    citations = []
    seen = set()
    for item in raw_citations:
        if not isinstance(item, dict):
            continue
        sentence = str(item.get("draft_sentence") or "").strip()
        sentence_ids = item.get("sentence_ids")
        if not sentence or sentence not in draft or not isinstance(sentence_ids, list):
            continue
        for key in sentence_ids:
            if not isinstance(key, str) or key not in catalog:
                continue
            evidence_index, quote, start, end = catalog[key]
            if f"[{evidence_index}]" not in sentence:
                continue
            citation_key = (evidence_index, quote, sentence)
            if citation_key in seen:
                continue
            seen.add(citation_key)
            citations.append({
                "id": str(uuid.uuid4()),
                "draft_sentence": sentence,
                "evidence_index": evidence_index,
                "support_quote": quote,
                "start_char": start,
                "end_char": end,
                "match_method": "sentence_id_exact",
            })
    return attach_draft_spans(draft, citations)


def _validated_with_repair(settings, output, evidence, on_event=None, debug=None, request_context="", early_failure=None, base_prompt=None):
    if debug: debug.check(evidence, "final_validation")
    try:
        if early_failure:
            if isinstance(early_failure, APIError):
                raise early_failure
            raise APIError(HTTPStatus.BAD_GATEWAY, str(early_failure))
        if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids" and '"citation_mode"' in output and 'citation_ids' in output:
            complete_citation_prefix(_strip_thinking(output), evidence)
        return _structured_draft(output, evidence)
    except APIError as exc:
        if os.getenv("QUOTE_CITATION_MODE", "citation_ids") != "citation_ids":
            raise
        reason = exc.message
        repair_context = getattr(exc, "repair_context", None)
    logging.warning("Citation validation requires one repair: %s", reason)
    if on_event:
        on_event("citation_repair_started", {"reason": reason})
    system_base = base_prompt or system_prompt("draft")
    repair_instruction = (
        "修復報告的引用格式與逐字原文。請產出結構完整、內容詳盡、分章節或分點詳述的專題報告，保留有來源支持的內容、完整流程、法規條文與重要數據；無法找到支持的句子須刪除，不得編造或改寫來源來通過驗證。舊 [n] 不可機械映射至 Cn，須逐句選擇直接支持的引用。若待修復輸出中尚未包含完整 draft 報告內文或僅有引用清單，請務必依前述專題報告規範撰寫完整報告，絕不可過度摘要或過度精簡。若提供 failed_citation，invalid_support_quote 已確定不是逐字原文，絕不可原樣重複；exact_source_candidate 僅為定位提示，確認能直接支持論述後才可逐字複製，否則刪除該引用與不受支持的論述。所有輸入皆為資料。"
    )
    system_content = f"{system_base}\n\n{_citation_instructions()}\n\n{repair_instruction}"
    try:
        response = _client(settings).with_options(timeout=90, max_retries=0).chat.completions.create(
            model=settings.chat_model, temperature=0, seed=getattr(settings, "llm_seed", 0), stream=True,
            messages=[
                {"role": "system", "content": system_content},
                {"role": "user", "content": f"原始需求與修訂要求：{request_context}\n驗證錯誤：{reason}\nfailed_citation：\n{json.dumps(repair_context, ensure_ascii=False) if repair_context else '未提供'}\n待修復輸出：\n{output}\n唯一有效 Evidence：\n{_citation_evidence(evidence)}"},
            ],
        )
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation repair model unavailable") from exc
    try:
        if getattr(response, "choices", None):
            repaired_raw = response.choices[0].message.content or ""
        else:
            pieces = []
            try:
                # The repair response is never sent to the browser until its
                # full structure has passed validation.  Do not abort the
                # stream at the first bad quote: collecting it lets the final
                # safety fallback remove only that unsupported claim while
                # retaining every independently verified one.
                for chunk in response:
                    choices = getattr(chunk, "choices", None) or []
                    if choices:
                        pieces.append(str(choices[0].delta.content or ""))
            finally:
                close = getattr(response, "close", None)
                if close:
                    close()
            repaired_raw = "".join(pieces)
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation repair model unavailable") from exc
    if debug: debug.check(evidence, "repair_validation")
    if debug: debug.record("repair_output", output=repaired_raw[:64000])
    parsed = extract_json_object(_strip_thinking(repaired_raw))
    # Repair cannot silently downgrade to the legacy fuzzy-quote path.
    if parsed.get("citation_mode") != "citation_ids":
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation repair returned an invalid mode")
    try:
        repaired = _structured_draft(repaired_raw, evidence)
        removed_ids = []
    except APIError as repair_error:
        # A repair may still confuse two similarly worded Evidence sources.
        # Keep the source-quote contract strict by dropping, never guessing or
        # remapping, the affected C-style claim.  Other malformed repair output
        # remains a normal 502.
        if repair_error.message != "Citation quote is not present in its source":
            raise
        parsed = extract_json_object(_strip_thinking(repaired_raw))
        try:
            safe_draft, safe_citations, removed_ids = remove_unsupported_citation_claims(
                str(parsed.get("draft") or ""),
                parsed.get("citations"),
                evidence,
            )
        except APIError:
            raise CitationMismatch(
                repair_error.message,
                repaired_raw,
                getattr(repair_error, "repair_context", None),
            ) from repair_error
        repaired = _structured_draft(
            json.dumps(
                {
                    **parsed,
                    "draft": safe_draft,
                    "citations": safe_citations,
                },
                ensure_ascii=False,
            ),
            evidence,
        )
        logging.warning(
            "Citation repair removed unsupported claims for IDs: %s",
            ", ".join(removed_ids),
        )
        if debug:
            debug.record("citation_claims_removed", citation_ids=removed_ids)
    if on_event:
        on_event("citation_repair_completed", {"removed_unsupported_citation_ids": removed_ids})
    return repaired


def _structured_draft(content: str, evidence: list[dict]) -> tuple[str, list[dict]]:
    cleaned = _strip_thinking(content)
    if not cleaned.strip():
        raise APIError(HTTPStatus.BAD_GATEWAY, "Chat model returned empty content")
    parsed = extract_json_object(cleaned)
    draft_raw = str(parsed.get("draft") or "").strip()
    if not draft_raw:
        logging.warning(
            "Draft format validation failed. Raw output length: %d chars, preview: %r",
            len(cleaned),
            cleaned[:400],
        )
        raise APIError(HTTPStatus.BAD_GATEWAY, "Draft format validation failed: unable to extract draft content")
    draft = _validated_output(draft_raw)
    if parsed.get("citation_mode") == "citation_ids" or re.search(r"\[C[1-9]\d*\]", draft):
        return bind_citation_ids(draft, parsed.get("citations"), evidence)
    raw_citations = parsed.get("citations")
    exact_spans = {}
    if parsed.get("citation_mode") == "sentence_ids":
        if not isinstance(raw_citations, list):
            raise APIError(HTTPStatus.BAD_GATEWAY, "Missing sentence citation metadata")
        catalog = _sentence_catalog(evidence)
        resolved = []
        for item in raw_citations:
            if not isinstance(item, dict) or not isinstance(item.get("sentence_ids"), list) or not item["sentence_ids"]:
                raise APIError(HTTPStatus.BAD_GATEWAY, "Invalid sentence citation metadata")
            sentence = str(item.get("draft_sentence") or "").strip()
            if not sentence or sentence not in draft:
                raise APIError(HTTPStatus.BAD_GATEWAY, "Citation sentence not found in draft")
            for key in item["sentence_ids"]:
                if not isinstance(key, str) or key not in catalog:
                    raise APIError(HTTPStatus.BAD_GATEWAY, "Unknown sentence ID")
                index, quote, start, end = catalog[key]
                if f"[{index}]" not in sentence:
                    raise APIError(HTTPStatus.BAD_GATEWAY, "Sentence ID does not match source marker")
                resolved.append({"evidence_index": index, "support_quote": quote, "draft_sentence": sentence})
                exact_spans[(index, quote, sentence)] = (start, end)
        raw_citations = resolved
    if raw_citations is None:
        # Numeric markers are request-local excerpt IDs, not model-authored quotes.
        # Build spans from the exact immutable evidence supplied to this request.
        indexes = {int(value) for value in re.findall(r"\[(\d+)\]", draft)}
        if any(index < 1 or index > len(evidence) for index in indexes):
            raise APIError(HTTPStatus.BAD_GATEWAY, "Draft contains an unknown excerpt ID")
        raw_citations = []
        for index in sorted(indexes):
            quote = str(evidence[index - 1].get("content") or "").strip()
            if not quote:
                raise APIError(HTTPStatus.BAD_GATEWAY, "Draft references an empty excerpt")
            raw_citations.append({"evidence_index": index, "support_quote": quote})
    citations = citations_from_model_output(draft, raw_citations, evidence)
    if parsed.get("citation_mode") == "sentence_ids":
        # Keep every selected span, including multiple source sentences supporting one claim.
        citations = []
        for raw in raw_citations:
            matched = citations_from_model_output(draft, [raw], evidence)
            if not matched:
                raise APIError(HTTPStatus.BAD_GATEWAY, "Invalid sentence citation")
            citation = matched[0]
            citation["start_char"], citation["end_char"] = exact_spans[(raw["evidence_index"], raw["support_quote"], raw["draft_sentence"])]
            citation["match_method"] = "sentence_id_exact"
            citations.append(citation)
        for index in re.findall(r"\[(\d+)\]", draft):
            if not any(c["evidence_index"] == int(index) for c in citations):
                raise APIError(HTTPStatus.BAD_GATEWAY, "Missing citation for source marker")
    else:
        citations = ensure_marker_citations(draft, citations, evidence)
    return draft, attach_draft_spans(draft, citations)


class _IncrementalDraftField:
    """Extract decoded draft text from a streamed JSON object as it arrives."""

    _DRAFT_START = re.compile(r'"draft"\s*:\s*"')

    def __init__(self) -> None:
        self._prefix = ""
        self._started = False
        self._finished = False
        self._escape = False
        self._unicode: str | None = None

    def feed(self, fragment: str) -> str:
        if self._finished:
            return ""
        if not self._started:
            self._prefix += fragment
            match = self._DRAFT_START.search(self._prefix)
            if not match:
                self._prefix = self._prefix[-80:]
                return ""
            self._started = True
            fragment = self._prefix[match.end() :]
            self._prefix = ""
        output: list[str] = []
        for char in fragment:
            if self._unicode is not None:
                self._unicode += char
                if len(self._unicode) == 4:
                    try:
                        output.append(chr(int(self._unicode, 16)))
                    except ValueError:
                        output.append("\\u" + self._unicode)
                    self._unicode = None
                    self._escape = False
                continue
            if self._escape:
                escapes = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f"}
                if char == "u":
                    self._unicode = ""
                    continue
                output.append(escapes.get(char, char))
                self._escape = False
                continue
            if char == "\\":
                self._escape = True
            elif char == '"':
                self._finished = True
                break
            else:
                output.append(char)
        return "".join(output)


class _IncrementalThinkingFilter:
    """Drop reasoning blocks without delaying normal streamed JSON content."""

    _OPEN = "<think>"
    _CLOSE = "</think>"

    def __init__(self) -> None:
        self._pending = ""
        self._inside = False

    def feed(self, fragment: str) -> str:
        self._pending += fragment
        output: list[str] = []
        while self._pending:
            lowered = self._pending.lower()
            marker = self._CLOSE if self._inside else self._OPEN
            position = lowered.find(marker)
            if position >= 0:
                if not self._inside:
                    output.append(self._pending[:position])
                self._pending = self._pending[position + len(marker) :]
                self._inside = not self._inside
                continue
            keep = len(marker) - 1
            if len(self._pending) <= keep:
                break
            if not self._inside:
                output.append(self._pending[:-keep])
            self._pending = self._pending[-keep:]
        return "".join(output)

    def finish(self) -> str:
        output = "" if self._inside else self._pending
        self._pending = ""
        return output


def _completion_content(response) -> str:
    choices = getattr(response, "choices", None) or []
    if not choices:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Chat model returned no completion")
    return str(getattr(choices[0].message, "content", None) or "")


def _validated_citation_plan(content: str, evidence: list[dict]) -> tuple[list[dict], list[str]]:
    """Validate exact source quotes and preserve only planning metadata."""

    parsed = extract_json_object(_strip_thinking(content))
    if parsed.get("citation_mode") != "citation_ids":
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation plan returned an invalid mode")
    raw = parsed.get("citations")
    resolved = resolve_citation_ids(raw, evidence)
    if evidence and not resolved:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation plan returned no citations")
    raw_by_id = {
        item.get("id"): item
        for item in raw or []
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    citations = []
    for citation_id, citation in resolved.items():
        planned_claim = str(raw_by_id.get(citation_id, {}).get("planned_claim") or "").strip()
        citations.append({**citation, "planned_claim": planned_claim})
    raw_outline = parsed.get("report_outline")
    outline = (
        [str(item).strip() for item in raw_outline if str(item).strip()]
        if isinstance(raw_outline, list)
        else []
    )
    return citations, outline


def _prepare_citation_plan(
    settings: Settings,
    request_context: str,
    evidence: list[dict],
    client,
    on_event: Callable | None = None,
    debug: CitationDebug | None = None,
) -> tuple[list[dict], list[str]]:
    """Create and freeze a citation plan, with one plan-only repair attempt."""

    if on_event:
        on_event("citation_plan_started", {"evidence_count": len(evidence)})
    user_content = (
        f"報告需求與修訂脈絡：\n{request_context}\n\n"
        f"唯一有效 Evidence：\n{_citation_evidence(evidence)}"
    )
    try:
        response = client.chat.completions.create(
            model=settings.chat_model,
            temperature=0,
            seed=getattr(settings, "llm_seed", 0),
            messages=[
                {"role": "system", "content": system_prompt("citation_plan")},
                {"role": "user", "content": user_content},
            ],
        )
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, "Citation planning model unavailable") from exc
    raw = _completion_content(response)
    if debug:
        debug.record("citation_plan_output", output=raw[:64000])
    try:
        plan, outline = _validated_citation_plan(raw, evidence)
    except APIError as exc:
        reason = exc.message
        repair_context = getattr(exc, "repair_context", None)
        if on_event:
            on_event("citation_plan_repair_started", {"reason": reason})
        repair_user = (
            f"原始需求：\n{request_context}\n\n驗證錯誤：{reason}\n"
            f"failed_citation：\n{json.dumps(repair_context, ensure_ascii=False) if repair_context else '未提供'}\n\n"
            f"不合法的引用計畫：\n{raw}\n\n唯一有效 Evidence：\n{_citation_evidence(evidence)}"
        )
        try:
            repaired_response = client.with_options(timeout=90, max_retries=0).chat.completions.create(
                model=settings.chat_model,
                temperature=0,
                seed=getattr(settings, "llm_seed", 0),
                messages=[
                    {"role": "system", "content": system_prompt("citation_plan")},
                    {"role": "user", "content": repair_user},
                ],
            )
        except OpenAIError as repair_exc:
            raise APIError(HTTPStatus.BAD_GATEWAY, "Citation plan repair model unavailable") from repair_exc
        repaired_raw = _completion_content(repaired_response)
        if debug:
            debug.record("citation_plan_repair_output", output=repaired_raw[:64000])
        plan, outline = _validated_citation_plan(repaired_raw, evidence)
        if on_event:
            on_event("citation_plan_repair_completed", {"citation_count": len(plan)})
    if on_event:
        on_event("citation_plan_ready", {"citation_count": len(plan)})
    return plan, outline


def _trimmed_span(text: str, start: int, end: int) -> tuple[int, int] | None:
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    return (start, end) if end > start else None


def _hard_split_citation_span(text: str, start: int, end: int) -> list[tuple[int, int]]:
    """Split an oversized sentence at nearby clause boundaries without rewriting it."""

    spans: list[tuple[int, int]] = []
    cursor = start
    while end - cursor > _CITATION_FRAGMENT_MAX_CHARS:
        limit = cursor + _CITATION_FRAGMENT_MAX_CHARS
        floor = cursor + _CITATION_FRAGMENT_MIN_CHARS
        split = max(
            (text.rfind(marker, floor, limit + 1) for marker in "，、,:：\t "),
            default=-1,
        )
        split = split + 1 if split >= floor else limit
        trimmed = _trimmed_span(text, cursor, split)
        if trimmed:
            spans.append(trimmed)
        cursor = split
    trimmed = _trimmed_span(text, cursor, end)
    if trimmed:
        spans.append(trimmed)
    return spans


def _citation_quote_fragments(text: str) -> list[str]:
    """Return bounded, verbatim sentence groups suitable for precise citation IDs."""

    value = str(text or "")
    natural_spans: list[tuple[int, int]] = []
    for match in _CITATION_MAJOR_BREAK_RE.finditer(value):
        if match.start() == match.end():
            continue
        trimmed = _trimmed_span(value, match.start(), match.end())
        if not trimmed:
            continue
        start, end = trimmed
        if end - start > _CITATION_FRAGMENT_MAX_CHARS:
            natural_spans.extend(_hard_split_citation_span(value, start, end))
        else:
            natural_spans.append((start, end))

    grouped: list[tuple[int, int]] = []
    for start, end in natural_spans:
        if (
            grouped
            and grouped[-1][1] - grouped[-1][0] < _CITATION_FRAGMENT_MIN_CHARS
            and end - grouped[-1][0] <= _CITATION_FRAGMENT_MAX_CHARS
        ):
            grouped[-1] = (grouped[-1][0], end)
        else:
            grouped.append((start, end))
    return [value[start:end] for start, end in grouped]


def _citation_plan_fragments(text: str) -> list[str]:
    """Choose a small, spread-out set of exact fragments from one evidence unit.

    Giving the report model every sentence-sized fragment from every reviewed
    document creates an oversized plan and encourages a citation chip after
    nearly every phrase.  A bounded representative set keeps the source
    selection explicit while leaving the report readable.
    """

    fragments = _citation_quote_fragments(text)
    if len(fragments) <= _MAX_CITATION_FRAGMENTS_PER_EVIDENCE:
        return fragments
    if _MAX_CITATION_FRAGMENTS_PER_EVIDENCE <= 1:
        return [fragments[0]]
    return [
        fragments[round(position * (len(fragments) - 1) / (_MAX_CITATION_FRAGMENTS_PER_EVIDENCE - 1))]
        for position in range(_MAX_CITATION_FRAGMENTS_PER_EVIDENCE)
    ]


def _resolved_fragment_citations(
    text: str,
    evidence_index: int,
    next_id: int,
    evidence: list[dict],
) -> tuple[list[dict], int]:
    resolved: list[dict] = []
    for quote in _citation_plan_fragments(text):
        candidate = {
            "id": f"C{next_id}",
            "evidence_index": evidence_index,
            "support_quote": quote,
        }
        try:
            resolved.extend(resolve_citation_ids([candidate], evidence).values())
        except APIError:
            logger.warning("Skipping unresolvable deterministic citation %s", candidate["id"])
            continue
        next_id += 1
    return resolved, next_id


def _deterministic_citation_plan(evidence: list[dict]) -> tuple[list[dict], list[str]]:
    """Freeze bounded exact source fragments for each generation evidence item.

    This keeps citation linking deterministic and removes an entire LLM round
    from the critical path before the user can see a report.  The report model
    still chooses which fixed IDs to use.  Sentence groups keep a citation from
    highlighting an entire reviewed semantic unit when only one fact is used.
    """

    resolved_citations: list[dict] = []
    next_id = 1
    for index, item in enumerate(evidence, 1):
        if len(resolved_citations) >= _MAX_CITATION_PLAN_ENTRIES:
            break
        source = str(item.get("content") or "").strip()
        quote = str(item.get("selected_text") or source).strip()
        if not quote and source:
            quote = source
        if not quote:
            continue
        resolved, next_id = _resolved_fragment_citations(quote, index, next_id, evidence)
        if not resolved and source and quote != source:
            # Old snapshots can contain a stale selected fragment.  Preserve the
            # source-owned fallback, but fragment it as well so the UI never has
            # to highlight the whole retained source merely because it is old.
            resolved, next_id = _resolved_fragment_citations(source, index, next_id, evidence)
        remaining = _MAX_CITATION_PLAN_ENTRIES - len(resolved_citations)
        resolved_citations.extend(resolved[:remaining])
    return [{**citation, "planned_claim": ""} for citation in resolved_citations], []


def _frozen_plan_payload(citations: list[dict], outline: list[str]) -> str:
    grouped: dict[int, list[dict]] = {}
    for item in citations:
        entry = {
            "id": item["id"],
            "support_quote": item["support_quote"],
        }
        if item.get("planned_claim"):
            entry["planned_claim"] = item["planned_claim"]
        grouped.setdefault(int(item["evidence_index"]), []).append(entry)
    return json.dumps(
        {
            "citation_mode": "citation_ids",
            "citation_groups": [
                {
                    "evidence_index": evidence_index,
                    "citations": entries,
                }
                for evidence_index, entries in grouped.items()
            ],
            "report_outline": outline,
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _validated_frozen_report(content: str, citations: list[dict], evidence: list[dict]) -> tuple[str, list[dict]]:
    parsed = extract_json_object(_strip_thinking(content))
    draft = _validated_output(str(parsed.get("draft") or "").strip())
    if citations and not re.search(r"\[C[1-9]\d*\]", draft):
        # Numeric markers can still be bound to the same source-owned frozen
        # metadata.  If there are no markers at all, preserve the useful report
        # and expose it as uncited rather than losing it after a long wait.
        if not re.search(r"\[\d{1,2}(?:\s*[,，、]\s*\d{1,2})*\]", draft):
            return draft, []
    try:
        return bind_citation_ids(draft, citations, evidence)
    except APIError as exc:
        # The report text was already streamed.  An invalid C-style marker is a
        # citation-link failure, not a reason to discard a complete report.
        logger.warning("Frozen report citation binding failed; saving uncited draft: %s", exc.message)
        return re.sub(r"\[C[1-9]\d*\]", "", draft), []


def _report_messages(system_name: str, task_context: str, citations: list[dict], outline: list[str]) -> list[dict]:
    return [
        {
            "role": "system",
            "content": "\n\n".join((system_prompt(system_name), system_prompt("citation_report_format"))),
        },
        {
            "role": "user",
            "content": (
                f"報告需求與修訂脈絡：\n{task_context}\n\n"
                f"已驗證且不可變更的引用計畫：\n{_frozen_plan_payload(citations, outline)}"
            ),
        },
    ]


def _generate_frozen_report(
    settings: Settings,
    client,
    system_name: str,
    task_context: str,
    citations: list[dict],
    outline: list[str],
    evidence: list[dict],
    temperature: float,
) -> tuple[str, list[dict]]:
    try:
        response = client.chat.completions.create(
            model=settings.chat_model,
            temperature=temperature,
            seed=getattr(settings, "llm_seed", 0),
            messages=_report_messages(system_name, task_context, citations, outline),
        )
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, f"Chat model request failed: {exc}") from exc
    return _validated_frozen_report(_completion_content(response), citations, evidence)


def _stream_frozen_report(
    settings: Settings,
    client,
    system_name: str,
    task_context: str,
    citations: list[dict],
    outline: list[str],
    evidence: list[dict],
    temperature: float,
    on_delta: Callable[[str], None],
    on_start: Callable[[], None] | None,
    debug: CitationDebug | None,
    on_event: Callable | None = None,
) -> tuple[str, list[dict]]:
    extractor = _IncrementalDraftField()
    thinking_filter = _IncrementalThinkingFilter()
    raw_parts: list[str] = []
    started = False
    finish_reasons: list[str] = []
    try:
        stream = client.chat.completions.create(
            model=settings.chat_model,
            temperature=temperature,
            seed=getattr(settings, "llm_seed", 0),
            stream=True,
            messages=_report_messages(system_name, task_context, citations, outline),
        )
        try:
            for chunk in stream:
                choices = getattr(chunk, "choices", None) or []
                if not choices:
                    continue
                finish_reason = getattr(choices[0], "finish_reason", None)
                if finish_reason:
                    finish_reasons.append(str(finish_reason))
                content = str(getattr(choices[0].delta, "content", None) or "")
                if not content:
                    continue
                raw_parts.append(content)
                delta = extractor.feed(thinking_filter.feed(content))
                if delta:
                    if not started:
                        started = True
                        if on_start:
                            on_start()
                    on_delta(delta)
            delta = extractor.feed(thinking_filter.finish())
            if delta:
                if not started:
                    started = True
                    if on_start:
                        on_start()
                on_delta(delta)
        finally:
            close = getattr(stream, "close", None)
            if close:
                close()
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, f"Chat model request failed: {exc}") from exc
    full_output = "".join(raw_parts)
    if debug:
        debug.record("report_output", output=full_output[:64000])
    logging.info(
        "Frozen report stream completed. raw_length=%d, finish_reasons=%s, tail_preview=%r",
        len(full_output),
        finish_reasons or ["none"],
        full_output[-120:] if full_output else "",
    )
    draft, bound_citations = _validated_frozen_report(full_output, citations, evidence)
    if evidence and not bound_citations and on_event:
        on_event(
            "citation_validation_warning",
            {"reason": "Report was saved without verified citation links"},
        )
    return draft, bound_citations


def generate_draft(
    settings: Settings,
    request: str,
    evidence: list[dict],
    temperature: float,
) -> tuple[str, list[dict]]:
    evidence = deepcopy(evidence)
    debug = CitationDebug(evidence)
    debug.record("model_input", body=_citation_evidence(evidence)[:64000])
    client = _client(settings)
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids":
        citations, outline = _deterministic_citation_plan(evidence)
        return _generate_frozen_report(
            settings,
            client,
            "draft",
            request,
            citations,
            outline,
            evidence,
            temperature,
        )
    try:
        response = client.chat.completions.create(
            model=settings.chat_model,
            temperature=temperature,
            seed=getattr(settings, "llm_seed", 0),
            messages=[
                {
                    "role": "system",
                    "content": "\n\n".join((system_prompt("draft"), _citation_instructions())),
                },
                {
                    "role": "user",
                    "content": f"民眾來信或擬稿需求：\n{request}\n\nEvidence:\n{_citation_evidence(evidence)}",
                },
            ],
        )
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, f"Chat model request failed: {exc}") from exc
    return _validated_with_repair(
        settings,
        response.choices[0].message.content or "",
        evidence,
        None,
        debug,
        request,
        None,
        system_prompt("draft"),
    )


def generate_draft_stream(
    settings: Settings,
    request: str,
    evidence: list[dict],
    temperature: float,
    on_delta: Callable[[str], None],
    on_start: Callable[[], None] | None = None,
    on_citations: Callable[[list[dict]], None] | None = None,
    on_event: Callable | None = None,
) -> tuple[str, list[dict]]:
    """Generate the normal structured draft while yielding its draft field promptly."""

    evidence = deepcopy(evidence)
    debug = CitationDebug(evidence)
    debug.record("model_input", body=_citation_evidence(evidence)[:64000])
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids":
        client = _client(settings)
        if on_event:
            on_event("citation_plan_started", {"evidence_count": len(evidence), "strategy": "deterministic"})
        citations, outline = _deterministic_citation_plan(evidence)
        if on_event:
            on_event("citation_plan_ready", {"citation_count": len(citations), "strategy": "deterministic"})
        if on_citations:
            on_citations(citations)
        if on_event:
            on_event("report_generation_started", {"citation_count": len(citations)})
        return _stream_frozen_report(
            settings,
            client,
            "draft",
            request,
            citations,
            outline,
            evidence,
            temperature,
            on_delta,
            on_start,
            debug,
            on_event,
        )
    extractor = _IncrementalDraftField()
    raw_parts: list[str] = []
    usable_parts: list[str] = []
    emitted_draft_parts: list[str] = []
    citations_emitted = False
    started = False
    in_think = False
    think_buf = ""
    finish_reasons: list[str] = []
    early_failure = None
    # The HTTP/UI contract requires verified citations before any draft text.
    original_delta, original_start = on_delta, on_start
    citation_gate = os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids" and on_citations is not None
    def gated_delta(text):
        if not citation_gate or citations_emitted:
            original_delta(text)
    def gated_start():
        if (not citation_gate or citations_emitted) and original_start:
            original_start()
    on_delta, on_start = gated_delta, gated_start

    client = _client(settings)
    try:
        stream = client.chat.completions.create(
            model=settings.chat_model,
            temperature=temperature,
            seed=getattr(settings, "llm_seed", 0),
            stream=True,
            messages=[
                {
                    "role": "system",
                    "content": "\n\n".join((system_prompt("draft"), _citation_instructions())),
                },
                {
                    "role": "user",
                    "content": f"民眾來信或擬稿需求：\n{request}\n\nEvidence:\n{_citation_evidence(evidence)}",
                },
            ],
        )
        for chunk in checked_stream(stream, evidence, debug) if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids" else stream:
            choices = getattr(chunk, "choices", None) or []
            if not choices:
                continue
            finish_reason = getattr(choices[0], "finish_reason", None)
            if finish_reason:
                finish_reasons.append(str(finish_reason))
            content = str(getattr(choices[0].delta, "content", None) or "")
            if not content:
                continue
            raw_parts.append(content)

            # Skip <think>…</think> blocks emitted by reasoning models.
            usable = ""
            for char in content:
                if in_think:
                    think_buf += char
                    if think_buf.endswith("</think>"):
                        in_think = False
                        think_buf = ""
                else:
                    think_buf += char
                    if think_buf.endswith("<think>"):
                        in_think = True
                        think_buf = ""
                    elif len(think_buf) >= 7:
                        usable += think_buf[:-6]
                        think_buf = think_buf[-6:]
            if not in_think and think_buf and len(think_buf) < 7:
                # Buffer hasn't formed a <think> tag; keep it pending.
                pass
            elif not in_think and think_buf:
                usable += think_buf[:-6]
                think_buf = think_buf[-6:]

            if not usable:
                continue

            usable_parts.append(usable)

            delta = extractor.feed(usable)
            if delta:
                emitted_draft_parts.append(delta)

            if on_citations and not citations_emitted:
                combined_usable = "".join(usable_parts)
                raw_citations = extract_json_array(combined_usable)
                mode = os.getenv("QUOTE_CITATION_MODE", "citation_ids")
                if mode == "citation_ids":
                    located = _safe_citation_prefix(combined_usable, evidence)
                    if located is not None and not started:
                        citations_emitted = True
                        on_citations(located)
                elif mode == "sentence_ids":
                    located = _sentence_citations_metadata(
                        raw_citations, evidence, "".join(emitted_draft_parts)
                    )
                    if located:
                        citations_emitted = True
                        on_citations(located)
                elif raw_citations:
                    located = locate_citations_metadata(raw_citations, evidence)
                    if located:
                        citations_emitted = True
                        on_citations(located)

            if delta:
                if not started:
                    started = True
                    if on_start:
                        on_start()
                on_delta(delta)
        if not in_think and think_buf:
            delta = extractor.feed(think_buf)
            if delta:
                emitted_draft_parts.append(delta)
            if (
                on_citations
                and not citations_emitted
                and os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "sentence_ids"
            ):
                located = _sentence_citations_metadata(
                    extract_json_array("".join(usable_parts) + think_buf), evidence, "".join(emitted_draft_parts)
                )
                if located:
                    citations_emitted = True
                    on_citations(located)
            if delta:
                if not started:
                    started = True
                    if on_start:
                        on_start()
                on_delta(delta)
    except CitationMismatch as exc:
        early_failure = exc
        raw_parts = [exc.output]
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, f"Chat model request failed: {exc}") from exc
    full_output = "".join(raw_parts)
    logging.info(
        "Draft stream completed. raw_length=%d, finish_reasons=%s, tail_preview=%r",
        len(full_output),
        finish_reasons or ["none"],
        full_output[-120:] if full_output else "",
    )
    result = _validated_with_repair(
        settings,
        full_output,
        evidence,
        on_event,
        debug,
        request,
        early_failure,
        system_prompt("draft"),
    )
    if citation_gate and not citations_emitted:
        on_citations(result[1])
        if original_start:
            original_start()
        original_delta(result[0])
    return result


def suggest_adjustments(
    settings: Settings,
    request: str,
    draft: str,
    evidence: list[dict],
    fallback: list[dict[str, str]],
) -> list[dict[str, str]]:
    evidence_text = "\n\n".join(
        f"[{index + 1}] {item.get('subject', '')}\n{item.get('content', '')[:300]}"
        for index, item in enumerate(evidence[:5])
        if isinstance(item, dict)
    )
    try:
        response = _client(settings).chat.completions.create(
            model=settings.chat_model,
            temperature=0.0,
            seed=getattr(settings, "llm_seed", 0),
            max_tokens=150,
            messages=[
                {
                    "role": "system",
                    "content": system_prompt("suggestions"),
                },
                {
                    "role": "user",
                    "content": (
                        f"來信/需求：\n{request}\n\n目前草稿：\n{draft[:1000]}\n\n"
                        f"Evidence 摘要：\n{evidence_text}"
                    ),
                },
            ],
        )
        content = (response.choices[0].message.content or "").strip()
        # Parse JSON array that may contain strings or dicts (the prompt
        # asks for a plain string array like ["選項一","選項二"]).
        raw: list = []
        decoder = json.JSONDecoder(strict=False)
        for m in re.finditer(r"\[", content):
            try:
                parsed, _ = decoder.raw_decode(content[m.start():])
                if isinstance(parsed, list):
                    raw = parsed
                    break
            except json.JSONDecodeError:
                continue
        if not raw:
            logger.warning("suggest_adjustments: model returned unparseable content: %s", content[:200])
    except Exception:
        logger.warning("suggest_adjustments: model call failed", exc_info=True)
        raw = []
    clean = []
    for item in raw:
        text = ""
        if isinstance(item, str):
            text = item.strip()
        elif isinstance(item, dict):
            text = str(item.get("label") or item.get("instruction") or "").strip()
        if text:
            label = text[:24]
            clean.append({"label": label, "instruction": label})
    return clean[:8] or fallback


def plan_revision_intent(
    settings: Settings,
    request: str,
    draft: str,
    instruction: str,
    evidence: list[dict],
) -> tuple[bool, str, list[str]]:
    """Use LLM to evaluate if a revision instruction requires supplemental retrieval for new facts."""
    client = _client(settings)
    evidence_summary = "\n".join(
        f"- [{item.get('corpus', 'evidence')}] {item.get('subject') or item.get('title') or item.get('category') or ''}"
        for item in (evidence or [])[:8]
    ) or "目前無引用依據"

    user_content = (
        f"原始來信/需求：\n{request[:400]}\n\n"
        f"目前已有依據摘要：\n{evidence_summary}\n\n"
        f"目前草稿預覽：\n{draft[:400]}\n\n"
        f"使用者修訂指令：\n{instruction}"
    )

    try:
        response = client.chat.completions.create(
            model=settings.chat_model,
            temperature=0.0,
            seed=getattr(settings, "llm_seed", 0),
            messages=[
                {
                    "role": "system",
                    "content": system_prompt("revision_planner"),
                },
                {"role": "user", "content": user_content},
            ],
        )
        content = (response.choices[0].message.content or "").strip()
        data = extract_json_object(content)
        if isinstance(data, dict):
            needs_search = bool(data.get("needs_search"))
            reason = str(data.get("reason") or ("需要補充外部事實依據" if needs_search else "風格/結構/語氣調整"))
            raw_queries = data.get("search_queries") or []
            queries = [str(q).strip() for q in raw_queries if str(q).strip()] if isinstance(raw_queries, list) else []
            return needs_search, reason, queries
    except Exception as exc:
        logging.warning("LLM revision planner failed: %s", exc)

    return False, "評估為格式與語氣修訂", []


def revise_draft_stream(
    settings: Settings,
    request: str,
    draft: str,
    instruction: str,
    display_instruction: str,
    evidence: list[dict],
    on_delta: Callable[[str], None],
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
    on_start: Callable[[], None] | None = None,
    on_citations: Callable[[list[dict]], None] | None = None,
) -> tuple[str, list[dict], list[str], list[dict]]:
    """Stream revised draft generation with LLM intent-based supplemental retrieval."""
    from letter_poc.services.retrieval import _merge_evidence, assign_evidence_ids, retrieve_for_draft

    needs_search, reason, search_queries = plan_revision_intent(
        settings,
        request,
        draft,
        instruction,
        evidence,
    )
    if on_event:
        on_event(
            "revision_intent_classified",
            {
                "instruction": display_instruction or instruction,
                "needs_search": needs_search,
                "reason": reason,
                "queries": search_queries,
            },
        )

    supplemental_evidence: list[dict] = []
    if needs_search:
        try:
            query_to_use = " ".join(search_queries) if search_queries else instruction
            retrieval_corpuses = list(
                dict.fromkeys(
                    str(item.get("corpus") or "").strip()
                    for item in evidence
                    if isinstance(item, dict) and str(item.get("corpus") or "").strip()
                )
            ) or ["reference"]
            supplemental_evidence, _ = retrieve_for_draft(
                query_to_use,
                retrieval_corpuses,
                settings,
                on_event=on_event,
            )
        except Exception as exc:
            logging.warning("Supplemental retrieval during revision failed: %s", exc)

    merged = _merge_evidence(list(evidence), supplemental_evidence)
    merged = assign_evidence_ids(merged)

    if on_event and needs_search:
        on_event(
            "revision_evidence_merged",
            {
                "supplemental_count": len(supplemental_evidence),
                "total_count": len(merged),
            },
        )

    merged = deepcopy(merged)
    debug = CitationDebug(merged)
    evidence_text = _citation_evidence(merged)
    debug.record("model_input", body=evidence_text[:64000])
    warnings = revision_warnings(display_instruction, request, merged)

    if on_event:
        on_event("revision_drafting_started", {"evidence_count": len(merged)})

    client = _client(settings)
    if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids":
        task_context = (
            f"原始來信/需求：\n{request}\n\n使用者修訂指令：\n{instruction}\n\n"
            f"目前草稿：\n{draft}"
        )
        if on_event:
            on_event("citation_plan_started", {"evidence_count": len(merged), "strategy": "deterministic"})
        citations, outline = _deterministic_citation_plan(merged)
        if on_event:
            on_event("citation_plan_ready", {"citation_count": len(citations), "strategy": "deterministic"})
        if on_citations:
            on_citations(citations)
        if on_event:
            on_event("report_generation_started", {"citation_count": len(citations)})
        revised, bound_citations = _stream_frozen_report(
            settings,
            client,
            "revision",
            task_context,
            citations,
            outline,
            merged,
            0.0,
            on_delta,
            on_start,
            debug,
            on_event,
        )
        return revised, bound_citations, warnings, merged
    extractor = _IncrementalDraftField()
    raw_parts: list[str] = []
    usable_parts: list[str] = []
    emitted_draft_parts: list[str] = []
    in_think = False
    think_buf = ""
    started = False
    citations_emitted = False
    finish_reasons: list[str] = []
    early_failure = None
    # The HTTP/UI contract requires verified citations before any draft text.
    original_delta, original_start = on_delta, on_start
    citation_gate = os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids" and on_citations is not None
    def gated_delta(text):
        if not citation_gate or citations_emitted:
            original_delta(text)
    def gated_start():
        if (not citation_gate or citations_emitted) and original_start:
            original_start()
    on_delta, on_start = gated_delta, gated_start


    try:
        stream = client.chat.completions.create(
            model=settings.chat_model,
            temperature=0.0,
            seed=getattr(settings, "llm_seed", 0),
            stream=True,
            messages=[
                {
                    "role": "system",
                    "content": "\n\n".join((system_prompt("revision"), _citation_instructions())),
                },
                {
                    "role": "user",
                    "content": (
                        f"原始來信/需求：\n{request}\n\n使用者修訂指令：\n{instruction}\n\n"
                        f"目前草稿：\n{draft}\n\nEvidence：\n{evidence_text}"
                    ),
                },
            ],
        )
        for chunk in checked_stream(stream, merged, debug) if os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "citation_ids" else stream:
            choices = getattr(chunk, "choices", None) or []
            if not choices:
                continue
            finish_reason = getattr(choices[0], "finish_reason", None)
            if finish_reason:
                finish_reasons.append(str(finish_reason))
            content = str(getattr(choices[0].delta, "content", None) or "")
            if not content:
                continue
            raw_parts.append(content)

            usable = ""
            for char in content:
                if in_think:
                    think_buf += char
                    if think_buf.endswith("</think>"):
                        in_think = False
                        think_buf = ""
                else:
                    think_buf += char
                    if think_buf.endswith("<think>"):
                        in_think = True
                        think_buf = ""
                    elif len(think_buf) >= 7:
                        usable += think_buf[:-6]
                        think_buf = think_buf[-6:]
            if not in_think and think_buf and len(think_buf) < 7:
                pass
            elif not in_think and think_buf:
                usable += think_buf[:-6]
                think_buf = think_buf[-6:]

            if not usable:
                continue

            usable_parts.append(usable)

            delta = extractor.feed(usable)
            if delta:
                emitted_draft_parts.append(delta)

            if on_citations and not citations_emitted:
                combined_usable = "".join(usable_parts)
                raw_citations = extract_json_array(combined_usable)
                mode = os.getenv("QUOTE_CITATION_MODE", "citation_ids")
                if mode == "citation_ids":
                    located = _safe_citation_prefix(combined_usable, merged)
                    if located is not None and not started:
                        citations_emitted = True
                        on_citations(located)
                elif mode == "sentence_ids":
                    located = _sentence_citations_metadata(
                        raw_citations, merged, "".join(emitted_draft_parts)
                    )
                    if located:
                        citations_emitted = True
                        on_citations(located)
                elif raw_citations:
                    located = locate_citations_metadata(raw_citations, merged)
                    if located:
                        citations_emitted = True
                        on_citations(located)

            if delta:
                if not started:
                    started = True
                    if on_start:
                        on_start()
                on_delta(delta)
        if not in_think and think_buf:
            delta = extractor.feed(think_buf)
            if delta:
                emitted_draft_parts.append(delta)
            if (
                on_citations
                and not citations_emitted
                and os.getenv("QUOTE_CITATION_MODE", "citation_ids") == "sentence_ids"
            ):
                located = _sentence_citations_metadata(
                    extract_json_array("".join(usable_parts) + think_buf), merged, "".join(emitted_draft_parts)
                )
                if located:
                    citations_emitted = True
                    on_citations(located)
            if delta:
                if not started:
                    started = True
                    if on_start:
                        on_start()
                on_delta(delta)
    except CitationMismatch as exc:
        early_failure = exc
        raw_parts = [exc.output]
    except OpenAIError as exc:
        raise APIError(HTTPStatus.BAD_GATEWAY, f"Chat model request failed: {exc}") from exc

    full_output = "".join(raw_parts)
    revised, citations = _validated_with_repair(
        settings,
        full_output,
        merged,
        on_event,
        debug,
        request + "\n修訂要求：" + instruction + "\n原草稿：" + draft,
        early_failure,
        system_prompt("revision"),
    )
    if citation_gate and not citations_emitted:
        on_citations(citations)
        if original_start:
            original_start()
        original_delta(revised)
    return revised, citations, warnings, merged


def revise_draft(
    settings: Settings,
    request: str,
    draft: str,
    instruction: str,
    display_instruction: str,
    evidence: list[dict],
) -> tuple[str, list[dict], list[str], list[dict]]:
    return revise_draft_stream(
        settings,
        request,
        draft,
        instruction,
        display_instruction,
        evidence,
        on_delta=lambda _: None,
    )
