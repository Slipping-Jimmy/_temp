# v0.1.0 7c9da0d complete UI and citation hotfix

This small overlay upgrades the installed
`7c9da0d6d8f479d8263a79329b89822178b2d172` base to the runtime behavior of
the verified `12d29ce` candidate without transferring Docker images.

It includes the previously reported UI corrections:

- real quick-adjustment document-review progress instead of generic workflow
  descriptions;
- compact paragraph-level citation placement, bounded citation fragments, and
  document-title fallback instead of excessive unnamed citation chips;
- visible topic-decomposition wait before the first search query.

The overlay mounts these current runtime files read-only into the app image:

- `letter_poc/domain/evidence.py`
- `letter_poc/services/drafting.py`
- `letter_poc/services/retrieval.py`
- `web/app.js`, `web/index.html`, and `web/workflow-data.js`

It also supplies the updated prompt catalogue. Prompt Inspector writes future
catalogue edits to the hotfix overlay's `overlay/letter_poc/prompts.yaml`, not
the old base directory. No image, `.env`, database schema, or PostgreSQL volume
is replaced. It does not add a retry for an upstream empty model response.

## Install

Extract the archive anywhere readable by Docker and run:

```sh
./apply_hotfix.sh /path/to/drafter-report-0.1.0-7c9da0d
```

The script verifies the exact target revision, its overlay checksums, and the
combined Compose configuration before recreating only app and prompt-inspector.
It also fixes the bind-mounted file/directory modes after extraction. Once both
services are healthy, use `Ctrl+F5` once in the browser.

## Rollback

Run the base deployment without the override:

```sh
cd /path/to/drafter-report-0.1.0-7c9da0d
docker compose --env-file .env up -d --pull never --force-recreate app prompt-inspector
```

Do not use `docker compose down --volumes`.
