# v11：整數上傳檔名與 prompt／問題分工

版本：20261028-v11。保留 v10 SSE 解析、absolute deadline、TTFT 與完成回覆判定。

## 安裝

在 `_temp` 執行（請用實際測試目錄）：

```bash
bash ./multimodal_load_test_update_20261028_v11/apply_update.sh ../multimodal_load_test
```

已提供解壓目錄，無需再解 tar。若只移轉壓縮包，先 `tar -xzf multimodal_load_test_update_20261028_v11.tar.gz`。
安裝會備份覆蓋的程式檔，保留 `.env`、原 `questions.json`、data、results 與虛擬環境。新檔 `questions_input_experiment.json` 是可選的問題檔。

## 第一個實驗：只改檔名

在既有 `.env` 加入或更新（不要保留重複 key）：

```dotenv
UPLOAD_FILENAME_MODE=integer
REQUEST_TEXT_FIELD=prompt
REQUEST_PROMPT=
```

`QUESTION_FILE` 維持原設定。只把 multipart filename 改為有效 manifest 圖片順序編號，如 `1.png`、`2.jpg`；不改圖片內容，不把 JPEG 假裝成 PNG，不改本地原檔名。

## 第二個實驗：分開格式指令和問題

已由同事確認：API 的 message 就是資料庫的 question。分工打法使用 message，不傳送 question 欄位。

在 `.env` 使用：

```dotenv
UPLOAD_FILENAME_MODE=integer
REQUEST_TEXT_FIELD=message
REQUEST_PROMPT="只輸出「符合」或「不符合」，不要解釋。"
QUESTION_FILE=./questions_input_experiment.json
```

程式會拒絕 `REQUEST_TEXT_FIELD=question`，避免送錯欄位。原 prompt 模式維持舊 payload。REQUEST_PROMPT 是 API prompt 欄位，不聲稱它必然是模型 system role。

先以 1 筆驗證後端紀錄及輸出，再擴大負載：

```bash
python3 unthrottled_load.py --config ./.env --output-root ./results \
  sse-burst --concurrency "1" --rounds 1 --between-rounds 0s --prepare-workers 1
```

新 CSV 欄位：upload_filename、request_text_field、request_prompt、request_text；搭配原 image_path 對照。run_config 記錄新設定。既有模型參數不變，仍是 presence_penalty=0.2，不傳 frequency_penalty。未新增多圖相似度測試。

本地完整測試 41 項通過；包內測試 39 項（不含依賴 PIL 的舊離線工具測試）。不是內網端到端驗證。
