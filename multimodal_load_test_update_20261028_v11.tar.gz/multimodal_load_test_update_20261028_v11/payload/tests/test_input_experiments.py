import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from unthrottled_load import build_sse_payload, load_settings, load_images, upload_filename


class InputExperimentTests(unittest.TestCase):
    def test_routes_are_explicit_and_preserve_ids(self):
        for route in ("prompt", "message"):
            instruction = "" if route == "prompt" else "只輸出符合或不符合"
            payload = build_sse_payload("conversation", "chat", "照片是否合規？", "attachment", {},
                                        text_field=route, instruction=instruction)
            self.assertEqual(payload[route], "照片是否合規？")
            self.assertEqual(payload["parent_id"], "conversation")
            self.assertEqual(payload["chat_id"], "chat")
            self.assertEqual(payload["attachments"], ["attachment"])
            if route != "prompt":
                self.assertEqual(payload["prompt"], instruction)
            self.assertNotIn("question", payload)
        with self.assertRaises(ValueError):
            build_sse_payload("c", "h", "q", "a", {}, text_field="question")
        with self.assertRaises(ValueError):
            build_sse_payload("c", "h", "q", "a", {}, text_field="unknown")
        with self.assertRaises(ValueError):
            build_sse_payload("c", "h", "q", "a", {}, instruction="would be lost")

    def test_filename_config_and_mapping_without_renaming(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "data/tono").mkdir(parents=True)
            (root / "data/tono/long-image-name.JPG").write_bytes(b"original bytes")
            (root / "images_manifest.csv").write_text("path,valid\nlong-image-name.JPG,1\n", encoding="utf-8")
            (root / "questions.json").write_text("[]")
            config = root / ".env"
            base = "PLAYGROUND_BASE_URL=http://example.invalid\nPLAYGROUND_TOKEN=test-only\n"
            config.write_text(base)
            settings = load_settings(config, None)
            self.assertEqual(settings.upload_filename_mode, "original")
            self.assertEqual(settings.request_text_field, "prompt")
            config.write_text(base + 'UPLOAD_FILENAME_MODE=integer\nREQUEST_TEXT_FIELD=message\n'
                              'REQUEST_PROMPT="只輸出符合或不符合"\n', encoding="utf-8")
            settings = load_settings(config, None)
            image = load_images(settings)[0]
            self.assertEqual(upload_filename(image, settings.upload_filename_mode), "1.jpg")
            self.assertEqual(upload_filename(image, "original"), "long-image-name.JPG")
            self.assertEqual(Path(image["absolute_path"]).read_bytes(), b"original bytes")
            self.assertEqual(settings.request_prompt, "只輸出符合或不符合")
            for invalid in ("UPLOAD_FILENAME_MODE=bad", "REQUEST_TEXT_FIELD=bad",
                            "REQUEST_PROMPT=lost"):
                config.write_text(base + invalid + "\n")
                with self.assertRaises(ValueError):
                    load_settings(config, None)
