# Unthrottled load test: unthrottled-20261021T092445Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_15c | sse_burst | 15 | 45 | 45 | 45 | 0.00 | 22 | 48.89 | 0 | 0 | 1852.8 | 2197.3 | 2220.9 | 12.0 |
| stage_002_sse_burst_20c | sse_burst | 20 | 60 | 60 | 60 | 0.00 | 12 | 20.00 | 0 | 0 | 1816.2 | 2167.9 | 2470.6 | 18.9 |
| stage_003_sse_burst_25c | sse_burst | 25 | 75 | 75 | 75 | 0.00 | 10 | 13.33 | 0 | 0 | 2314.4 | 2651.2 | 2936.0 | 22.4 |
| stage_004_sse_burst_30c | sse_burst | 30 | 90 | 90 | 90 | 0.00 | 10 | 11.11 | 0 | 0 | 2607.3 | 2945.2 | 3116.7 | 31.2 |
| stage_005_sse_burst_35c | sse_burst | 35 | 105 | 105 | 105 | 0.00 | 10 | 9.52 | 0 | 0 | 3005.1 | 3389.8 | 3691.3 | 37.2 |
| stage_006_sse_burst_40c | sse_burst | 40 | 120 | 120 | 120 | 0.00 | 5 | 4.17 | 0 | 0 | 3734.5 | 4168.4 | 4765.9 | 43.0 |
| stage_007_sse_burst_45c | sse_burst | 45 | 135 | 135 | 135 | 0.00 | 4 | 2.96 | 0 | 0 | 4076.2 | 4540.7 | 4825.7 | 53.5 |
| stage_008_sse_burst_50c | sse_burst | 50 | 150 | 150 | 149 | 0.67 | 2 | 1.34 | 0 | 0 | 4601.7 | 5266.0 | 5368.8 | 55.5 |
  - errors: `{"client_sse_absolute_timeout": 1}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
