# Unthrottled load test: unthrottled-20261029T101448Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_50c | sse_burst | 50 | 150 | 150 | 150 | 0.00 | 150 | 100.00 | 0 | 0 | 4308.9 | 5022.4 | 5060.1 | 69.9 |
| stage_002_sse_burst_100c | sse_burst | 100 | 300 | 300 | 300 | 0.00 | 300 | 100.00 | 0 | 0 | 8484.8 | 11745.0 | 11897.6 | 142.0 |
| stage_003_sse_burst_150c | sse_burst | 150 | 450 | 450 | 450 | 0.00 | 450 | 100.00 | 0 | 0 | 11880.5 | 17316.1 | 17653.9 | 202.6 |
| stage_004_sse_burst_200c | sse_burst | 200 | 600 | 600 | 599 | 0.17 | 599 | 100.00 | 0 | 0 | 15799.0 | 23894.5 | 24498.2 | 320.8 |
  - errors: `{"sse_no_content": 1}`
| stage_005_sse_burst_250c | sse_burst | 250 | 750 | 750 | 747 | 0.40 | 747 | 100.00 | 0 | 0 | 21780.9 | 29134.7 | 29517.7 | 396.0 |
  - errors: `{"sse_no_content": 3}`
| stage_006_sse_burst_300c | sse_burst | 300 | 900 | 900 | 900 | 0.00 | 900 | 100.00 | 0 | 0 | 24674.0 | 34107.5 | 34858.4 | 529.4 |
| stage_007_sse_burst_350c | sse_burst | 350 | 1050 | 1050 | 1048 | 0.19 | 1048 | 100.00 | 0 | 0 | 28901.9 | 38158.7 | 38906.8 | 565.3 |
  - errors: `{"sse_no_content": 2}`
| stage_008_sse_burst_400c | sse_burst | 400 | 1200 | 1200 | 1197 | 0.25 | 1197 | 100.00 | 0 | 0 | 37164.9 | 48940.4 | 49517.0 | 681.2 |
  - errors: `{"sse_model_communication_error": 2, "sse_no_content": 1}`
| stage_009_sse_burst_450c | sse_burst | 450 | 1350 | 1350 | 1345 | 0.37 | 1345 | 100.00 | 0 | 0 | 44775.3 | 57929.1 | 59487.2 | 823.1 |
  - errors: `{"sse_model_communication_error": 1, "sse_no_content": 4}`
| stage_010_sse_burst_500c | sse_burst | 500 | 1500 | 1500 | 1480 | 1.33 | 1480 | 100.00 | 525 | 0 | 58494.1 | 76450.6 | 78559.8 | 889.6 |
  - errors: `{"sse_model_communication_error": 5, "sse_no_content": 14, "sse_record_save_error": 1}`
  - 60-second cutoff candidates: **525**
  - timeout basis: `{"first_token": 525}`

## 60-second cutoff boundary

The first cutoff candidate occurred at **stage_010_sse_burst_500c** (target=500, count=525).

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received SSE lines with elapsed times and chat IDs, including blank event separators, event names and completion markers. Wire-line counters distinguish empty responses from heartbeat-only streams.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.

## All-request first-token timing

Includes failed requests that received content. Requests without a first token are counted separately, not assigned zero latency.

| Target | First token received | No first token | TTFT >60s | Mean ms | p95 ms | Max ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 50 | 150 | 0 | 0 | 3129.4 | 4266.7 | 4331.4 |
| 100 | 300 | 0 | 0 | 6703.1 | 10646.9 | 10965.4 |
| 150 | 450 | 0 | 0 | 9272.8 | 15461.7 | 15758.0 |
| 200 | 599 | 1 | 0 | 12379.0 | 21068.2 | 22405.2 |
| 250 | 747 | 3 | 0 | 18129.3 | 27026.5 | 28245.1 |
| 300 | 900 | 0 | 0 | 20678.1 | 31932.8 | 32965.1 |
| 350 | 1048 | 2 | 0 | 23709.9 | 35746.6 | 38814.2 |
| 400 | 1197 | 3 | 0 | 30432.4 | 47109.7 | 49154.9 |
| 450 | 1345 | 5 | 0 | 37963.3 | 55668.9 | 57455.5 |
| 500 | 1481 | 19 | 524 | 50723.5 | 73043.6 | 76930.2 |
