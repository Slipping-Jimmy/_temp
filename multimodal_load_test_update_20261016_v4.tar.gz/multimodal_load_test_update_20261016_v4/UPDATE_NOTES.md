# Multimodal load-test update 20261016-v4

這是給既有 `multimodal_load_test` 的小型增量修正包，不含圖片資料集，也不會覆蓋
`.env`、`data/`、`results/` 或 `.venv-loadtest/`。

## 新增內容

- `sse-burst`：先完成 N 筆 attachment upload，所有 SSE worker 抵達 barrier 後才同步放行。
- 原本 `burst` 保留，語意仍是 upload＋SSE 完整流程同時開始；也升級為所有 worker
  到齊 barrier 後才放行。
- 每筆請求仍使用同一 token，並產生唯一 UUID `chat_id`。
- 某 round 只要一筆準備失敗，整個 round 取消，不會用較少請求冒充目標並發數。
- 預設在第一個有失敗的並發級別停止；可用 `--continue-after-failure` 覆寫。
- `summary.csv` 新增平均、p95、最大完整回答時間、準備失敗數與最大同步誤差。
- `report.html` 新增可離線開啟的「同時請求數 × 完整回答時間」圖表，含 60 秒線。
- conversation/upload 的準備錯誤與 SSE/model cutoff 分類分開，避免錯誤歸因。
- 不需要新增 Python 套件。

## 安裝

把整個更新資料夾搬到內網後：

```bash
cd multimodal_load_test_update_20261016_v4
chmod +x apply_update.sh
./apply_update.sh ~/ModelUseData/ivan/multimodal_load_test
```

安裝器會先把被替換的三個檔案備份到目標資料夾中的
`_update_backup_<timestamp>/`，然後執行語法與單元測試。

## 建議執行

若要避免歷史對話內容影響每輪結果，建議讓 `.env` 中的
`FIXED_CONVERSATION_ID=` 留空；`shared` 模式會為每個 round 建立一個新的 conversation，
該 round 內的所有請求則共用它。若後端目前無法建立 conversation，才暫時填入已知可用 ID，
並在報告註明跨 round 重用的限制。

```bash
cd ~/ModelUseData/ivan/multimodal_load_test
source .venv-loadtest/bin/activate

python3 unthrottled_load.py \
  --config ./.env \
  --output-root ./results \
  sse-burst \
  --concurrency "1 5 10 15 20 25 30 35 40 45 50" \
  --rounds 5 \
  --between-rounds 20s \
  --prepare-workers 8
```

第一個出現失敗的級別會是最後一個 X 軸資料點。請將完整的
`results/<run_id>/` 帶回；重點檔案為 `summary.csv`、`report.html`、`report.md` 和各級
`transactions.csv`。
