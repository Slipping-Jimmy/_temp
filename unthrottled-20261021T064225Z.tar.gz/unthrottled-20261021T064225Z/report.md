# Unthrottled load test: unthrottled-20261021T064225Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_15c | sse_burst | 15 | 45 | 45 | 45 | 0.00 | 31 | 68.89 | 0 | 0 | 1630.8 | 1809.8 | 1923.6 | 14.3 |
| stage_002_sse_burst_20c | sse_burst | 20 | 60 | 60 | 58 | 3.33 | 11 | 18.97 | 0 | 0 | 1635.8 | 1980.7 | 2565.6 | 18.7 |
  - errors: `{"sse_record_save_error": 2}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received non-empty SSE lines with elapsed times and chat IDs, including event names and completion markers for parser diagnosis.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.
