# Multimodal load-test report: 20261014T105955Z

## 結論

- 觀測到的最高成功吞吐量：**4.870 requests/s** （24 users，stage_004_24u）。
- 暫定 SLO 下的最高通過級別：**24 users / 4.870 requests/s**。
- 暫定門檻：error ≤ 1%、p95 TTFT ≤ 3000 ms、p95 SSE total ≤ 10000 ms。
- 最終容量仍應搭配 vLLM queue、GPU 及至少 30 分鐘耐久測試確認。

## 各級負載

| Users | Requests | Success RPS | Error % | p50 TTFT ms | p95 TTFT ms | p95 SSE ms | p95 E2E ms | Avg output chars | Pass |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 12 | 1169 | 3.861 | 0.00 | 776.8 | 1091.5 | 1572.8 | 3798.8 | 17.7 | Y |
| 16 | 1270 | 4.200 | 0.00 | 1056.3 | 1437.3 | 1913.1 | 4462.6 | 18.1 | Y |
| 20 | 1416 | 4.283 | 0.07 | 1195.1 | 1670.5 | 2193.9 | 5072.2 | 18.8 | Y |
| 24 | 1469 | 4.870 | 0.00 | 1494.3 | 2229.8 | 2673.2 | 5823.6 | 18.0 | Y |
| 28 | 1602 | 4.143 | 21.60 | 1748.5 | 2428.6 | 2945.9 | 6205.3 | 22.4 | N |
| 32 | 1896 | 0.230 | 96.31 | 518.0 | 773.8 | 1034.9 | 4881.4 | 14.5 | N |

## 錯誤分布

- stage_003_20u: client_interrupted_GreenletExit=1
- stage_005_28u: upload_http_error=346
- stage_006_32u: upload_http_error=1826

## Server telemetry

未收集 vLLM/GPU telemetry；容量仍可由 client 結果計算，但無法完整定位瓶頸。

## 解讀注意事項

- SSE chunk 數不是 token 數；token throughput 只採用 vLLM metrics。
- 此報告的 RPS 使用整個 stage wall time，包含 ramp-up，數字較保守。
- TONO 主要是不合規樣本，本報告不將模型準確率視為容量判定條件。
- 若圖片被大量重複，multimodal cache 可能讓容量偏高，應一併查看 manifest 與 cache 指標。
