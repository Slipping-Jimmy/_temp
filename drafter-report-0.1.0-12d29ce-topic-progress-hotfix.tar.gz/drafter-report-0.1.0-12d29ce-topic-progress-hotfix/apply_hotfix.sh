#!/bin/sh
set -eu

HOTFIX_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BASE_DIR="$(CDPATH= cd -- "${1:-.}" && pwd)"

if [ ! -f "$BASE_DIR/docker-compose.yml" ] || [ ! -f "$BASE_DIR/.env" ]; then
  echo "Usage: $0 <existing-drafter-deployment-directory>" >&2
  echo "The target directory must contain docker-compose.yml and .env." >&2
  exit 2
fi

(cd "$HOTFIX_DIR" && sha256sum -c checksums.sha256)

if [ -f "$BASE_DIR/release.json" ] && ! grep -q '"commit": "e1c0a793ffa3fc66f8c29fb78f2469a898a19b18"' "$BASE_DIR/release.json"; then
  echo "Warning: this overlay was verified against the e1c0a79 v0.1.0 candidate." >&2
  echo "Confirm the target image is compatible before continuing." >&2
fi

export DRAFTER_HOTFIX_DIR="$HOTFIX_DIR"
cd "$BASE_DIR"
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" config --quiet
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" up -d --pull never --force-recreate app prompt-inspector
docker compose --env-file .env -f docker-compose.yml -f "$HOTFIX_DIR/docker-compose.hotfix.yml" ps
