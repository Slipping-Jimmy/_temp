# v0.1.0 topic-decomposition progress hotfix

This small overlay exposes the otherwise silent topic-decomposition model wait
before the first reference search. It is built from source revision
`12d29ce6d1346ef567557d93c98a5fd3220843fc` and is intended for the prior
local v0.1.0 `e1c0a79` deployment candidate.

It mounts exactly these runtime files into the existing application images:

- `overlay/letter_poc/services/retrieval.py` →
  `/app/letter_poc/services/retrieval.py`
- `overlay/web/app.js` → `/app/web/app.js`
- `overlay/web/index.html` → `/app/web/index.html`
- `overlay/web/workflow-data.js` → `/app/web/workflow-data.js`

The prompt-inspector additionally mounts `workflow-data.js`. No image, model
setting, prompt catalogue, database schema, or PostgreSQL volume is changed.
This hotfix does **not** add a retry for an upstream chat-model empty response.

## Install

1. Copy `drafter-report-0.1.0-12d29ce-topic-progress-hotfix.tar.gz` to the
   machine and extract it anywhere readable by Docker.
2. From the extracted directory, run:

   ```sh
   ./apply_hotfix.sh /path/to/current/drafter-deployment
   ```

   The target path must contain the deployment's `docker-compose.yml` and
   existing `.env`. The script verifies the overlay checksums, recreates only
   `app` and `prompt-inspector`, and retains the PostgreSQL volume and data.
3. Confirm the services are healthy, then use a hard refresh (`Ctrl+F5`) once
   in the browser. The page will show 「正在拆解題目」 while it waits for the
   model to create search terms, then 「題目拆解完成」 before normal retrieval.

## Rollback

Run the existing deployment without this override:

```sh
cd /path/to/current/drafter-deployment
docker compose --env-file .env up -d --pull never --force-recreate app prompt-inspector
```

Do not run `docker compose down --volumes`.
