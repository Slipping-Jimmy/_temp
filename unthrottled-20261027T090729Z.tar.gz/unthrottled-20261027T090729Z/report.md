# Unthrottled load test: unthrottled-20261027T090729Z

## Stages

| Stage | Mode | Target | Scheduled | Admitted | Success | Error % | Valid answers | Valid % | 60s candidates | Prep failures | Mean E2E ms | p95 E2E ms | Max E2E ms | Max release skew ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| stage_001_sse_burst_5c | sse_burst | 5 | 15 | 15 | 15 | 0.00 | 7 | 46.67 | 0 | 0 | 1167.5 | 1284.6 | 1305.0 | 6.7 |
| stage_002_sse_burst_10c | sse_burst | 10 | 30 | 30 | 29 | 3.33 | 18 | 62.07 | 0 | 0 | 1732.0 | 2129.2 | 4753.3 | 10.6 |
  - errors: `{"sse_no_content": 1}`

## 60-second cutoff boundary

No 60-second cutoff candidate was observed in these stages; increase the burst size or arrival rate to continue finding the boundary.

## Interpretation

- `burst` sends the target number of jobs together, then waits for the round to finish.
- `sse_burst` uploads all attachments first and then releases all SSE/model requests together; its E2E values measure SSE release through complete model answer.
- `open_loop` schedules at its target requests/s even while earlier jobs are still running.
- `admission_limited > 0` means the client safety cap was reached; increase `--max-inflight` before treating that stage as a server capacity result.
- `cutoff_60s_candidates` uses the confirmed first-token limit: TTFT > 60000 ms, or failure near 60s before any model content. Post-token failures remain errors but do not count as this cutoff.
- `timeout_basis_counts` reports `first_token`. Confirm candidates with API/vLLM logs. E2E measures completed answers and is not the timeout criterion.
- With CAPTURE_RESPONSE=1, `sse_raw.jsonl` stores received SSE lines with elapsed times and chat IDs, including blank event separators, event names and completion markers. Wire-line counters distinguish empty responses from heartbeat-only streams.
- `answer_valid_rate_percent` checks whether a successful short-profile response is exactly `符合` or `不符合` after removing protocol markers.

## All-request first-token timing

Includes failed requests that received content. Requests without a first token are counted separately, not assigned zero latency.

| Target | First token received | No first token | TTFT >60s | Mean ms | p95 ms | Max ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 5 | 15 | 0 | 0 | 1009.4 | 1150.6 | 1169.8 |
| 10 | 29 | 1 | 0 | 1379.5 | 1731.1 | 1735.6 |
